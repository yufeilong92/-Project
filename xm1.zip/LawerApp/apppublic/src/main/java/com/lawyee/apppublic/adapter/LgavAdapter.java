package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.andview.refreshview.recyclerview.BaseRecyclerAdapter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.vo.LgavActivityVO;
import com.lawyee.apppublic.vo.LgavNoticeVO;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.TimeUtil;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: 我的活动适配器
 * @author: YFL
 * @date: 2017/9/28 16:06
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavAdapter extends BaseRecyclerAdapter<LgavAdapter.ViewHolder> implements View.OnClickListener {


    private Context mContext;
    private ArrayList mDatas;
    private final LayoutInflater mInflater;
    public static final String LGAVACTIVITY = "0";//活动类型
    public static final String LGAVNOTICE = "1";//通知公告
    /**
     *显示类型
     */
    private String mTypeStr;
    //item 接口
    private OnRecyclerItemOnClickListener itemOnClickListener=null;

    public OnRecyclerItemOnClickListener getItemOnClickListener() {
        return itemOnClickListener;
    }

    public void setItemOnClickListener(OnRecyclerItemOnClickListener itemOnClickListener) {
        this.itemOnClickListener = itemOnClickListener;
    }

    /**
     *
     * @param mContext 上下文
     * @param mDatas  数据vo
     * @param type   数据类型 LGAVACTIVITY活动类型 ，LGAVLAW通知公告类型
     */
    public LgavAdapter(Context mContext, ArrayList mDatas, String type) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        mInflater = LayoutInflater.from(mContext);
        this.mTypeStr = type;
    }

    @Override
    public void onClick(View v) {
      if (itemOnClickListener!=null){
          itemOnClickListener.onItemClickListener(v,v.getTag());
      }
    }

    public  interface  OnRecyclerItemOnClickListener{
        /**
         *
         * @param view
         * @param content oid
         */
        public void onItemClickListener(View view, Object content);
    }

    @Override
    public ViewHolder getViewHolder(View view) {
        return new ViewHolder(view);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i, boolean b) {
        View view = mInflater.inflate(R.layout.item_lgav_activity, null);
        view.setOnClickListener(this);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i, boolean b) {
        //判空
        if (StringUtil.isEmpty(mTypeStr))
            return;
        //获取vo （活动/通知）
        //判断是否阅读
        //显示（活动/通知）
        if (mTypeStr.equals(LGAVACTIVITY)) {//活动
            LgavActivityVO vo = (LgavActivityVO) mDatas.get(i);
            viewHolder.mTvLgavactivityTitle.setText(vo.getTitle());
            String ymdt = TimeUtil.getYMDT(vo.getPublishDatetime());
            viewHolder.mTvLgavactivityTime.setText(ymdt);
            //点击保存一个id
            viewHolder.itemView.setTag(vo.getOid());
        } else if (mTypeStr.equals(LGAVNOTICE)) {//通知
            LgavNoticeVO vo = (LgavNoticeVO) mDatas.get(i);
            viewHolder.mTvLgavactivityTitle.setText(vo.getTitle());
            String ymdt = TimeUtil.getYMDT(vo.getPublishDate());
            viewHolder.mTvLgavactivityTime.setText(ymdt);
            //点击是保存一个id
            viewHolder.itemView.setTag(vo.getOid());

        }
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mTvLgavactivityTitle;
        public TextView mTvLgavactivityTime;

        public ViewHolder(View itemView) {
            super(itemView);
            this.mTvLgavactivityTitle = (TextView) itemView.findViewById(R.id.tv_lgavactivity_title);
            this.mTvLgavactivityTime = (TextView) itemView.findViewById(R.id.tv_lgavactivity_time);
        }
    }


}
