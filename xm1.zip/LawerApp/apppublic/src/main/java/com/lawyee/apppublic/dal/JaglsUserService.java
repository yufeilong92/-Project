package com.lawyee.apppublic.dal;

import android.content.Context;

import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.vo.UserVO;

import net.lawyee.mobilelib.json.JsonCreater;
import net.lawyee.mobilelib.utils.SecurityUtil;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.dal
 * @Description: 法律工作者用户接口
 * @author: uustrong
 * @date: 2017/10/24 11:27
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class JaglsUserService extends BaseJsonService {
    /**
     * @param c
     */
    public JaglsUserService(Context c) {
        super(c);
    }

    /**
     * 【服务管理端】获取某法律工作者的委托列表
     * @param pageNo 第几页,从1开始
     * @param listener 结果回调
     */
    public void getEntrustList(int pageNo,
                               IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin())
        {
            listener.onError("请先进行用户登录","");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId",  SecurityUtil.Encrypt(userVO.getSessionId(),SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        creater.setParam("pageNo",pageNo<1?1:pageNo);
        creater.setParam("pageSize", Constants.CINT_PAGE_SIZE);
        mCommandName = "mmJaglsGetEntrustList";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_LIST);
        getData(json, null);
    }

    /**
     * 【服务管理端】获取某法律工作者委托详情
     * @param entrustId 预申请id
     * @param listener 结果回调
     */
    public void getEntrustDetail(String entrustId,
                                 IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin())
        {
            listener.onError("请先进行用户登录","");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId",  SecurityUtil.Encrypt(userVO.getSessionId(),SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        creater.setParam("entrustId",entrustId);
        mCommandName = "mmJaglsGetEntrustDetail";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);
    }

    /**
     * 【服务管理端】某法律工作者委托回复详情
     * @param entrustId 委托id
     * @param entrustLawyerMobilePhone 律师手机号
     * @param entrustLawyerFixedPhone 律师座机
     * @param entrustLawyerAnswer 回复内容
     * @param listener 结果回调
     */
    public void postEntrustReply(String entrustId,String entrustLawyerMobilePhone,
                                 String entrustLawyerFixedPhone,String entrustLawyerAnswer,
                                 IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin())
        {
            listener.onError("请先进行用户登录","");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId",  SecurityUtil.Encrypt(userVO.getSessionId(),SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        creater.setParam("entrustId",entrustId);
        creater.setParam("entrustStaffMobilePhone",entrustLawyerMobilePhone);
        creater.setParam("entrustStaffFixedPhone",entrustLawyerFixedPhone);
        creater.setParam("entrustStaffAnswer",entrustLawyerAnswer);
        mCommandName = "mmJaglsPostEntrustReply";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);
    }
}
