package com.lawyee.apppublic.dal;

import android.content.Context;

import com.lawyee.apppublic.config.Constants;

import net.lawyee.mobilelib.json.JsonCreater;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  LegalService.java
 * @Package com.lawyee.apppublic.dal
 * @Description:    以案释法
 * @author: YFL
 * @date:   2017/12/27 14:58
 * @version V 1.0 xxxxxxxx
 * @verdescript  版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/12/27 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LegalService extends BaseJsonService {

    /**
     * @param c
     */
    public LegalService(Context c) {
        super(c);
    }

    /**
     *  查询我的活动接口
     * @param pageNo 页
     * @param listener
     */
    public void queryUserGetLgavLawList(int pageNo,  IResultInfoListener listener) {
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("pageSize",Constants.CINT_PAGE_SIZE);
        creater.setParam("pageNo", pageNo < 1 ? 1 : pageNo);
        mCommandName = "mmUserGetLgavLawList";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_LIST);
        getData(json, null);
    }


}
