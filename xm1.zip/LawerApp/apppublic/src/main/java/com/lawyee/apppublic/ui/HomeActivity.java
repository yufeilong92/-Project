package com.lawyee.apppublic.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.afollestad.materialdialogs.MaterialDialog;
import com.andview.refreshview.XRefreshView;
import com.jauker.widget.BadgeView;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.HomeAdpater;
import com.lawyee.apppublic.adapter.LawWorkPopAdapter;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.CommonService;
import com.lawyee.apppublic.dal.InfoService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.dal.LgavNoticeService;
import com.lawyee.apppublic.ui.lawAdministration.PersionActivity;
import com.lawyee.apppublic.ui.personalcenter.LoginActivity;
import com.lawyee.apppublic.ui.personalcenter.PersonCenterActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerPCenterActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity;
import com.lawyee.apppublic.util.SessionIdUtil;
import com.lawyee.apppublic.util.db.ChatProvider;
import com.lawyee.apppublic.util.db.IMDBHelper;
import com.lawyee.apppublic.vo.InfomationVO;
import com.lawyee.apppublic.vo.JaLawWorkVO;
import com.lawyee.apppublic.vo.JaUpdateVO;
import com.lawyee.apppublic.vo.LgavNoticeVO;
import com.lawyee.apppublic.vo.MarqueeBean;
import com.lawyee.apppublic.vo.UnreadVO;
import com.lawyee.apppublic.vo.UserVO;
import com.lawyee.apppublic.widget.FloatDragView;
import com.lawyee.apppublic.widget.MyMarqueeLayout;
import com.lawyee.apppublic.widget.XRefreshViewLayout;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import static com.lawyee.apppublic.ui.UpdateActivity.UPDATA;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity.CSTR_URL;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_BASICLAWWORKER;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_JALAW;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  标题
 * @Package com.lawyee.apppublic.ui
 * @Description:    首页Activity
 * @author:czq
 * @date:   2017/5/15
 * @version
 * @verdescript   2017/5/15  czq 初建
 * @Copyright: 2017/5/15 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class HomeActivity extends BaseActivity {
    private final static String HOMEID="homenews";
    private RecyclerView mRecyclerView;
    private ImageView mIvSearch;
    private HomeAdpater mAdpater;

    private Context mContext;
    private XRefreshViewLayout mXrefreshview;
    /**
     * 数据是否处理中，用于服务端请求数据时标识，防止重复申请
     */
    private Boolean mInProgess= false;
    /**
     * 数据列表
     */
    @SuppressWarnings("rawtypes")
    protected ArrayList mDataList;
    private String[] mId;
    private BadgeView badgeView;
    private Handler mChatHandler = new Handler();
    private ImageView iv_per;
    private int mNum;
    private ChatObserver mChatObserver = new ChatObserver();
    private UnreadVO mUnreadVO;
    GridLayoutManager gridLayoutManager;
    private MaterialDialog mShow;
    List<JaLawWorkVO> mWrokList=new ArrayList<>();//律师工作列表
    private RelativeLayout mMainLayout;
    private ImageView mWrokImage;
    private  LawWorkPopAdapter applyPopAdapter;
    private ArrayList<LgavNoticeVO> mNoticeDataList=new ArrayList<LgavNoticeVO>();//通知公告数据
    ArrayList<MarqueeBean> arrayList=new ArrayList<>();//topnoticelist
    MyMarqueeLayout marqueeLayout;
    private String mSessionid="";
    private boolean isFirst=true;
    private AlertDialog show;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void initContentView(Bundle savedInstanceState) {

        setContentView(R.layout.activity_home);
        mContext=this;
        initView();
        mMainLayout = (RelativeLayout) findViewById(R.id.main_layout);
        addFloatBtn();
        loadData();
        getContentResolver().registerContentObserver(
                ChatProvider.CONTENT_URI, true, mChatObserver);// 开始聊天数据库
//       checkUpdate();
    }



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onResume() {
        super.onResume();
        mAdpater.setCenterView();
        setBadgView(badgeView,0);

        if(isFirst){
            requestNoticeService();
            isFirst=false;
        }else {
            if (!ApplicationSet.getInstance().IsLogin() && !mSessionid.equals("")) {
                mSessionid = "";
                requestNoticeService();
            } else if (ApplicationSet.getInstance().IsLogin() && !mSessionid.equals(ApplicationSet.getInstance().getUserVO().getSessionId())) {
                mSessionid = ApplicationSet.getInstance().getUserVO().getSessionId();
                requestNoticeService();
            }
        }

           isDuty();
        if(ApplicationSet.getInstance().getUserVO()!=null &&
                ApplicationSet.getInstance().getUserVO().getRole()!=null&&
                (ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_JALAW)
                        ||  ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_BASICLAWWORKER))){
            if(ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_JALAW)){
                mWrokImage.setVisibility(View.VISIBLE);
            }else{
                mWrokImage.setVisibility(View.GONE);
            }
            loadNoread();
        }else{
            mUnreadVO=null;
            loadMessageNum();
            mWrokImage.setVisibility(View.GONE);

        }



    }

    private void isDuty() {
        if(ApplicationSet.getInstance().IsLogin()&&ApplicationSet.getInstance().getUserVO().getDutyFlag().equals("true")){
            iv_per.setImageResource(R.drawable.icon_duty);
        }else{
            iv_per.setImageResource(R.drawable.ic_per_center);
        }
    }

    //设置快讯视图
    private void setTopNotice() {

        arrayList = new ArrayList<MarqueeBean>();
        Log.e("czqmNoticeDataList",mNoticeDataList.size()+"");
        if(mNoticeDataList.size()>0){
            marqueeLayout.setVisibility(View.VISIBLE);
            int length=0;
            if(mNoticeDataList.size()<=5){
                length=mNoticeDataList.size();
            }else{
                length=5;
            }
            for(int i=0;i<length;i++){
                MarqueeBean bean = new MarqueeBean();
                bean.setOid(mNoticeDataList.get(i).getOid());
                bean.setTitle(mNoticeDataList.get(i).getTitle());
                arrayList.add(bean);
            }
            Log.e("czqmarrayList",arrayList.size()+"");
            marqueeLayout.setList(arrayList);
            marqueeLayout.start();
        }else{

            marqueeLayout.setVisibility(View.GONE);
        }

    }

    //绑定未读消息
    private void loadMessageNum() {

        if(ApplicationSet.getInstance().IsLogin()) {
             mNum = IMDBHelper.getInstance().getNoReadMessage(ApplicationSet.getInstance().getUserVO().getOpenfireLoginId());
            if( mWrokImage.getVisibility()==View.VISIBLE){
                mWrokList= getJaLawWorkVO(mNum);
                if(applyPopAdapter!=null){
                    applyPopAdapter.notifyDataSetChanged();
                }

            }
            if(mUnreadVO!=null){
                mNum=mNum+Integer.parseInt(mUnreadVO.getTotalCount());
            }
            setBadgView(badgeView,mNum);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        getContentResolver().unregisterContentObserver(mChatObserver);
    }

    private void initView() {

        marqueeLayout = (MyMarqueeLayout)findViewById(R.id.main_buyfood_marquee);
        marqueeLayout.setVisibility(View.GONE);

        marqueeLayout.setListener(new MyMarqueeLayout.onClickPositionListener() {
            @Override
            public void onClick(int position) {
               // Toast.makeText(mContext, "position:"+position +"||title:"+arrayList.get(position).getTitle(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(mContext, WebViewShowActivity.class);
                intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.notice_announcement));
                String url="";
                if(ApplicationSet.getInstance().IsLogin()){
                    url=getString(R.string.url_base) +getString(R.string.url_notice)+arrayList.get(position).getOid()+ getString(R.string.url_sessionid) +SessionIdUtil.getUserSessionId(mContext) +
                            getString(R.string.url_appstamp) +  SessionIdUtil.getAppstamp(mContext);;
                }else{
                    url=getString(R.string.url_base) +getString(R.string.url_notice)+arrayList.get(position).getOid();
                }
                intent.putExtra(CSTR_URL, url);
                startActivity(intent);
            }
        });
        mRecyclerView= (RecyclerView) findViewById(R.id.rv_home);
        mXrefreshview= (XRefreshViewLayout) findViewById(R.id.xrefreshview);
        iv_per= (ImageView) findViewById(R.id.iv_per);
        mIvSearch= (ImageView) findViewById(R.id.iv_search);

        mIvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, WebViewShowActivity.class);
                intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.search));
                String url =getString(R.string.url_base) +getString(R.string.url_search);
                intent.putExtra(CSTR_URL, url);
                startActivity(intent);
            }
        });

        // 设置是否可以下拉刷新
        mXrefreshview.setPullRefreshEnable(true);
        mXrefreshview.restoreLastRefreshTime(0l);
        badgeView = new BadgeView(this);
        badgeView.setTargetView(iv_per);
        badgeView.setBackground(12, Color.parseColor("#FFFF00"));
        badgeView.setBadgeGravity(Gravity.TOP | Gravity.RIGHT);
        badgeView.setBadgeMargin(0, 5 , 0, 0 );
        badgeView.setTypeface(Typeface.create(Typeface.SANS_SERIF,
               Typeface.ITALIC));
        badgeView.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary));
     //   badgeView.setShadowLayer(2, -1, -1, Color.BLACK);
        badgeView.setVisibility(View.GONE);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy!=0&&mAdpater != null && (mAdpater.getCentreModeConsultantButton() != null||mAdpater.getCentreModeSuppoButton() != null)) {
                        if(mAdpater.getCentreModeConsultantButton() != null&&mAdpater.getCentreModeConsultantButton().isOpen()) {
                            mAdpater.getCentreModeConsultantButton().close(false);
                        }
                        if(mAdpater.getCentreModeSuppoButton() != null&&mAdpater.getCentreModeSuppoButton().isOpen()){
                            mAdpater.getCentreModeSuppoButton().close(false);
                        }
                }
            }
        });

    }

    public void onToolbarClick(View view)
    {

        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin()) {
            startActivity(new Intent(mContext, LoginActivity.class));
        }else
        {
            if(userVO.isPublicUser()){
                startActivity(new Intent(mContext,PersonCenterActivity.class));
            }else{
                       if(userVO.getRole().equals(CSTR_USERROLE_JALAW)||userVO.getRole().equals(CSTR_USERROLE_BASICLAWWORKER)){
                           startActivity(new Intent(mContext,LawyerPCenterActivity.class));
                       }else if(userVO.getRole().equals(UserVO.CSTR_USERROLE_JAMED)){//人民调解服务
                           Intent intent = new Intent(mContext, PersionActivity.class);
                           intent.putExtra(PersionActivity.CONTENT_PARAMETER_TYPE, PersionActivity.CONTENT_PARAMETER_JAMED);
                           startActivity(intent);
                       }else if (userVO.getRole().equals(UserVO.CSTR_USERROLE_MEDIAWORKER)){//媒体调解服务
                           Intent intent = new Intent(mContext, PersionActivity.class);
                           intent.putExtra(PersionActivity.CONTENT_PARAMETER_TYPE, PersionActivity.CONTENT_PARAMETER_MEDIA);
                           startActivity(intent);

                       }
            }

        }
    }

@RequiresApi(api = Build.VERSION_CODES.M)
private void setAdapetData() {
    gridLayoutManager=new GridLayoutManager(mContext,1);
    mRecyclerView.setLayoutManager(gridLayoutManager);
    mAdpater=new HomeAdpater(mContext,mDataList);
    mRecyclerView.setAdapter(mAdpater);
    mAdpater.setOnItemListener(new HomeAdpater.OnClickInfoServiceListener() {
        @Override
        public void onItemListener(View view) {
            gridLayoutManager.scrollToPositionWithOffset(2, 0);
        }
    });
    mXrefreshview.setXRefreshViewListener(new XRefreshView.SimpleXRefreshListener() {
        @Override
        public void onRefresh(boolean isPullDown) {

            loadNewData();
        }


        @Override
        public void onRelease(float direction) {
            super.onRelease(direction);
        }
    });
}
    /**
     * 读取数据
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void loadData()
    {
        mId=mContext.getResources().getStringArray(R.array.homeInfoID);
        clearDataList();
        //读取缓存
        List list = InfomationVO.loadVOList(InfomationVO.dataListFileName(mContext,HOMEID));
        if(list!=null&&!list.isEmpty())
        {
            addDataList(list);
        }
        setAdapetData();
        Boolean mustRefresh = true;
        //判断是否在有效期内
        if(mDataList!=null&&!mDataList.isEmpty())
        {
            InfomationVO vo;
            Object o = mDataList.get(0);
            if(o instanceof  InfomationVO)
            {
                vo = (InfomationVO)o;
                mXrefreshview.restoreLastRefreshTime(vo.getVoCreateDate().getTime());
                if(vo.isEffectiveTimeData(Constants.CINT_EFFECTIVE_NEWS_TIME))
                    mustRefresh =false;
            }
//            if(mDataList.size()%Constants.CINT_PAGE_SIZE==0)
//                // 设置是否可以上拉加载
//                mXrefreshview.setPullLoadEnable(true);
        }
        if(mustRefresh) {
            mXrefreshview.startRefresh();
        }
    }

    /**
     * 增加列表数据
     *
     * @param list
     */
    @SuppressWarnings({ "unchecked" })
    private void addDataList(List<?> list) {
        if (mDataList == null)
            clearDataList();
        if (list == null || list.isEmpty())
            return;
        mDataList.addAll(list);
    }

    /**
     * 清除数据
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private void clearDataList() {
        if (mDataList == null) {
            mDataList = new ArrayList();
        } else
            mDataList.clear();
    }
    /**
     * 清除通知数据
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private void clearNoticeDataList() {
        if (mNoticeDataList == null) {
            mNoticeDataList = new ArrayList();
        } else
            mNoticeDataList.clear();
    }
    /**
     * 刷新数据
     */
    protected void loadNewData()
    {
        if(mInProgess)
            return;
        //走马灯的数据刷新
            requestNoticeService();

        mInProgess=true;
        InfoService service = new InfoService(mContext);
        service.getList(mId[0], 1, null, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshview.stopRefresh();
                if(values==null||values.isEmpty()) {
                    T.showShort(mContext,content);
                    return;
                }

                ArrayList list = (ArrayList) values
                        .get(0);

                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                }
                //缓存数据
                InfomationVO.saveVOList(mDataList,InfomationVO.dataListFileName(mContext,HOMEID));
                    mXrefreshview.setLoadComplete(true);
                mAdpater.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshview.stopRefresh();
                T.showLong(mContext,msg);
            }
        });
    }



    /**
     * 聊天数据库变化监听
     */
    private class ChatObserver extends ContentObserver {
        public ChatObserver() {
            super(mChatHandler);
        }

        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            updateChatStatus();
        }
    }
//更新数据消息项
    private void updateChatStatus() {
        Observable<Boolean> observable = Observable.create(
                new ObservableOnSubscribe<Boolean>() {
                    @Override
                    public void subscribe(@NonNull ObservableEmitter<Boolean> e) throws Exception {
                       int num  = IMDBHelper.getInstance().getNoReadMessage(ApplicationSet.getInstance().getUserVO().getOpenfireLoginId());
                        if( mWrokImage.getVisibility()==View.VISIBLE){
                            mWrokList= getJaLawWorkVO(num);
                        }
                        if (mNum != num) {
                            if (mUnreadVO != null) {
                                mNum = num +Integer.parseInt(mUnreadVO.getTotalCount());
                            } else {
                                mNum = num;
                            }

                            e.onNext(true);
                        }

                    }
                }
        );
        Observer<Boolean> subscriber = new Observer<Boolean>() {
            @Override
            public void onSubscribe(@NonNull Disposable d) {

            }

            @Override
            public void onNext(Boolean b) {
                if (b) {
                    setBadgView(badgeView,mNum);
                }
            }

            @Override
            public void onError(Throwable t) {
                T.showLong(mContext, t.getMessage());
            }

            @Override
            public void onComplete() {
            }
        };
        observable.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(subscriber);
    }

    /**
     * 加载未读信息
     */
    private void loadNoread() {
        if (getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.getMessageNoRead(new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);

                if (values == null || values.isEmpty() || !(values.get(0) instanceof UnreadVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mUnreadVO = (UnreadVO) values.get(0);
                loadMessageNum();
            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext, msg);
            }
        });
    }



    @Override
    protected void onStop() {
        super.onStop();
        if (mAdpater != null && (mAdpater.getCentreModeConsultantButton() != null||mAdpater.getCentreModeSuppoButton() != null)) {
            if(mAdpater.getCentreModeConsultantButton()!=null&&mAdpater.getCentreModeConsultantButton().isOpen()) {
                mAdpater.getCentreModeConsultantButton().close(false);
            }
            if(mAdpater.getCentreModeSuppoButton()!=null&&mAdpater.getCentreModeSuppoButton().isOpen()){
                mAdpater.getCentreModeSuppoButton().close(false);
            }
        }
    }


    //显示对话框
    private void handlerPopWindosAdapter() {

        applyPopAdapter = new LawWorkPopAdapter(mWrokList, mContext);
        GridLayoutManager manager = new GridLayoutManager(mContext, 1);
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        applyPopAdapter.setItemCallback(new LawWorkPopAdapter.ItemCallback1() {
            @Override
            public void onItemClicked() {
                mShow.dismiss();
            }
        });
        if (mShow == null || !mShow.isShowing()) {
            mShow = new MaterialDialog.Builder(mContext)
                    .adapter(applyPopAdapter, manager)
                    .show();
        }
    }
    //获取工作数据
    private List<JaLawWorkVO> getJaLawWorkVO(int num){
        List<JaLawWorkVO> list=new ArrayList<>();
        JaLawWorkVO jaLawWorkVO_message=new JaLawWorkVO();
        JaLawWorkVO jaLawWorkVO_qwpf=new JaLawWorkVO();
        JaLawWorkVO jaLawWorkVO_gw=new JaLawWorkVO();
        JaLawWorkVO jaLawWorkVO_entrust=new JaLawWorkVO();
        JaLawWorkVO jaLawWorkVO_consult=new JaLawWorkVO();
        JaLawWorkVO jaLawWorkVO_more=new JaLawWorkVO();
        JaLawWorkVO jalawDutyLawyer=new JaLawWorkVO();
        jaLawWorkVO_message.setContent(getString(R.string.my_message));
        jaLawWorkVO_message.setType(1);
        if(mUnreadVO!=null){
            jaLawWorkVO_message.setNoReadNum(num+Integer.parseInt(mUnreadVO.getMessageCount()));
        }else{
            jaLawWorkVO_message.setNoReadNum(num);
        }
        jaLawWorkVO_qwpf.setContent(getString(R.string.law_team_problem));
        jaLawWorkVO_qwpf.setType(2);
        if(mUnreadVO!=null){
            jaLawWorkVO_qwpf.setNoReadNum(Integer.parseInt(mUnreadVO.getTeamLawCount()));
        }
        jaLawWorkVO_gw.setContent(getString(R.string.law_advise_problem));
        jaLawWorkVO_gw.setType(3);
        if(mUnreadVO!=null){
            jaLawWorkVO_gw.setNoReadNum(Integer.parseInt(mUnreadVO.getTeamVillageCount()));
        }
        jaLawWorkVO_entrust.setContent(getString(R.string.my_entrust));
        jaLawWorkVO_entrust.setType(4);
        if(mUnreadVO!=null){
            jaLawWorkVO_entrust.setNoReadNum(Integer.parseInt(mUnreadVO.getEntrustCount()));
        }
        jaLawWorkVO_consult.setContent(getString(R.string.my_consult2));
        jaLawWorkVO_consult.setType(5);
        if(mUnreadVO!=null){
            jaLawWorkVO_consult.setNoReadNum(Integer.parseInt(mUnreadVO.getConsultCount()));
        }
        jaLawWorkVO_more.setContent(getString(R.string.more));
        jaLawWorkVO_more.setType(6);

        jalawDutyLawyer.setContent(getString(R.string.duty_lawyer_problem));
        jalawDutyLawyer.setType(7);
        if(mUnreadVO!=null){
            jalawDutyLawyer.setNoReadNum(Integer.parseInt(mUnreadVO.getTeamDutyCount()));
        }
      if( ApplicationSet.getInstance().getUserVO()!=null &&
                ApplicationSet.getInstance().getUserVO().getRole()!=null&&
                ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_JALAW)){
            if( ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("1")&&
                    ApplicationSet.getInstance().getUserVO().getAdviserFlag().equals("true")){

                list.add(jaLawWorkVO_message);
                list.add(jaLawWorkVO_qwpf);
                list.add(jaLawWorkVO_gw);
                if(ApplicationSet.getInstance().getUserVO().getDutyFlag().equals("true")){
                    list.add(jalawDutyLawyer);
                }
                list.add(jaLawWorkVO_entrust);
                list.add(jaLawWorkVO_consult);
                list.add(jaLawWorkVO_more);
            }else if(ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("1")&&
                    !ApplicationSet.getInstance().getUserVO().getAdviserFlag().equals("true")){
                list.add(jaLawWorkVO_message);
                list.add(jaLawWorkVO_qwpf);
                if(ApplicationSet.getInstance().getUserVO().getDutyFlag().equals("true")){
                    list.add(jalawDutyLawyer);
                }
                list.add(jaLawWorkVO_entrust);
                list.add(jaLawWorkVO_consult);
                list.add(jaLawWorkVO_more);
            }else if(!ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("1")
                    &&ApplicationSet.getInstance().getUserVO().getAdviserFlag().equals("true")){
                list.add(jaLawWorkVO_message);
                list.add(jaLawWorkVO_gw);
                list.add(jaLawWorkVO_entrust);
                list.add(jaLawWorkVO_consult);
                list.add(jaLawWorkVO_more);
            }else {
                list.add(jaLawWorkVO_message);
                list.add(jaLawWorkVO_entrust);
                list.add(jaLawWorkVO_consult);
                list.add(jaLawWorkVO_more);
            }
        }
        return list;
    }
    private void addFloatBtn() {
        mWrokImage=FloatDragView.addFloatDragView(this, mMainLayout, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 点击事件
                handlerPopWindosAdapter();
            }
        });
    }
    /**
     * 通知公告数据请求
     */
    private void requestNoticeService( ) {
        LgavNoticeService noticeService = new LgavNoticeService(mContext);
        noticeService.queryLgavNoticeList(1, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                clearNoticeDataList();
                if (list != null && !list.isEmpty()) {
                    mNoticeDataList=list;
                    setTopNotice();
                } else {
                    marqueeLayout.setVisibility(View.GONE);
                    return;
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });

    }

    // 检查更新信息
    public void  checkUpdate(){
        CommonService updateService = new CommonService(this);
        updateService.getUpdateInfo(new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty() || !(values.get(0) instanceof JaUpdateVO)) {
                    //T.showLong(this, getString(R.string.get_error_noeffectdata));
                    return;
                }
                JaUpdateVO jaUpateVO= (JaUpdateVO) values.get(0);
                if(!getVersionCode().equals(jaUpateVO.getSversion())){
                    Intent dialogIntent = new Intent(getBaseContext(), UpdateActivity.class);
                    dialogIntent.putExtra(UPDATA,jaUpateVO);
                    dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getApplication().startActivity(dialogIntent);
                }

            }

            @Override
            public void onError(String msg, String content) {
                // T.showLong(mContext, msg);
            }
        });
    }
    private String getVersionCode() {
        PackageManager packageManager = HomeActivity.this.getPackageManager();
        try {
            PackageInfo info = packageManager.getPackageInfo(HomeActivity.this.getPackageName(), 0);
            String versionCode = info.versionName;
            return versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "";
        }
    }

}
