package com.lawyee.apppublic.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.vo.LgavSignsVO;
import com.lawyee.apppublic.widget.myDateView.DPCManager;
import com.lawyee.apppublic.widget.myDateView.DPDecor;
import com.lawyee.apppublic.widget.myDateView.DPMode;
import com.lawyee.apppublic.widget.myDateView.DatePicker2;
import com.lawyee.apppublic.widget.myDateView.MonthView;

import net.lawyee.mobilelib.utils.ScreenUtils;
import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class    SignedActivity extends BaseActivity {
    private RelativeLayout mRlSignedTotal;
    private RelativeLayout mRlSignedMonthTotal;
    private Context mContext;
    DatePicker2 picker;
    private Calendar mCalendar;
    private int mTotal = 0;//签到总数
    private int mMouthNum = 0;//签到本月总数
    private TextView mTvTotal;
    private TextView mTvMonthTotal;
    private LgavSignsVO mLgavSignsVO;
    private   int mNowYear;//当前年
    private  int mNowMonth;//当前月
    private String mLastDate="";
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_signed);
        mContext = this;
        mCalendar = Calendar.getInstance();
        mNowYear = mCalendar.get(Calendar.YEAR);
       mNowMonth = mCalendar.get(Calendar.MONTH)+1;
        initView();
       LoadSignedData(mNowYear,mNowMonth);
    }



    private void initView() {
        mRlSignedTotal = (RelativeLayout) findViewById(R.id.rl_signed_total);
        mRlSignedMonthTotal = (RelativeLayout) findViewById(R.id.rl_signed_month_total);
        mTvTotal= (TextView) findViewById(R.id.tv_total);
        mTvMonthTotal= (TextView) findViewById(R.id.tv_month_total);
        int screenwidth = ScreenUtils.getScreenWidth(mContext);
        RelativeLayout.LayoutParams OrgParams = (RelativeLayout.LayoutParams) mRlSignedTotal.getLayoutParams();
        OrgParams.width = (int) (screenwidth * 0.248);
        OrgParams.height = (int) (screenwidth * 0.248);
        mRlSignedTotal.setLayoutParams(OrgParams);
        RelativeLayout.LayoutParams InformationParams = (RelativeLayout.LayoutParams) mRlSignedMonthTotal.getLayoutParams();
        InformationParams.width = (int) (screenwidth * 0.14);
        InformationParams.height = (int) (screenwidth * 0.2);
        mRlSignedMonthTotal.setLayoutParams(InformationParams);
        picker = (DatePicker2) findViewById(R.id.myDatepick2);
        DPCManager.getInstance().clearnDATE_CACHE(); //清除cache
        picker.setMode(DPMode.NONE);
        picker.setFestivalDisplay(false); //是否显示节日
        picker.setTodayDisplay(false); //是否高亮显示今天
        picker.setHolidayDisplay(false); //是否显示假期
        picker.setDeferredDisplay(false); //是否显示补休
        picker.setActivated(false);
        picker.setDate(mNowYear, mNowMonth);
        picker.setFocusable(false);
        picker.setDPDecor(new DPDecor() {
            @Override
            public void drawDecorBG(Canvas canvas, Rect rect, Paint paint) {
                //设置画园的大小
                paint.setColor(ContextCompat.getColor(mContext,R.color.patrol_finish_blue));
                canvas.drawCircle(rect.centerX(), rect.centerY(), rect.width() / 4F, paint);
            }
        });
        picker.getMonthView().setMaxYear(mNowYear);
        picker.getMonthView().setMaxMonth(mNowMonth);
        picker.getMonthView().setOnDateScrollChangeListener(new MonthView.OnDateScrollChangeListener() {
            @Override
            public void scrollLeft(int year, int month) {
                LoadSignedData(year,month);

            }

            @Override
            public void scrollRight(int year, int month) {


                LoadSignedData(year,month);
            }

            @Override
            public void scrollTop(int year, int month) {


            }

            @Override
            public void scrollBottom(int year, int month) {

            }
        });
//        mRlSignedTotal.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //手动签到取消
//                loadTodaySigned();
//                }
//        });
        picker.invalidate();
    }

    //加载今日签到
    private void loadTodaySigned() {
        if(ApplicationSet.getInstance().getUserVO().getLastSignDate()!=null
                &&(ApplicationSet.getInstance().getUserVO().getLastSignDate().substring(0,10).equals(mLastDate))){
            T.showShort(mContext, R.string.already_sign);
            return;
        }
        if(getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.setProgressShowContent(mContext.getString(R.string.submit_ing));
        service.setShowProgress(true);
        service.postSigned(new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty() || !(values.get(0) instanceof LgavSignsVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mLgavSignsVO= (LgavSignsVO) values.get(0);
                bindDataToView(mNowYear,mNowMonth);
                if(mLgavSignsVO.getSignDates().size()>0) {
                  mLastDate=
                            mLgavSignsVO.getSignDates().get(0).getSignTime().substring(0,10);
                }
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
                String today=df.format(new Date());// new Date()为获取当前系统时间
                if(StringUtil.isEmpty(ApplicationSet.getInstance().getUserVO().getLastSignDate())||
                        (!StringUtil.isEmpty(ApplicationSet.getInstance().getUserVO().getLastSignDate())&&
                                !ApplicationSet.getInstance().getUserVO().getLastSignDate().substring(0,10).equals(today))){
                        if(mLgavSignsVO.getSignDates().size()>0) {
                            ApplicationSet.getInstance().getUserVO().setLastSignDate(
                                    mLgavSignsVO.getSignDates().get(0).getSignTime());
                        }
                        T.showShort(mContext, R.string.sign_success);
                    }
            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext, msg);
            }
        });

    }
    //查询所选日期签到
    private void LoadSignedData(final int year, final int month) {
        String signDate=year+"-"+addZero(month);

        if(getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.setProgressShowContent(mContext.getString(R.string.get_ing));
        service.setShowProgress(true);
        service.getSigned(signDate,new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty() || !(values.get(0) instanceof LgavSignsVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mLgavSignsVO= (LgavSignsVO) values.get(0);
                bindDataToView(year,month);


            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext, msg);
            }
        });
    }

//刷新日历视图
    private void bindDataToView(int year,int month) {

        if(!TextUtils.isEmpty(mLgavSignsVO.getTotalSign())){
            mTotal=Integer.parseInt(mLgavSignsVO.getTotalSign());
        }
        mTvTotal.setText(mTotal+"");

        if(mLgavSignsVO.getSignDates()!=null){
            mMouthNum=mLgavSignsVO.getSignDates().size();
            mTvMonthTotal.setText(mMouthNum+"");
            DPCManager.getInstance().clearnDATE_CACHE(); //清除cache
            List<String> tmp = new ArrayList<>();
            for(int i=0;i<mLgavSignsVO.getSignDates().size();i++){
                tmp.add(reduceZero(mLgavSignsVO.getSignDates().get(i).getSignTime().substring(0,10)));
            }
            picker.getMonthView().setNeedMonth(month);
            picker.getMonthView().setNeedYear(year);
            DPCManager.getInstance().setDecorBG(tmp);

            picker.setDPDecor(new DPDecor() {
                @Override
                public void drawDecorBG(Canvas canvas, Rect rect, Paint paint) {
                    paint.setColor(ContextCompat.getColor(mContext,R.color.patrol_finish_blue));
                    canvas.drawCircle(rect.centerX(), rect.centerY(), rect.width() / 4F, paint);
                }
            });
            picker.invalidate(); //刷新
        }else{
                mTvMonthTotal.setText("0");
        }

    }

    private String reduceZero(String str) {
        String date=str.substring(0,5);
        if(str.substring(5,6).equals("0")){
            date=date+str.substring(6,7);
        }else{
            date=date+str.substring(5,7);
        }
        if(str.substring(8,9).equals("0")){
            date=date+"-"+str.substring(9,10);
        }else{
            date=date+str.substring(7,10);
        }
        Log.e("czq",date+"");
        return date;
    }

    //月份加0
    private String addZero(int  month){
        if(month<10){
            return "0"+month;
        }
        return  month+"";
    }

}
