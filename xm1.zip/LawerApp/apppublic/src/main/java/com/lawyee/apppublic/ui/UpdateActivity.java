package com.lawyee.apppublic.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.vo.JaUpdateVO;

public class UpdateActivity extends Activity {
    public final static String UPDATA="updata";
    private AlertDialog show;
    private JaUpdateVO mjaUpateVO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        JaUpdateVO mjaUpateVO = (JaUpdateVO) intent.getSerializableExtra(UPDATA);
        if(mjaUpateVO==null){
            finish();
        }
        showDialog(mjaUpateVO);
    }

    private void showDialog(final JaUpdateVO jaUpateVO) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(UpdateActivity.this, android.R.style.Theme_Holo_Light_Dialog));
        LayoutInflater inflater = (LayoutInflater) UpdateActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View updateview = inflater.inflate(R.layout.dialog_updata_layout, null);
        TextView mTvApkSize = (TextView) updateview.findViewById(R.id.tv_NewApkSize);
        TextView mNewApkContent = (TextView) updateview.findViewById(R.id.tv_NewApkContent);
        TextView mNewServsion = (TextView) updateview.findViewById(R.id.tv_NewServsion);
        TextView mNowServsion = (TextView) updateview.findViewById(R.id.tv_NowServsion);
        TextView mNewTitle = (TextView) updateview.findViewById(R.id.tv_NewApktitle);
        Button future = (Button) updateview.findViewById(R.id.btn_future);
        Button force = (Button) updateview.findViewById(R.id.btn_force);
        mTvApkSize.setText(jaUpateVO.getFilesize());
        mNowServsion.setText(getVersionCode());
        mNewApkContent.setText(jaUpateVO.getUpdinfo());
        mNewServsion.setText(jaUpateVO.getSversion());
        mNewTitle.setText(R.string.newUpdatetitle);
        builder.setView(updateview);
        builder.setCancelable(false);
        show = builder.create();
        show.setCanceledOnTouchOutside(false);
        show.show();
        int code = Integer.parseInt(jaUpateVO.getUpdtype());
        switch (code) {
            case 1://以后再说提示
                future.setText(R.string.future);
                future.setOnClickListener(new View.OnClickListener() {//以后再说
                    @Override
                    public void onClick(View view) {
                        show.dismiss();
                        getFinish();
                    }
                });
                force.setText(R.string.nowUpdate);
                force.setOnClickListener(new View.OnClickListener() {//立即更新
                    @Override
                    public void onClick(View view) {
                        Intent intent= new Intent();
                        intent.setAction("android.intent.action.VIEW");
                        Uri content_url = Uri.parse(jaUpateVO.getFileurl());
                        intent.setData(content_url);
                        startActivity(intent);
                        show.dismiss();
                        getFinish();
                    }
                });
                break;
            case 2://必须更新提
                future.setVisibility(View.GONE);
                force.setText("确认");
                force.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent= new Intent();
                        intent.setAction("android.intent.action.VIEW");
                        Uri content_url = Uri.parse(jaUpateVO.getFileurl());
                        intent.setData(content_url);
                        startActivity(intent);
                        show.dismiss();
                        getFinish();
                    }
                });
                break;
            default:

                break;
        }
    }

    private void getFinish() {
        ApplicationSet.getInstance().finishAllActivity();
        UpdateActivity.this.finish();
    }

    /**
     *
     * @return 获取应用版本号
     */

    private String getVersionCode() {
        PackageManager packageManager = UpdateActivity.this.getPackageManager();
        try {
            PackageInfo info = packageManager.getPackageInfo(UpdateActivity.this.getPackageName(), 0);
            String versionCode = info.versionName;
            return versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "";
        }
    }
    /**
     * @return 获取应用名字
     */
    private String getApplicationName() {
        PackageManager packageManager = null;
        ApplicationInfo applicationInfo = null;
        try {
            packageManager = UpdateActivity.this.getPackageManager();
            applicationInfo = packageManager.getApplicationInfo(UpdateActivity.this.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            applicationInfo = null;
        }
        String applicationName =
                (String) packageManager.getApplicationLabel(applicationInfo);
        return applicationName;
    }
}
