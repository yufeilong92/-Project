package com.lawyee.apppublic.ui.frag.fragService;

import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.widget.TextView;

import com.afollestad.materialdialogs.GravityEnum;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavProblemService;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.ui.frag.fragService
 * @author: YFL
 * @date: 2017/7/26 16:25
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class BaseFragment extends Fragment {
    /**
     * 律师追答
     *
     */
    private static final String REPLYTYPE="1";
    /**
     * 律师回复
     */
    private static final String REPLYTYPEONE="0";
    public interface ResultIResultInfoListener {
        public void resultIResultInfoListener(ArrayList<Object> values, String content);
        public void resultIErrorResultInfoListener();

    }


    private ResultIResultInfoListener resultIResultInfoListener = null;

    public ResultIResultInfoListener getResultIResultInfoListener() {
        return resultIResultInfoListener;
    }

    public void setResultIResultInfoListener(ResultIResultInfoListener resultIResultInfoListener) {
        this.resultIResultInfoListener = resultIResultInfoListener;
    }

    protected String getTextStr(TextView tv) {
        String trim = tv.getText().toString().trim();
        if (!TextUtils.isEmpty(trim))
            return trim;
        return "";
    }

    protected MaterialDialog.Builder getShowDialog() {
        MaterialDialog.Builder builder = new MaterialDialog.Builder(getContext());
        builder
                .limitIconToDefaultSize() // limits the displayed icon size to 48dp
                .title("提示")
                .titleGravity(GravityEnum.CENTER)
                .titleColor(Color.RED)
                .content("内容提交后不能修改")
                .contentGravity(GravityEnum.CENTER)
                .positiveText(R.string.dl_btn_ok)
                .negativeText(R.string.dl_btn_cancel)
                .cancelable(false)
                .show();
        return builder;
    }

    /**
     * 提交评价
     * @param content  内容
     * @param isreplyType 类型  是否解答过
     * @param oid  问题id
     * @param resultIResultInfoListener
     */
    protected void submitService(String content,boolean isreplyType , String oid,final ResultIResultInfoListener resultIResultInfoListener) {
        LgavProblemService problemService = new LgavProblemService(getContext());
        problemService.setShowProgress(true);
        problemService.setProgressShowContent(getResources().getString(R.string.submit_ing));
        String replyType="";
        if (isreplyType){
            replyType=REPLYTYPE;
        }else {
            replyType=REPLYTYPEONE;
        }
        problemService.submitLgavPostReply( content,replyType, oid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values==null||values.isEmpty()){
                   T.showShort(getContext(),"提交失败");
                    return;
                }
                T.showShort(getContext(),R.string.submit_success);
                resultIResultInfoListener.resultIResultInfoListener(values, content);
            }
            @Override
            public void onError(String msg, String content) {
                T.showShort(getContext(), msg);
                resultIResultInfoListener.resultIErrorResultInfoListener();
            }
        });
    }

    /**
     *  查询我的问题
     * @param proId
     * @param listener
     */

    protected void queryMyProblemInfom(String proId, BaseJsonService.IResultInfoListener listener){
        LgavProblemService service = new LgavProblemService(getContext());
        service.queryLgavGetConsultDetail(proId,listener);
    }


}
