package com.lawyee.apppublic.ui.frag.fragService.media;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.ApplySeasonListPopAdapter;
import com.lawyee.apppublic.config.DataManage;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JamedUserService;
import com.lawyee.apppublic.ui.frag.fragService.BaseFragment;
import com.lawyee.apppublic.ui.lawAdministration.ShowInfomActivity;
import com.lawyee.apppublic.vo.BaseCommonDataVO;
import com.lawyee.apppublic.vo.JamedApplyDetailVO;
import com.lawyee.apppublic.vo.SelectItemVo;
import com.lawyee.apppublic.widget.ContentEditText;
import com.lawyee.apppublic.widget.RecycleViewDivider;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

import static com.lawyee.apppublic.util.RecyclerSelectItem.MoveToPostion;
/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  MediaTwoFragment.java
 * @Package com.lawyee.apppublic.ui.frag.fragService.media
 * @Description:    媒体筛选页
 * @author: YFL
 * @date:   2017/8/30 15:33
 * @version V 1.0 xxxxxxxx
 * @verdescript  版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/8/30 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MediaTwoFragment extends BaseFragment implements View.OnClickListener {
    /**
     * 机构oid
     */
    private static final String ARG_ORGID = "arg_orgid";
    /**
     * 调解显示状态
     */
    private static final String ARG_MEDIASTUTAS = "arg_mediastutas";
    /**
     * 媒体参与调解状态
     */
    private static final String ARG_MEDIAAPPLYTYPE = "arg_mediaapplytype";
    /**
     * 媒体是否调解成功
     */
    private static final String ARG_MEDIAFLAG = "arg_mediaflag";
    /**
     * 申请人数据详情
     */
    private static final String ARG_JAMEDDETAILVO = "arg_jameddetailvo";
    /**
     * 机构id
     */
    private String mOrgId;
    /**
     * 审核状态
     */
    private String mMediaStutas;
    private RadioButton mRdbMediaTwoPass;
    private RadioButton mRdbMediaTwoNopass;
    private ContentEditText mEtMediaTwoOtherExplain;
    private Button mBtnMediaTwoSubmit;
    /**
     * 是否同意媒体参与调解  1 同意 ，-1 不同意
     */
    private String mAgree = "";
    private static final String MPASS = "1";//同意
    private static final String MNOPASS = "-1";//不同意
    /**
     * 调解员发起人媒体调解
     */
    private static final String MJMAEDPEOPLE = "2";
    /**
     * 当事人发起人媒体调解
     */
    private static final String mMediaUser = "1";
    /**
     * 媒体发起人媒体调解
     */
    private static final String mMediaMedia = "3";
    private TextView mTvMediaTwoNoJoinPass;
    private TextView mTvMediatwoResultagree;
    private TextView mTvMediatwoResultreason;
    private TextView mTvMediatwoResultexplain;
    private TextView mTvMediaTwoMresultagree;
    private TextView mTvMediaTwoMreasultReason;
    private TextView mTvMediaTwoMreasultExplain;
    private LinearLayout mLinearMediaTwoResult;
    private List<BaseCommonDataVO> mNoHandlerLists;
    private MaterialDialog mPopWinowsShow;
    private SelectItemVo mSelectNoAgreeItem;
    private Context mContext;
    private LinearLayout mLinearMediaTwoApply;
    /**
     * 发起人
     */
    private String mMediaApplyType;
    private TextView mTvMediaTwoJamedAgree;
    /**
     * 是否勾选媒体调解
     */
    private boolean mMediaFlag;
    private LinearLayout mLinearMediaTwoMResult;
    private JamedApplyDetailVO mJamedDetailVo;

    /**
     *
     * @param orgid 机构oid
     * @param mediaStutas  调解状态
     * @param mediaApplyType 媒体调解发起人类型
     * @param mediaFlag 是否调解成功
     * @param jamedDetailVo 申请人详情
     * @return
     */
    public static MediaTwoFragment newInstance(String orgid, String mediaStutas, String mediaApplyType,
                                               boolean mediaFlag, JamedApplyDetailVO jamedDetailVo) {
        MediaTwoFragment fragment = new MediaTwoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ORGID, orgid);
        args.putString(ARG_MEDIASTUTAS, mediaStutas);
        args.putString(ARG_MEDIAAPPLYTYPE, mediaApplyType);
        args.putBoolean(ARG_MEDIAFLAG, mediaFlag);
        args.putSerializable(ARG_JAMEDDETAILVO, jamedDetailVo);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mOrgId = getArguments().getString(ARG_ORGID);
            mMediaStutas = getArguments().getString(ARG_MEDIASTUTAS);
            mMediaApplyType = getArguments().getString(ARG_MEDIAAPPLYTYPE);
            mMediaFlag = getArguments().getBoolean(ARG_MEDIAFLAG);
            mJamedDetailVo = (JamedApplyDetailVO) getArguments().getSerializable(ARG_JAMEDDETAILVO);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_media_two, container, false);
        initView(view);
        initAcceptSeasons();
        return view;
    }

    //初始化不同意原因
    private void initAcceptSeasons() {
        if (mNoHandlerLists == null || mNoHandlerLists.isEmpty()) {
            mNoHandlerLists = new ArrayList<>();
            List<BaseCommonDataVO> mNoHandlers = DataManage.getInstance().getmApplyJamedNoHandler();
            if (mNoHandlers != null && !mNoHandlers.isEmpty()) {
                mNoHandlerLists = mNoHandlers;
            }
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        handlerShowData();
        handlerData();
    }

    /**
     * 处理显示
     */
    private void handlerShowData() {
        if (!mMediaFlag) {
            if (mMediaApplyType == null || !mMediaApplyType.equals(MJMAEDPEOPLE)) {
                mTvMediaTwoJamedAgree.setVisibility(View.GONE);
            } else if (mMediaApplyType.equals(MJMAEDPEOPLE)) {
                mTvMediaTwoJamedAgree.setVisibility(View.VISIBLE);
            }
        }
        if (mJamedDetailVo == null) {
            requestServiceDatas();
        }
        if (mMediaStutas.equals(ShowInfomActivity.MSTATUSTWOORGAGREE)) {//机构受理
            if (mJamedDetailVo != null) {
                String applyMediaConfirm = mJamedDetailVo.getApplyMediaConfirm();
                String mediaApplyType = mJamedDetailVo.getMediaApplyType();
                int mediaConfirm = mJamedDetailVo.getMediaConfirm();
                if (mediaApplyType != null && mediaApplyType.equals(mMediaMedia) &&
                        (applyMediaConfirm.equals("1")||applyMediaConfirm.equals("-1"))) {//最终确认是否媒体调解
                    requestServiceData(false, true);
                } else if (mediaConfirm == 1 || mediaConfirm == -1) {//媒体是否同意参与
                    requestServiceData(false, true);
                } else {
                    requestServiceData(true, false);
                }
            }
        } else if (mMediaStutas.equals(ShowInfomActivity.MSTATUSTHREEORGNOAGREE)) {//机构不受理
            requestServiceData(false, false);
        } else if (mMediaStutas.equals(ShowInfomActivity.MSTATUSFOURMEDIAAGREE) || mMediaStutas.equals(ShowInfomActivity.MSTATUSFIVEMEIDANOAGREE) ||
                mMediaStutas.equals(ShowInfomActivity.MSTATUSSIXFINISH)) {//媒体已受理
            requestServiceData(false, true);
        } else {
            isShowResult(false, false, null);
        }

    }

    private void requestServiceDatas() {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setProgressShowContent(getString(R.string.get_ing));
        jamedUserService.setShowProgress(true);
        jamedUserService.getApplyDetail(mOrgId, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                JamedApplyDetailVO vo = (JamedApplyDetailVO) values.get(0);
                if (vo != null) {
                    mJamedDetailVo = vo;
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });
    }

    /**
     * @param isShowApply 是否显示申请页
     * @param isShow      是否显示筛选结果
     */
    private void requestServiceData(final boolean isShowApply, final boolean isShow) {
        if (mJamedDetailVo != null) {
            if (isShowApply) {
                isShowResult(false, isShow, mJamedDetailVo);
            } else {
                isShowResult(true, isShow, mJamedDetailVo);
            }
        }
    }

    private void handlerData() {
        mRdbMediaTwoPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {//媒体同意
                if (isChecked) {
                    mAgree = MPASS;
                    mTvMediaTwoNoJoinPass.setClickable(false);
                    if (mSelectNoAgreeItem != null) {
                        mSelectNoAgreeItem.setItemVo(null);
                        mSelectNoAgreeItem.setSelectPosition(-1);
                        mTvMediaTwoNoJoinPass.setText(getResources().getString(R.string.please_select_nopassreason));
                    }
                }
            }
        });
        mRdbMediaTwoNopass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {//媒体不同意
                if (isChecked) {
                    mAgree = MNOPASS;
                    mTvMediaTwoNoJoinPass.setClickable(true);
                }
            }
        });


    }

    private void initView(View view) {
        mContext = getActivity();
        mRdbMediaTwoPass = (RadioButton) view.findViewById(R.id.rdb_MediaTwo_Pass);
        mRdbMediaTwoNopass = (RadioButton) view.findViewById(R.id.rdb_MediaTwo_Nopass);
        mEtMediaTwoOtherExplain = (ContentEditText) view.findViewById(R.id.et_MediaTwo_OtherExplain);
        mBtnMediaTwoSubmit = (Button) view.findViewById(R.id.btn_mediaTwo_submit);
        mTvMediaTwoJamedAgree = (TextView) view.findViewById(R.id.tv_mediatwo_jamedagree);
        mBtnMediaTwoSubmit.setOnClickListener(this);
        mRdbMediaTwoNopass.setOnClickListener(this);
        mRdbMediaTwoPass.setOnClickListener(this);
        mTvMediaTwoNoJoinPass = (TextView) view.findViewById(R.id.tv_MediaTwo_NoJoinPass);
        mTvMediaTwoNoJoinPass.setOnClickListener(this);
        mTvMediatwoResultagree = (TextView) view.findViewById(R.id.tv_mediatwo_resultagree);
        mTvMediatwoResultagree.setOnClickListener(this);
        mTvMediatwoResultreason = (TextView) view.findViewById(R.id.tv_mediatwo_resultreason);
        mTvMediatwoResultreason.setOnClickListener(this);
        mTvMediatwoResultexplain = (TextView) view.findViewById(R.id.tv_mediatwo_resultexplain);
        mTvMediatwoResultexplain.setOnClickListener(this);
        mTvMediaTwoMresultagree = (TextView) view.findViewById(R.id.tv_MediaTwo_Mresultagree);
        mTvMediaTwoMresultagree.setOnClickListener(this);
        mTvMediaTwoMreasultReason = (TextView) view.findViewById(R.id.tv_MediaTwo_MreasultReason);
        mTvMediaTwoMreasultReason.setOnClickListener(this);
        mTvMediaTwoMreasultExplain = (TextView) view.findViewById(R.id.tv_MediaTwo_MreasultExplain);
        mTvMediaTwoMreasultExplain.setOnClickListener(this);
        mLinearMediaTwoResult = (LinearLayout) view.findViewById(R.id.linear_MediaTwo_Result);
        mLinearMediaTwoApply = (LinearLayout) view.findViewById(R.id.linear_mediatwo_apply);
        mLinearMediaTwoMResult = (LinearLayout) view.findViewById(R.id.linear_mediatwo_Mreasult);
        mLinearMediaTwoResult.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_mediaTwo_submit:
                submit();
                break;
            case R.id.tv_MediaTwo_NoJoinPass://不同意原因
                String str = getTextStr(mTvMediaTwoNoJoinPass);
                if (mNoHandlerLists != null && !mNoHandlerLists.isEmpty())
                    handlerPopWindos(mTvMediaTwoNoJoinPass, mNoHandlerLists, str, null);
                break;

        }
    }

    /**
     * @param tv     显示控件
     * @param mData  数据
     * @param nation 显示文字
     * @param type   类型
     */
    private void handlerPopWindos(final TextView tv, final List<BaseCommonDataVO> mData, final String nation, final String type) {
        final ApplySeasonListPopAdapter applyPopAdapter = new ApplySeasonListPopAdapter(mData, getContext());
        final GridLayoutManager manager = new GridLayoutManager(getContext(), 1);
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        if (mPopWinowsShow == null || !mPopWinowsShow.isShowing()) {
            mPopWinowsShow = new MaterialDialog.Builder(getContext())
                    .adapter(applyPopAdapter, manager)
                    .show();
            mPopWinowsShow.getRecyclerView().addItemDecoration(new RecycleViewDivider(getContext(), GridLayoutManager.VERTICAL, R.drawable.bg_rlv_diving));
        }
        if (!TextUtils.isEmpty(nation))
            applyPopAdapter.setSeletsStr(nation);
        if (mSelectNoAgreeItem == null) {
            mSelectNoAgreeItem = new SelectItemVo();
        }
        int selectPosition = mSelectNoAgreeItem.getSelectPosition();
        if (selectPosition != -1) {
            applyPopAdapter.setSeletsPosition(selectPosition);
            MoveToPostion(manager, mPopWinowsShow.getRecyclerView(), selectPosition);
        }
        applyPopAdapter.setOnRecyclerItemClickListener(new ApplySeasonListPopAdapter.OnRecyclerItemClickListener() {
            @Override
            public void OnItemClickListener(View view, BaseCommonDataVO itemVo, int position) {
                mSelectNoAgreeItem.setItemVo(itemVo);
                mSelectNoAgreeItem.setSelectPosition(position);
                tv.setText(itemVo.getName());
                mPopWinowsShow.dismiss();
            }
        });

    }


    private void submit() {
        final MediaTwoApplyVo vo = new MediaTwoApplyVo();
        if (TextUtils.isEmpty(mAgree)) {
            T.showShort(mContext, getString(R.string.pleaseSelectResult));
            return;
        }
        vo.setIsAgree(mAgree);
        if (mAgree.equals(MNOPASS)) {
            String reason = getTextStr(mTvMediaTwoNoJoinPass);
            if (TextUtils.isEmpty(reason) || reason.equals(getResources().getString(R.string.please_select_nopassreason))) {
                T.showShort(mContext, getString(R.string.please_select_nopassreason));
                return;
            } else {
                vo.setReason(mSelectNoAgreeItem.getItemVo().getOid());
            }
        }
        String explain = getTextStr(mEtMediaTwoOtherExplain);
        if (!TextUtils.isEmpty(explain)) {
            vo.setExplain(explain);
        }

        MaterialDialog.Builder showDialog = getShowDialog();
        showDialog.onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                submitService(vo);
                materialDialog.dismiss();

            }
        });
        showDialog.onNegative(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                materialDialog.dismiss();
            }
        });


    }

    private void submitService(MediaTwoApplyVo vo) {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setProgressShowContent(getString(R.string.submit_ing));
        jamedUserService.setShowProgress(true);
        jamedUserService.postMediaAccept(mOrgId, vo.getIsAgree(), vo.getExplain(), vo.getReason(), new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                JamedApplyDetailVO vo = (JamedApplyDetailVO) values.get(0);
                if (vo != null) {
                    int mediaConfirm = vo.getMediaConfirm();
                    ShowInfomActivity activity = (ShowInfomActivity) getActivity();
                    activity.selectNextBtnSet(false, false);
                    isShowResult(true, true, vo);
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });
    }

    /**
     * @param ishow          是否显示结果
     * @param isShowMreasult 显示筛选结果
     * @param vo
     */
    private void isShowResult(boolean ishow, boolean isShowMreasult, JamedApplyDetailVO vo) {
        if (!ishow) {
            mLinearMediaTwoApply.setVisibility(View.VISIBLE);
            mLinearMediaTwoResult.setVisibility(View.GONE);
            mLinearMediaTwoMResult.setVisibility(View.GONE);
            return;
        }
        mLinearMediaTwoResult.setVisibility(View.VISIBLE);//媒体参与信息结果
        mLinearMediaTwoApply.setVisibility(View.GONE);//媒体筛选
        if (isShowMreasult) {
            mLinearMediaTwoMResult.setVisibility(View.VISIBLE);//媒体筛选结果
        } else {
            mLinearMediaTwoMResult.setVisibility(View.GONE);
        }
        String mediaApplyType = vo.getMediaApplyType();
        String applyMediaConfirm = vo.getApplyMediaConfirm();
        if (mediaApplyType != null && mediaApplyType.equals("3") && !applyMediaConfirm.equals("0")) {//最终确认媒体参与
            mTvMediatwoResultagree.setText(getStringWithInt(1));
            mTvMediatwoResultreason.setText(DataManage.getInstance().getNameWithOid(vo.getMediaNoAcceptReason()));
            mTvMediatwoResultexplain.setText(vo.getMediaOpinion());
            mTvMediaTwoMresultagree.setText(vo.getStringWithApplyMediaConfirm());
            mTvMediaTwoMreasultReason.setText(DataManage.getInstance().getNameWithOid(vo.getApplynoAcceptReason()));
            mTvMediaTwoMreasultExplain.setText(vo.getApplyOpinion());
        }else {//正常的筛选
            mTvMediatwoResultagree.setText(getStringWithInt(vo.getMediaConfirm()));
            mTvMediatwoResultreason.setText(DataManage.getInstance().getNameWithOid(vo.getMediaNoAcceptReason()));
            mTvMediatwoResultexplain.setText(vo.getMediaOpinion());
            mTvMediaTwoMresultagree.setText(vo.getStringWithApplyMediaConfirm());
            mTvMediaTwoMreasultReason.setText(DataManage.getInstance().getNameWithOid(vo.getApplynoAcceptReason()));
            mTvMediaTwoMreasultExplain.setText(vo.getApplyOpinion());
        }
    }

    private static final class MediaTwoApplyVo {
        /**
         * 媒体筛选是否同意
         */
        private String isAgree;
        /**
         * 不同原因
         */
        private String reason;
        /**
         * 其它说明
         */
        private String explain;

        public String getIsAgree() {
            return isAgree;
        }

        public void setIsAgree(String isAgree) {
            this.isAgree = isAgree;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getExplain() {
            return explain;
        }

        public void setExplain(String explain) {
            this.explain = explain;
        }
    }

    /**
     * 筛选通过
     *
     * @param str
     * @return
     */
    private String getStringWithInt(int str) {
        String type = "";
        switch (str) {
            case 1:
                type = getString(R.string.yes);
                break;
            case -1:
                type = getString(R.string.no);
                break;
            default:
                break;
        }
        return type;
    }

}
