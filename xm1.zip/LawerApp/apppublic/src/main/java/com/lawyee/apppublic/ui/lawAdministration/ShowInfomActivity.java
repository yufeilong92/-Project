package com.lawyee.apppublic.ui.lawAdministration;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JamedUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.ui.frag.fragService.jamed.JamedFourFragment;
import com.lawyee.apppublic.ui.frag.fragService.jamed.JamedOneFragment;
import com.lawyee.apppublic.ui.frag.fragService.jamed.JamedThreeFragment;
import com.lawyee.apppublic.ui.frag.fragService.jamed.JamedTwoFragment;
import com.lawyee.apppublic.ui.frag.fragService.media.MediaFourFragment;
import com.lawyee.apppublic.ui.frag.fragService.media.MediaOneFragment;
import com.lawyee.apppublic.ui.frag.fragService.media.MediaThreeFragment;
import com.lawyee.apppublic.ui.frag.fragService.media.MediaTwoFragment;
import com.lawyee.apppublic.util.ObjectToList;
import com.lawyee.apppublic.vo.JamedApplyDetailVO;

import net.lawyee.mobilelib.utils.ScreenUtils;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  ShowInfomActivity.java 
 * @Package com.lawyee.apppublic.ui.lawAdministration   
 * @Description:    人民/媒体显示页
 * @author: YFL
 * @date:   2017/8/30 16:47
 * @version V 1.0 xxxxxxxx
 * @verdescript  版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/8/30 www.lawyee.com Inc. All rights reserved. 
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class ShowInfomActivity extends BaseActivity implements View.OnClickListener {
    /**
     * 传入参数(机构id)
     */
    public static final String CSTR_EXTRA_ORGID_ID = "orgid";
    /**
     * 媒体调解类型发起人1 当事人 2调解员 3 电视台
     */
    public static final String CONTENT_PARAMETER_MEDIAAPPLYTYPE = "mediaapplytype";
    private String mMediaApplyType;

    /**
     * 是否参与媒体调解
     */
    public static final String CONTENT_PARAMETER_MEDIAFLAG = "mediaFlag";
    private boolean mMediaFlag;
    /**
     * 是否可以参加媒体调解
     */
    public static final String CONTENT_PARAMETER_MEDIACONFIRM = "mMediaConfirm";
    private int mMediaConfirm;
    /**
     * 调解状态
     */
    public static final String CONTENT_PARAMETER_STATUS = "status";
    /**
     * 传递参数-类型
     */
    public static final String CONTENT_PARAMETER_TYPE = "type";
    /**
     * 传递参数-类型-人民调解
     */
    public static final String CONTENT_PARAMETER_JAMED = "jamed";
    /**
     * 传递参数-类型-媒体调解
     */
    public static final String CONTENT_PARAMETER_MEDIA = "media";
    private Button mBtnOne;
    private Button mBtnTwo;
    private Button mBtnThree;
    private Button mBtnFour;
    private FrameLayout mFlJamedLayuot;
    private Fragment mTtemFragment;
    private List<Fragment> mFragments;
    private List<String> mTabList;
    private Context mContext;
    private FragmentManager fm;
    private LinearLayout mLinearTab;
    //第一个按钮
    private static final int ZERO = 0;
    //第二个按钮
    private static final int ONE = 1;
    //第三个按钮
    private static final int TWO = 2;
    //第四个按钮
    private static final int THREE = 3;
    public static final String MSTATUSONEBEGIN = "0";//未审核
    public static final String MSTATUSTWOORGAGREE = "1";//机构受理
    public static final String MSTATUSTHREEORGNOAGREE = "-1";//机构不受理
    public static final String MSTATUSFOURMEDIAAGREE = "2";//媒体已受理
    public static final String MSTATUSFIVEMEIDANOAGREE = "-2";//媒体不受理
    public static final String MSTATUSSIXFINISH = "3";//调解结束

    /**
     * 按下的显示字体大小
     */
    private static final float PRESSSIZE = 18;
    /**
     * 正常的字体大小
     */
    private static final float NORMALSIZE = 12;
    private LinearLayout mLiJamedTitle;
    private TextView mIndicatorView;
    /**
     * 默认显示提示线宽度
     */
    private int i;
    private String mOrgId;
    private String mType;
    private String mMediaStatus;
    private static boolean mTwoIsChick = false;//true 能点击 ，false 不能点击
    private static boolean mThreeIsChick = false;//true 能点击 ，false 不能点击
    private static boolean mFourIsChick = false;//true 能点击 ，false 不能点击
    private int screenWidth;
    private String mPlayTime;
    private String mRecordTime;
    private JamedApplyDetailVO mJamedDetailVo;
    private String mApplyMediaConfirm;
    private int mOrgAcceptFlag;
    private int mSuccessFlag;

    enum JamedStutas {
        One, Two, Three, Four, Five, Six;

        public static void SelectStutas(JamedStutas jamedStutas) {
            switch (jamedStutas) {
                case One://未审核状体
                    mTwoIsChick = true;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Two://机构已受理
                    mTwoIsChick = true;
                    mThreeIsChick = false;
                    mFourIsChick = true;
                    break;
                case Three://机构不受理
                    mTwoIsChick = true;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Four://媒体已受理
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = true;
                    break;
                case Five://媒体不受理
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = true;
                    break;
                case Six://调解结束
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = true;
                    break;

                default:
                    break;
            }
        }
    }

    enum MediaStutas {
        One, Two, Three, Four, Five, Six, Service;

        public static void SelectStutas(MediaStutas mediaStutas) {
            switch (mediaStutas) {
                case One://未审核状体
                    mTwoIsChick = false;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Two://机构已受理
                    mTwoIsChick = true;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Three://机构不受理
                    mTwoIsChick = false;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Four://媒体已受理
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = true;
                    break;
                case Five://媒体不受理
                    mTwoIsChick = true;
                    mThreeIsChick = false;
                    mFourIsChick = false;
                    break;
                case Six://调解结束
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = true;
                    break;
                case Service://无录制信息
                    mTwoIsChick = true;
                    mThreeIsChick = true;
                    mFourIsChick = false;
                    break;

                default:
                    break;
            }
        }
    }

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_show_infom);
        initView();
        HanderData();
        requestApplyDetialData();
    }

    private void HanderData() {
        Intent intent = getIntent();
        mType = intent.getStringExtra(CONTENT_PARAMETER_TYPE);
        mOrgId = intent.getStringExtra(CSTR_EXTRA_ORGID_ID);
    }

    private void initView() {
        mContext = this;
        mBtnOne = (Button) findViewById(R.id.btn_one);
        mBtnTwo = (Button) findViewById(R.id.btn_two);
        mBtnThree = (Button) findViewById(R.id.btn_three);
        mBtnFour = (Button) findViewById(R.id.btn_four);
        mFlJamedLayuot = (FrameLayout) findViewById(R.id.fl_jamed_layuot);
        mBtnOne.setOnClickListener(this);
        mBtnTwo.setOnClickListener(this);
        mBtnThree.setOnClickListener(this);
        mBtnFour.setOnClickListener(this);
        mLinearTab = (LinearLayout) findViewById(R.id.linear_tab);
        mLinearTab.setOnClickListener(this);
        mLiJamedTitle = (LinearLayout) findViewById(R.id.li_jamed_title);
        mLiJamedTitle.setOnClickListener(this);
        mIndicatorView = (TextView) findViewById(R.id.indicator_view);
        mIndicatorView.setOnClickListener(this);
    }

    //请求网络数据
    private void requestApplyDetialData() {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setProgressShowContent(getString(R.string.get_ing));
        jamedUserService.setShowProgress(true);
        jamedUserService.getApplyDetail(mOrgId, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty()) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    mLinearTab.setVisibility(View.GONE);
                    return;
                }
                mJamedDetailVo = (JamedApplyDetailVO) values.get(0);
                if (mJamedDetailVo == null) {
                    mLinearTab.setVisibility(View.GONE);
                    return;
                }
                mRecordTime = mJamedDetailVo.getRecordTime();
                mPlayTime = mJamedDetailVo.getPlaytime();
                mMediaStatus = mJamedDetailVo.getStatus();
                mMediaConfirm = mJamedDetailVo.getMediaConfirm();
                mMediaFlag = mJamedDetailVo.isMediaFlag();
                mMediaApplyType = mJamedDetailVo.getMediaApplyType();
                mApplyMediaConfirm = mJamedDetailVo.getApplyMediaConfirm();
                mOrgAcceptFlag = mJamedDetailVo.getOrgAcceptFlag();
                mSuccessFlag = mJamedDetailVo.getSuccessFlag();
                bindViewData();
                mLinearTab.setVisibility(View.VISIBLE);
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
                setInProgess(false);
                mLinearTab.setVisibility(View.GONE);
            }
        });
    }


    private void bindViewData() {
        if (mType.equals(CONTENT_PARAMETER_MEDIA)) {//媒体
            selectShowMediaFragment();
            initMediaServiceData();
        } else if (mType.equals(CONTENT_PARAMETER_JAMED)) {//调解员
            selectShowJamedFragment();
            initJamedServieData();
        }
        selectBtnSet(mTwoIsChick, mThreeIsChick, mFourIsChick);
    }

    private void selectShowMediaFragment() {
        if (mMediaStatus.equals(MSTATUSONEBEGIN)) {//未审核
            MediaStutas.SelectStutas(MediaStutas.One);
        } else if (mMediaStatus.equals(MSTATUSTWOORGAGREE)) {//机构已受理
            if (mMediaApplyType == null) {
                MediaStutas.SelectStutas(MediaStutas.One);//无任何人发起媒体参与（包括媒体）
            } else {
                MediaStutas.SelectStutas(MediaStutas.Two);
            }
        } else if (mMediaStatus.equals(MSTATUSTHREEORGNOAGREE)) {//机构不受理
            MediaStutas.SelectStutas(MediaStutas.Three);
        } else if (mMediaStatus.equals(MSTATUSFOURMEDIAAGREE)) {//媒体已受理
            //最终是否调解成功
            if (mApplyMediaConfirm != null && mApplyMediaConfirm.equals("1")) {//媒体参与
                if (TextUtils.isEmpty(mRecordTime)) {//判断录制时间是否为空
                    MediaStutas.SelectStutas(MediaStutas.Service);
                } else if (!TextUtils.isEmpty(mRecordTime) && TextUtils.isEmpty(mPlayTime)) {//判断播出时间是否为空并且播出录制时间不为空
                    MediaStutas.SelectStutas(MediaStutas.Four);
                } else {
                    MediaStutas.SelectStutas(MediaStutas.Four);
                }
            } else if (mApplyMediaConfirm != null && mApplyMediaConfirm.equals("-1")||mApplyMediaConfirm.equals("0")) {//媒体不参与
                MediaStutas.SelectStutas(MediaStutas.Five);
            } else {
                MediaStutas.SelectStutas(MediaStutas.Four);
            }
        } else if (mMediaStatus.equals(MSTATUSFIVEMEIDANOAGREE)) {//媒体不受理
            MediaStutas.SelectStutas(MediaStutas.Five);
        } else if (mMediaStatus.equals(MSTATUSSIXFINISH)) {//调解结束
            if (mOrgAcceptFlag == 1 && mMediaConfirm == 0) {//机构受理
                mMediaStatus = MSTATUSTWOORGAGREE;
                if (mMediaApplyType == null) {
                    MediaStutas.SelectStutas(MediaStutas.One);//无任何人发起媒体参与（包括媒体）
                } else {
                    MediaStutas.SelectStutas(MediaStutas.Two);
                }
            } else if (mOrgAcceptFlag == -1 && mMediaConfirm == 0) {//机构不受理
                mMediaStatus = MSTATUSTHREEORGNOAGREE;
                MediaStutas.SelectStutas(MediaStutas.Three);
            } else if (mMediaConfirm == 1) {//媒体受理
                //最终是否调解成功
                mMediaStatus = MSTATUSFOURMEDIAAGREE;
                if (mApplyMediaConfirm != null && mApplyMediaConfirm.equals("1")) {//媒体参与
                    if (TextUtils.isEmpty(mRecordTime)) {//判断录制时间
                        MediaStutas.SelectStutas(MediaStutas.Service);
                    } else if (!TextUtils.isEmpty(mRecordTime) && TextUtils.isEmpty(mPlayTime)) {//判断播出时间
                        MediaStutas.SelectStutas(MediaStutas.Four);
                    } else {
                        MediaStutas.SelectStutas(MediaStutas.Six);
                    }
                } else if (mApplyMediaConfirm != null && ( mApplyMediaConfirm.equals("0")||mApplyMediaConfirm.equals("-1"))) {//媒体不参与或未确认
                    MediaStutas.SelectStutas(MediaStutas.Five);
                }else {
                    MediaStutas.SelectStutas(MediaStutas.Four);
                }
            } else if (mMediaConfirm == -1) {//媒体不受理
                mMediaStatus = MSTATUSFIVEMEIDANOAGREE;
                MediaStutas.SelectStutas(MediaStutas.Five);
            } else if (mApplyMediaConfirm.equals("-1")) {//最终没有同意媒体调解
                MediaStutas.SelectStutas(MediaStutas.Five);
            } else {
                MediaStutas.SelectStutas(MediaStutas.Six);
            }
        }
    }

    private void selectShowJamedFragment() {
        if (mMediaStatus.equals(MSTATUSONEBEGIN)) {//未审核
            JamedStutas.SelectStutas(JamedStutas.One);
        } else if (mMediaStatus.equals(MSTATUSTWOORGAGREE)) {//机构已受理
            if (mMediaApplyType != null && mMediaApplyType.equals("3")) {
                JamedStutas.SelectStutas(JamedStutas.Four);
            } else {
                JamedStutas.SelectStutas(JamedStutas.Two);
            }
        } else if (mMediaStatus.equals(MSTATUSTHREEORGNOAGREE)) {//机构不受理

            JamedStutas.SelectStutas(JamedStutas.Three);
        } else if (mMediaStatus.equals(MSTATUSFOURMEDIAAGREE)) {//媒体已受理
            if (mSuccessFlag == 1 || mSuccessFlag == -1) {
                mMediaStatus = MSTATUSSIXFINISH;
                JamedStutas.SelectStutas(JamedStutas.Four);
            } else if (mSuccessFlag == 0) {
                JamedStutas.SelectStutas(JamedStutas.Four);
            }
        } else if (mMediaStatus.equals(MSTATUSFIVEMEIDANOAGREE)) {//媒体不受理
            JamedStutas.SelectStutas(JamedStutas.Five);
        } else if (mMediaStatus.equals(MSTATUSSIXFINISH)) {//调解结束
            if (mMediaConfirm == 0) {
                JamedStutas.SelectStutas(JamedStutas.Two);
            } else
                JamedStutas.SelectStutas(JamedStutas.Six);
        }
    }

    private void initMediaServiceData() {
        if (mTabList == null) {
            mTabList = new ArrayList<>();
            mTabList = ObjectToList.ArrayToList(mContext, R.array.MediaServicetab);
        } else {
            mTabList.clear();
            mTabList = ObjectToList.ArrayToList(mContext, R.array.jamedServicetab);
        }
        setTabName();
        if (mFragments == null) {
            mFragments = new ArrayList<>();
        } else {
            mFragments.clear();
        }
        MediaOneFragment oneFragment = MediaOneFragment.newInstance(mOrgId, mJamedDetailVo, mMediaStatus);

        MediaTwoFragment twoFragment = MediaTwoFragment.newInstance(mOrgId, mMediaStatus, mMediaApplyType, mMediaFlag, mJamedDetailVo);

        MediaThreeFragment threeFragment = MediaThreeFragment.newInstance(mOrgId, mMediaStatus, mJamedDetailVo);

        MediaFourFragment fourFragment = MediaFourFragment.newInstance(mOrgId, mJamedDetailVo);
        mFragments.add(oneFragment);
        mFragments.add(twoFragment);
        mFragments.add(threeFragment);
        mFragments.add(fourFragment);
        addFragment();
    }


    private void initJamedServieData() {
        if (mTabList == null) {
            mTabList = new ArrayList<>();
            mTabList = ObjectToList.ArrayToList(mContext, R.array.jamedServicetab);
        } else {
            mTabList.clear();
            mTabList = ObjectToList.ArrayToList(mContext, R.array.jamedServicetab);
        }
        setTabName();
        if (mFragments == null) {
            mFragments = new ArrayList<>();
        } else {
            mFragments.clear();
        }
        JamedOneFragment oneFragment = JamedOneFragment.newInstance(mOrgId, mJamedDetailVo);

        JamedTwoFragment twoFragment = JamedTwoFragment.newInstance(mMediaFlag, mOrgId, mMediaStatus, mJamedDetailVo);

        JamedThreeFragment threeFragment = JamedThreeFragment.newInstance(mOrgId, mMediaApplyType, mMediaStatus, mMediaFlag, mJamedDetailVo);

        JamedFourFragment fourFragment = JamedFourFragment.newInstance(mOrgId, mMediaStatus, mJamedDetailVo);
        mFragments.add(oneFragment);
        mFragments.add(twoFragment);
        mFragments.add(threeFragment);
        mFragments.add(fourFragment);
        addFragment();


    }

    /**
     * 添加fragment
     */
    private void addFragment() {
        fm = getSupportFragmentManager();

        for (int i = 0; i < mFragments.size(); i++) {
            fm.beginTransaction().add(R.id.fl_jamed_layuot, mFragments.get(i)).hide(mFragments.get(i)).commit();
        }
        fm.beginTransaction().show(mFragments.get(0)).commit();
        selectFragment(0);
        screenWidth = ScreenUtils.getScreenWidth(mContext);
        i = screenWidth / 4;
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) mIndicatorView.getLayoutParams();
        params.width = i;
        mIndicatorView.setLayoutParams(params);
    }
  // 设置标题名字
    private void setTabName() {
        for (int i = 0; i < mLinearTab.getChildCount(); i++) {
            Button btn = (Button) mLinearTab.getChildAt(i);
            btn.setText(mTabList.get(i));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_one://第一个按钮
                selectFragment(0);
                break;
            case R.id.btn_two://第二个按钮
                selectFragment(1);
                break;
            case R.id.btn_three://第三个按钮
                selectFragment(2);
                break;
            case R.id.btn_four://第四个按钮
                selectFragment(3);
                break;
        }
    }

    /**
     * 使用hide和show方法切换Fragment
     *
     * @param fragmentfrom 隐藏fragment
     * @param fragmentto   需要切换的fragment
     */
    private void switchFragment(Fragment fragmentfrom, Fragment fragmentto) {

        if (fragmentto != mTtemFragment) {
            FragmentTransaction bt = fm.beginTransaction();
            if (!fragmentto.isAdded()) {
                bt.hide(fragmentfrom)
                        .add(R.id.fl_jamed_layuot, fragmentto).commit();
            } else {
                bt.hide(fragmentfrom)
                        .show(fragmentto).commit();
            }
            mTtemFragment = fragmentto;
        }
    }

    /**
     *  选择fragment是否显示
     * @param position
     */
    private void selectFragment(int position) {
        for (int i = 0; i < mFragments.size(); i++) {
            Fragment fragment = mFragments.get(i);
            boolean visible = fragment.isVisible();
            if (visible) {
                switchFragment(fragment, mFragments.get(position));
            }
        }
        setAnimator(position);

    }

    /**
     *  设置动画
     * @param position 第几个按钮
     */
    private void setAnimator(int position) {
        int press = R.color.color_hei;
        int normal = R.color.red_org;
        mBtnOne.setTextSize(position == ZERO ? PRESSSIZE : NORMALSIZE);
        mBtnTwo.setTextSize(position == ONE ? PRESSSIZE : NORMALSIZE);
        mBtnThree.setTextSize(position == TWO ? PRESSSIZE : NORMALSIZE);
        mBtnFour.setTextSize(position == THREE ? PRESSSIZE : NORMALSIZE);
        int width = i;
        float two = mBtnTwo.getX();
        int twoWith = mBtnTwo.getWidth();
        float three = mBtnThree.getX();
        int threeWidth = mBtnThree.getWidth();
        float four = mBtnFour.getX();
        int fourWith = mBtnFour.getWidth();
        float mover = 0;
        switch (position) {
            case 0:
                mover = 0;
                break;
            case 1:
                mover = two;
                width = twoWith;
                break;
            case 2:
                mover = three;
                width = (int) threeWidth;
                break;
            case 3:
                mover = four;
                width = (int) (screenWidth - four);
                break;
            default:
                mover = width;
                break;
        }
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) mIndicatorView.getLayoutParams();
        params.width = (int) width;
        mIndicatorView.setLayoutParams(params);
        float translationX = mIndicatorView.getTranslationX();
        ObjectAnimator animator = ObjectAnimator.ofFloat(mIndicatorView, "translationX", translationX, mover);
        animator.setDuration(300);
        animator.start();
        final float finalMover = mover;
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mIndicatorView.setX(finalMover);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        mBtnOne.setTextColor(position == ZERO ? getResources().getColor(normal) : getResources().getColor(press));
        if (mTwoIsChick) {
            mBtnTwo.setTextColor(position == ONE ? getResources().getColor(normal) : getResources().getColor(press));
        }
        if (mThreeIsChick) {
            mBtnThree.setTextColor(position == TWO ? getResources().getColor(normal) : getResources().getColor(press));
        }
        if (mFourIsChick) {
            mBtnFour.setTextColor(position == THREE ? getResources().getColor(normal) : getResources().getColor(press));
        }
    }

    /**
     * @param two
     * @param three
     * @param four
     */
    public void selectBtnSet(boolean two, boolean three, boolean four) {
        mBtnTwo.setClickable(two);
        mBtnThree.setClickable(three);
        mBtnFour.setClickable(four);
        mBtnTwo.setTextColor(two ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mBtnThree.setTextColor(three ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mBtnFour.setTextColor(four ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mTwoIsChick = two;
        mThreeIsChick = three;
        mFourIsChick = four;
    }

    /**
     * @param three
     * @param four
     */
    public void selectNextBtnSet(boolean three, boolean four) {
        mBtnThree.setClickable(three);
        mBtnFour.setClickable(four);
        mBtnThree.setTextColor(three ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mBtnFour.setTextColor(four ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mThreeIsChick = three;
        mFourIsChick = four;
    }

    /**
     * @param four
     */
    public void selectNextFourBtnSet(boolean four) {
        mBtnFour.setClickable(four);
        mBtnFour.setTextColor(four ? getResources().getColor(R.color.color_hei) : getResources().getColor(R.color.btn_focused_false));
        mFourIsChick = four;
    }

}
