package com.lawyee.apppublic.ui.lawyerService;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.LawyerDetailAdpater;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.util.BaseCommonToStringUtil;
import com.lawyee.apppublic.util.UrlUtil;
import com.lawyee.apppublic.vo.BaseCommonDataVO;
import com.lawyee.apppublic.vo.JalawLawyerDetailVO;
import com.lawyee.apppublic.vo.JalawLawyerVO;
import com.lawyee.apppublic.vo.UserVO;
import com.nostra13.universalimageloader.core.ImageLoader;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

import am.widget.wraplayout.WrapLayout;

import static com.lawyee.apppublic.R.id.tv_lawyer_name;
import static com.lawyee.apppublic.ui.lawyerService.SessionActivity.CSTR_EXTRA_SESSION_STR;
import static com.lawyee.apppublic.util.ToLoginDialogUtil.alertTiptoLogin;
import static com.lawyee.apppublic.util.ToLoginDialogUtil.alertToLogin;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @Title: 标题
 * @Package com.lawyee.apppublic.ui.lawyerService
 * @Description: 律师详情页面
 * @author:czq
 * @date: 2017/5/31
 * @verdescript 2017/5/31  czq 初建
 * @Copyright: 2017/5/31 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class LawyerDetailActivity extends BaseActivity {
    public final static String JALAWLAWYERVO = "JalawLawyerVO";//传递JalawLawyerVO的标识
    private ImageView mIvLawyerAvatar;
    private TextView mTvConsult;
    private TextView mTvLawyerName;
    private TextView mTvOffice;
    private TextView mTvArea1;

    private RecyclerView mRvLawyer;
    private LawyerDetailAdpater mAdpater;
    private JalawLawyerDetailVO mJalawLawyerDetailVO;
    private JalawLawyerVO mJalawLawyerVO;
    private Context mContext;
    private WrapLayout mWly_lyt_warp;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lawyer_detail);
        mContext = this;
        initView();
    }

    private void initView() {
        mIvLawyerAvatar = (ImageView) findViewById(R.id.iv_lawyer_avatar);
        mTvConsult = (TextView) findViewById(R.id.tv_consult);
        mTvLawyerName = (TextView) findViewById(tv_lawyer_name);
        mTvOffice = (TextView) findViewById(R.id.tv_office);
        mTvArea1 = (TextView) findViewById(R.id.tv_area1);
        mWly_lyt_warp= (WrapLayout) findViewById(R.id.wly_lyt_warp);

        mRvLawyer = (RecyclerView) findViewById(R.id.rv_lawyer);
        mTvConsult.setVisibility(View.INVISIBLE);
        initData();
        String imageUrl = mJalawLawyerVO.getPhoto();
        if (!TextUtils.isEmpty(imageUrl)) {
            ImageLoader.getInstance().displayImage(UrlUtil.getImageFileUrl(mContext, imageUrl), mIvLawyerAvatar, ApplicationSet.CDIO_LAW);
        } else {
            mIvLawyerAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
        mTvLawyerName.setText(mJalawLawyerVO.getName() + "    " + mContext.getString(R.string.lawyer));
        mTvOffice.setText(mJalawLawyerVO.getLawfirmName());
        BaseCommonDataVO baseCommonDataVO = BaseCommonDataVO.findDataVOWithOid(ApplicationSet.getInstance().getAreas(), mJalawLawyerVO.getCity());
        String city = "";
        if (baseCommonDataVO != null) {
            city = baseCommonDataVO.getName();
        }
        BaseCommonDataVO baseCommonDataVO1 = BaseCommonDataVO.findDataVOWithOid(ApplicationSet.getInstance().getAreas(), mJalawLawyerVO.getCounty());
        String country = "";
        if (baseCommonDataVO1 != null) {
            country = baseCommonDataVO1.getName();
        }
        mTvArea1.setText(city + " " + country);
        if (mJalawLawyerVO.getBusiness() != null && mJalawLawyerVO.getBusiness().size() > 0) {
            for(int i=0;i<mJalawLawyerVO.getBusiness().size();i++){
                TextView textView = (TextView) getLayoutInflater().inflate(R.layout.layout_law_serivce_tv, null);
                textView.setText(BaseCommonToStringUtil.toString(mJalawLawyerVO.getBusiness().get(i).getBusiness()));
                textView.measure(0, 0);
                mWly_lyt_warp.addView(textView);
            }
        }

        mTvConsult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserVO userVO = ApplicationSet.getInstance().getUserVO();
                if(userVO==null|| StringUtil.isEmpty(userVO.getLoginId())) {
                        alertToLogin(mContext);

                }else {
                    if(!userVO.isPublicUser()){
                            alertTiptoLogin(mContext);
                    }else{
                            Intent intent = new Intent(mContext, SessionActivity.class);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR, mJalawLawyerVO.getName());
                            intent.putExtra(CSTR_EXTRA_SESSION_STR, mJalawLawyerVO.getOid());
                            startActivity(intent);
                    }

                }
            }
        });
    }

    //初始化数据
    private void initData() {
        mJalawLawyerVO = (JalawLawyerVO) getIntent().getSerializableExtra(JALAWLAWYERVO);
        if (mJalawLawyerVO == null) {
            finish();
        }
        LoadData(mJalawLawyerVO.getOid());
    }

    /**
     * 加载律师详情数据
     *
     * @param id 律师ID
     */
    private void LoadData(String id) {
        if (getInProgess())
            return;
        setInProgess(true);
        JalawService service = new JalawService(mContext);
        service.setProgressShowContent(getString(R.string.get_ing));
        service.setShowProgress(true);
        service.getLawyerDetail(id, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty() || !(values.get(0) instanceof JalawLawyerDetailVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mJalawLawyerDetailVO = (JalawLawyerDetailVO) values.get(0);
                if(mJalawLawyerDetailVO.getUserOnLine().equals("online")){
                    mTvConsult.setVisibility(View.VISIBLE);
                }else{
                    mTvConsult.setVisibility(View.INVISIBLE);
                }
                mRvLawyer.setVisibility(View.VISIBLE);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 1);
                mRvLawyer.setLayoutManager(gridLayoutManager);
                mAdpater = new LawyerDetailAdpater(mContext, mJalawLawyerDetailVO);
                mRvLawyer.setAdapter(mAdpater);
            }

            @Override
            public void onError(String msg, String content) {
                T.showLong(mContext, msg);
                setInProgess(false);
            }
        });
    }



}
