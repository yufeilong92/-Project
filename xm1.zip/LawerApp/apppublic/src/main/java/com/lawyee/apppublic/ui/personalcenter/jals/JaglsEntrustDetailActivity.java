package com.lawyee.apppublic.ui.personalcenter.jals;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.MyJaglsEntrustDetailAdpater;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JaglsUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.JaglsEntrustDetailVO;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  标题
 * @Package com.lawyee.apppublic.ui.personalcenter.lawyer
 * @Description:    法律工作者-我的委托详情
 * @author:lzh
 * @date:   2017/10/24
 * @version
 * @verdescript   2017/10/24  lzh 初建
 * @Copyright: 2017/10/24 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class JaglsEntrustDetailActivity extends BaseActivity {
    public final static String JAGLSENTRUSTDETAIL="JaglsEntrustDetail";//跳转进入LawyerEntrustDetailActivity的标识

    private JaglsEntrustDetailVO mJaglsEntrustDetailVO;// 法律工作者委托详情VO
    private MyJaglsEntrustDetailAdpater mAdpater;
    private String  mOid;
    private RecyclerView rv_entrust_detail;
    private Context mContext;
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_jals_entrust_detail);
        mContext=this;
        mOid= (String) getIntent().getSerializableExtra(JAGLSENTRUSTDETAIL);
        if(mOid==null||mOid.equals("")){
            finish();
        }
        rv_entrust_detail= (RecyclerView) findViewById(R.id.rv_entrust_detail);
        loadData();
    }



    @Override
    protected void onResume() {
        super.onResume();
    }

    private void loadData() {
        if(getInProgess())
            return;
        setInProgess(true);
        JaglsUserService service = new JaglsUserService(this);
        service.setProgressShowContent(mContext.getString(R.string.get_ing));
        service.setShowProgress(true);
        service.getEntrustDetail(mOid,  new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if(values==null||values.isEmpty()||!(values.get(0) instanceof JaglsEntrustDetailVO))
                {
                    T.showLong(mContext,getString(R.string.get_error_noeffectdata));
                    return;
                }
                mJaglsEntrustDetailVO  = (JaglsEntrustDetailVO)values.get(0);

                GridLayoutManager gridLayoutManager=new GridLayoutManager(mContext,1);
                rv_entrust_detail.setLayoutManager(gridLayoutManager);
                if(!StringUtil.isEmpty(mJaglsEntrustDetailVO.getEvaluateTime())){
                    mAdpater=new MyJaglsEntrustDetailAdpater(mContext,mJaglsEntrustDetailVO,3);
                }else {
                    mAdpater=new MyJaglsEntrustDetailAdpater(mContext,mJaglsEntrustDetailVO,2);
                }

                rv_entrust_detail.setAdapter(mAdpater);
            }

            @Override
            public void onError(String msg, String content) {
                T.showLong(mContext,msg);
                setInProgess(false);
            }
        });
    }

}
