package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.ui.BaseActivity;
import com.zhy.view.flowlayout.FlowLayout;
import com.zhy.view.flowlayout.TagAdapter;
import com.zhy.view.flowlayout.TagFlowLayout;

public class EditHomePageActivity extends BaseActivity {


    private TextView mTvSave;
    private ImageView mIvLawyerAvatar;
    private TextView mTvLawyerName;
    private TextView mTextView15;
    private TextView mTvOffice;
    private EditText mEtModifyPhone;
    private TextView mTvArea2;
    private TextView mTvPracticeCertificateNumber;
    private TextView mTvWorkYear;
    private TagFlowLayout mIdFlowlayout;
    private ImageView mIvBottom1;
    private TextView mTvLawyerIntro;
    private TextView mTvPackUp1;
    private LinearLayout mLlBottomDetail1;
    private TextView mTvLawyerIntro2;
    private String[] mVals = new String[]
            {"遗嘱继承", "遗嘱继承", "遗嘱继承", "遗嘱继承", "遗嘱继承", "遗嘱继承",
                    "遗嘱继承", "遗嘱继承", "遗嘱继承", "遗嘱继承", "遗嘱继承",
                    "遗嘱继承"};
    private EditText mEtInput;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_edit_home_page);
        initView();
        final LayoutInflater mInflater = LayoutInflater.from(this);
        if (mIdFlowlayout != null) {
            mIdFlowlayout.setAdapter(new TagAdapter<String>(mVals) {
                @Override
                public View getView(FlowLayout parent, int position, String s) {
                    TextView tv = (TextView) mInflater.inflate(R.layout.tv,
                            mIdFlowlayout, false);
                    tv.setText(s);
                    return tv;
                }
            });
        }
    }
    public void onToolbarClick(View view) {

    }
    private void initView() {
        mIdFlowlayout = (TagFlowLayout) findViewById(R.id.id_flowlayout);
        mTvSave = (TextView) findViewById(R.id.tv_save);
        mIvLawyerAvatar = (ImageView) findViewById(R.id.iv_lawyer_avatar);
        mTvLawyerName = (TextView) findViewById(R.id.tv_lawyer_name);
        mTvOffice = (TextView) findViewById(R.id.tv_office);
        mEtModifyPhone = (EditText) findViewById(R.id.et_modify_phone);
        mTvArea2 = (TextView) findViewById(R.id.tv_area2);
        mTvPracticeCertificateNumber = (TextView) findViewById(R.id.tv_practice_certificate_number);
        mTvWorkYear = (TextView) findViewById(R.id.tv_work_year);
        mIvBottom1 = (ImageView) findViewById(R.id.iv_bottom1);
        mTvLawyerIntro = (TextView) findViewById(R.id.tv_lawyer_intro);
        mTvPackUp1 = (TextView) findViewById(R.id.tv_pack_up1);
        mLlBottomDetail1 = (LinearLayout) findViewById(R.id.ll_bottom_detail1);
        mTvLawyerIntro2 = (TextView) findViewById(R.id.tv_lawyer_intro2);
        mEtInput= (EditText) findViewById(R.id.et_input);
    }


}
