package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.RadarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.RadarData;
import com.github.mikephil.charting.data.RadarDataSet;
import com.github.mikephil.charting.data.RadarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IRadarDataSet;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.util.BaseCommonToStringUtil;
import com.lawyee.apppublic.util.TextViewUtil;
import com.lawyee.apppublic.util.UrlUtil;
import com.lawyee.apppublic.vo.BaseCommonDataVO;
import com.lawyee.apppublic.vo.JalawLawyerDetailVO;
import com.lawyee.apppublic.widget.RadarMarkerView;
import com.nostra13.universalimageloader.core.ImageLoader;

import net.lawyee.mobilelib.utils.T;
import net.lawyee.mobilelib.utils.TimeUtil;

import java.util.ArrayList;

import material.danny_jiang.com.mcoysnaplibrary.page.McoyScrollSnapPage;
import material.danny_jiang.com.mcoysnaplibrary.widget.McoySnapPageLayout;

public class LawHomePageActivity extends BaseActivity implements View.OnClickListener {
    private RadarChart mChart;
    protected Typeface mTfLight;
    private JalawLawyerDetailVO mJalawLawyerDetailVO;
    private Context mContext;
    private McoySnapPageLayout mcoySnapPageLayout = null;
    private ImageView mIvLawyerAvatar;
    private TextView mTvLawyerName;
    private TextView mTvOffice;
    private TextView mTvServicePhone;
    private TextView mTvArea2;
    private TextView mTvPracticeCertificateNumber;
    private TextView mTextView7;
    private TextView mTvWorkYear;
    private TextView mTvSpecialityTip1;
    private TextView mTvSpecialityTip2;
    private TextView mTvSpecialityTip3;
    private LinearLayout mLlSpeciality;
    private TextView mTvSpecialityTip4;
    private TextView mTvSpecialityTip5;
    private ImageView mIvBottom1;
    private TextView mTvLawyerIntro;
    private TextView mTvPackUp1;
    private LinearLayout mLlBottomDetail1;
    private TextView mTvLawyerIntro2;
    private ImageView mIvBottom2;
    private TextView mTvPackUp2;
    private LinearLayout mLlBottomDetail2;
    private TextView mTvEvaluationNumber;
    private ImageView mIvBottom3;
    private TextView mTvTotalList;
    private TextView mTvMonthList;
    private TextView mTvSatisfactionDegree;
    private TextView mTvActivityList;
    private TextView mTvPackUp3;
    private LinearLayout mLlBottomDetail3;
    private TextView mTvPersonalRank;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_per_home_page);
        mTfLight = Typeface.createFromAsset(getAssets(), "OpenSans-Light.ttf");
        mContext = this;
        initView();
        setChart();
        //    LoadData( "1e314c59e37f4757bab2be2b26452748");
    }

    private void initView() {
        mcoySnapPageLayout = (McoySnapPageLayout) findViewById(R.id.flipLayout);
        McoyScrollSnapPage m1 = new McoyScrollSnapPage(this, R.layout.layout_homepage_enter_lawyer);
        McoyScrollSnapPage m2 = new McoyScrollSnapPage(this, R.layout.fragment_apply_submit);
        mcoySnapPageLayout.addSnapPage(m1);
        mcoySnapPageLayout.addSnapPage(m2);
        mIvLawyerAvatar = (ImageView) findViewById(R.id.iv_lawyer_avatar);
        mTvLawyerName = (TextView) findViewById(R.id.tv_lawyer_name);
        mTvOffice = (TextView) findViewById(R.id.tv_office);
        mTvServicePhone = (TextView) findViewById(R.id.tv_service_phone);
        mTvArea2 = (TextView) findViewById(R.id.tv_area2);
        mTvPracticeCertificateNumber = (TextView) findViewById(R.id.tv_practice_certificate_number);
        mTvWorkYear = (TextView) findViewById(R.id.tv_work_year);
        mTvSpecialityTip1 = (TextView) findViewById(R.id.tv_speciality_tip1);
        mTvSpecialityTip2 = (TextView) findViewById(R.id.tv_speciality_tip2);
        mTvSpecialityTip3 = (TextView) findViewById(R.id.tv_speciality_tip3);
        mLlSpeciality = (LinearLayout) findViewById(R.id.ll_speciality);
        mTvSpecialityTip4 = (TextView) findViewById(R.id.tv_speciality_tip4);
        mTvSpecialityTip5 = (TextView) findViewById(R.id.tv_speciality_tip5);
        mIvBottom1 = (ImageView) findViewById(R.id.iv_bottom1);
        mIvBottom1.setOnClickListener(this);
        mTvLawyerIntro = (TextView) findViewById(R.id.tv_lawyer_intro);
        mTvLawyerIntro.setOnClickListener(this);
        mTvPackUp1 = (TextView) findViewById(R.id.tv_pack_up1);
        mTvPackUp1.setOnClickListener(this);
        mLlBottomDetail1 = (LinearLayout) findViewById(R.id.ll_bottom_detail1);
        mTvLawyerIntro2 = (TextView) findViewById(R.id.tv_lawyer_intro2);
        mTvLawyerIntro2.setOnClickListener(this);
        mIvBottom2 = (ImageView) findViewById(R.id.iv_bottom2);
        mTvPackUp2 = (TextView) findViewById(R.id.tv_pack_up2);
        mTvPackUp2.setOnClickListener(this);
        mLlBottomDetail2 = (LinearLayout) findViewById(R.id.ll_bottom_detail2);
        mTvEvaluationNumber = (TextView) findViewById(R.id.tv_evaluation_number);
        mTvEvaluationNumber.setOnClickListener(this);
        mIvBottom3 = (ImageView) findViewById(R.id.iv_bottom3);
        mTvTotalList = (TextView) findViewById(R.id.tv_total_list);
        mTvMonthList = (TextView) findViewById(R.id.tv_month_list);
        mTvSatisfactionDegree = (TextView) findViewById(R.id.tv_satisfaction_degree);
        mTvActivityList = (TextView) findViewById(R.id.tv_activity_list);
        mTvPackUp3 = (TextView) findViewById(R.id.tv_pack_up3);
        mTvPackUp3.setOnClickListener(this);
        mLlBottomDetail3 = (LinearLayout) findViewById(R.id.ll_bottom_detail3);
        mTvPersonalRank = (TextView) findViewById(R.id.tv_personal_rank);
        mTvPersonalRank.setOnClickListener(this);


    }

    //编辑点击
    public void onToolbarClick(View view) {
        Intent intent = new Intent(mContext, EditHomePageActivity.class);
        intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.qwpf));
        startActivity(intent);
    }

    private void setChart() {
        mChart = (RadarChart) findViewById(R.id.chart1);
        mChart.setBackgroundColor(Color.WHITE);
        mChart.getDescription().setEnabled(false);
        mChart.setWebLineWidth(1f);
        mChart.setWebColor(Color.LTGRAY);
        mChart.setWebLineWidthInner(1f);
        mChart.setWebColorInner(Color.LTGRAY);
        mChart.setWebAlpha(120);
        mChart.setRotationEnabled(false);

        // create a custom MarkerView (extend MarkerView) and specify the layout
        // to use for it
        MarkerView mv = new RadarMarkerView(this, R.layout.radar_markerview);
        mv.setChartView(mChart); // For bounds control
        mChart.setMarker(mv); // Set the marker to the chart
        setData();
        mChart.animateXY(
                1400, 1400,
                Easing.EasingOption.EaseInOutQuad,
                Easing.EasingOption.EaseInOutQuad);
        XAxis xAxis = mChart.getXAxis();
        xAxis.setTypeface(mTfLight);
        xAxis.setTextSize(9f);
        xAxis.setYOffset(0f);
        xAxis.setXOffset(0f);
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            private String[] mActivities = new String[]{"Burger", "Steak", "Salad", "Pasta"};

            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return mActivities[(int) value % mActivities.length];
            }
        });
        xAxis.setTextColor(Color.BLACK);
        YAxis yAxis = mChart.getYAxis();
        yAxis.setTypeface(mTfLight);
        yAxis.setLabelCount(4, false);
        yAxis.setTextSize(9f);
        yAxis.setAxisMinimum(0f);
        yAxis.setAxisMaximum(80f);
        yAxis.setDrawLabels(false);
        Legend l = mChart.getLegend();
        l.setEnabled(false);
    }

    public void setData() {
        float mult = 80;
        float min = 20;
        int cnt = 4;
        ArrayList<RadarEntry> entries1 = new ArrayList<RadarEntry>();
        for (int i = 0; i < cnt; i++) {
            float val1 = (float) (Math.random() * mult) + min;
            entries1.add(new RadarEntry(val1));
        }
        RadarDataSet set1 = new RadarDataSet(entries1, null);
        set1.setColor(Color.rgb(203, 71, 71));
        set1.setFillColor(Color.rgb(240, 173, 173));
        set1.setDrawFilled(true);
        set1.setFillAlpha(180);
        set1.setLineWidth(2f);
        set1.setDrawHighlightCircleEnabled(true);
        set1.setDrawHighlightIndicators(false);
        ArrayList<IRadarDataSet> sets = new ArrayList<IRadarDataSet>();
        sets.add(set1);
        RadarData data = new RadarData(sets);
        data.setValueTypeface(mTfLight);
        data.setValueTextSize(8f);
        data.setDrawValues(false);
        data.setValueTextColor(Color.WHITE);
        mChart.setData(data);
        mChart.invalidate();
    }

    /**
     * 加载律师详情数据
     *
     * @param id 律师ID
     */
    private void LoadData(String id) {
        if (getInProgess())
            return;
        setInProgess(true);
        JalawService service = new JalawService(mContext);
        service.setProgressShowContent(getString(R.string.get_ing));
        service.setShowProgress(true);
        service.getLawyerDetail(id, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty() || !(values.get(0) instanceof JalawLawyerDetailVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mJalawLawyerDetailVO = (JalawLawyerDetailVO) values.get(0);
                bindDataToView();

            }

            @Override
            public void onError(String msg, String content) {
                T.showLong(mContext, msg);
                setInProgess(false);
            }
        });
    }

    private void bindDataToView() {
        String imageUrl = mJalawLawyerDetailVO.getPhoto();
        if (!TextUtils.isEmpty(imageUrl)) {
            ImageLoader.getInstance().displayImage(UrlUtil.getImageFileUrl(mContext, imageUrl), mIvLawyerAvatar, ApplicationSet.CDIO_LAW);
        } else {
            mIvLawyerAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
        mTvLawyerName.setText(mJalawLawyerDetailVO.getName() + "    " + mContext.getString(R.string.lawyer));
        mTvOffice.setText(mJalawLawyerDetailVO.getLawfirmName());
        BaseCommonDataVO baseCommonDataVO = BaseCommonDataVO.findDataVOWithOid(ApplicationSet.getInstance().getAreas(), mJalawLawyerDetailVO.getCity());
        String city = "";
        if (baseCommonDataVO != null) {
            city = baseCommonDataVO.getName();
        }
        BaseCommonDataVO baseCommonDataVO1 = BaseCommonDataVO.findDataVOWithOid(ApplicationSet.getInstance().getAreas(), mJalawLawyerDetailVO.getCounty());
        String country = "";
        if (baseCommonDataVO1 != null) {
            country = baseCommonDataVO1.getName();
        }
        mTvArea2.setText(city + " " + country);
        TextViewUtil.isEmpty(mTvServicePhone, mJalawLawyerDetailVO.getLawfirmTelephone());
        if (mJalawLawyerDetailVO.getFirstPracticeDate() != null) {
            int x = 0;
            x = Integer.parseInt(TimeUtil.getCurrentYear()) - Integer.parseInt(mJalawLawyerDetailVO.getFirstPracticeDate().substring(0, 4));
            TextViewUtil.isEmpty(mTvWorkYear, x + getString(R.string.year2));
        }

        TextViewUtil.isEmpty(mTvPracticeCertificateNumber, mJalawLawyerDetailVO.getPractisingCertificateSerialNumber());

        if (mJalawLawyerDetailVO.getBusiness() != null && mJalawLawyerDetailVO.getBusiness().size() > 0) {
            for (int i = 0; i < mJalawLawyerDetailVO.getBusiness().size(); i++) {
                switch (i) {
                    case 0:
                        String str1 = BaseCommonToStringUtil.toString(mJalawLawyerDetailVO.getBusiness().get(0).getBusiness());
                        if (str1 == null || str1.equals("")) {
                            mTvSpecialityTip1.setVisibility(View.GONE);
                        } else {
                            mTvSpecialityTip1.setVisibility(View.VISIBLE);
                            TextViewUtil.isEmpty(mTvSpecialityTip1, str1);
                        }

                        break;
                    case 1:
                        String str2 = BaseCommonToStringUtil.toString(mJalawLawyerDetailVO.getBusiness().get(1).getBusiness());
                        if (str2 == null || str2.equals("")) {
                            mTvSpecialityTip2.setVisibility(View.GONE);
                        } else {
                            mTvSpecialityTip2.setVisibility(View.VISIBLE);
                            TextViewUtil.isEmpty(mTvSpecialityTip2, str2);
                        }
                        break;
                    case 2:
                        String str3 = BaseCommonToStringUtil.toString(mJalawLawyerDetailVO.getBusiness().get(2).getBusiness());
                        if (str3 == null || str3.equals("")) {
                            mTvSpecialityTip3.setVisibility(View.GONE);
                        } else {
                            mTvSpecialityTip3.setVisibility(View.VISIBLE);
                            TextViewUtil.isEmpty(mTvSpecialityTip3, str3);
                        }
                        break;
                    case 3:
                        String str4 = BaseCommonToStringUtil.toString(mJalawLawyerDetailVO.getBusiness().get(3).getBusiness());
                        if (str4 == null || str4.equals("")) {
                            mTvSpecialityTip4.setVisibility(View.GONE);
                        } else {
                            mTvSpecialityTip4.setVisibility(View.VISIBLE);
                            TextViewUtil.isEmpty(mTvSpecialityTip4, str4);
                        }
                        break;
                    case 4:
                        String str5 = BaseCommonToStringUtil.toString(mJalawLawyerDetailVO.getBusiness().get(4).getBusiness());
                        if (str5 == null || str5.equals("")) {
                            mTvSpecialityTip5.setVisibility(View.GONE);
                        } else {
                            mTvSpecialityTip5.setVisibility(View.VISIBLE);
                            TextViewUtil.isEmpty(mTvSpecialityTip5, str5);
                        }
                        break;
                }
            }
        }

        TextViewUtil.isEmpty(mTvLawyerIntro, mJalawLawyerDetailVO.getIntroduction());
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_pack_up1:
                mLlBottomDetail1.setVisibility(View.GONE);
                mIvBottom1.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_lawyer_intro2:
                if (mLlBottomDetail1.getVisibility() == View.GONE) {
                    mIvBottom1.setVisibility(View.GONE);
                    mLlBottomDetail1.setVisibility(View.VISIBLE);
                } else {
                    mIvBottom1.setVisibility(View.VISIBLE);
                    mLlBottomDetail1.setVisibility(View.GONE);
                }
                break;
            case R.id.tv_pack_up2:
                mLlBottomDetail2.setVisibility(View.GONE);
                mIvBottom2.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_evaluation_number:
                if (mLlBottomDetail2.getVisibility() == View.GONE) {
                    mIvBottom2.setVisibility(View.GONE);
                    mLlBottomDetail2.setVisibility(View.VISIBLE);

                } else {
                    mIvBottom2.setVisibility(View.VISIBLE);
                    mLlBottomDetail2.setVisibility(View.GONE);
                }
                break;
            case R.id.tv_pack_up3:
                mLlBottomDetail3.setVisibility(View.GONE);
                mIvBottom3.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_personal_rank:
                if (mLlBottomDetail3.getVisibility() == View.GONE) {
                    mIvBottom3.setVisibility(View.GONE);
                    mLlBottomDetail3.setVisibility(View.VISIBLE);

                } else {
                    mIvBottom3.setVisibility(View.VISIBLE);
                    mLlBottomDetail3.setVisibility(View.GONE);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) and run LayoutCreator again
    }
}
