package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.UserVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class LawProtocolActivity extends BaseActivity {

    private WebView mWvContent;
    private Button mBtnSure;
    private Button mBtnCancle;
    private  boolean is30s=false;
    private Timer mTime;
    private long durationTime = 1000;
    private Context mContext;
    private int countdown = 14;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_law_protocol);
        mContext=this;
        initView();
        startTimer();
    }



    private void initView() {
        mWvContent = (WebView) findViewById(R.id.wv_content);
        mBtnSure= (Button) findViewById(R.id.btn_sure);
        mBtnCancle= (Button) findViewById(R.id.btn_cancle);
        mBtnSure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    commitEnter();
            }
        });
        mBtnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //启用支持javascript
        WebSettings settings = mWvContent.getSettings();

        settings.setJavaScriptEnabled(true);
        mWvContent.loadUrl(getString(R.string.url_base) + getString(R.string.law_protocol));
    }

    private void commitEnter() {
        if (getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.setProgressShowContent(mContext.getString(R.string.submit_ing));
        service.setShowProgress(true);
        service.postEnterTeam(new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if (values == null || values.isEmpty() || !(values.get(0) instanceof UserVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                UserVO userVO=(UserVO) values.get(0);
                ApplicationSet.getInstance().getUserVO().setLawyerTeamFlag(userVO.getLawyerTeamFlag());
                T.showLong(mContext, getString(R.string.submit_success));
                finish();
            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext, msg);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onDestroy() {
        cancelTimer();
        super.onDestroy();
    }

    private void cancelTimer() {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                countdown = 14;
                mBtnSure.setText(R.string.sure);
                mBtnSure.setClickable(true);
                mBtnSure.setSelected(false);
            }
        });
        if (mTime != null)
            mTime.cancel();
    }
    private void startTimer() {
        cancelTimer();
        mBtnSure.setSelected(true);
        mBtnSure.setClickable(false);
        mTime = new Timer();
        mTime.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (countdown > 0) {
                            if(countdown<10){
                                mBtnSure.setText("0"+
                                        countdown +"S");
                            }else {
                                mBtnSure.setText(
                                        countdown + "S" );
                            }
                            countdown--;
                        } else {
                            cancelTimer();
                        }

                    }
                });

            }
        }, durationTime, durationTime);

    }
}
