package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.jauker.widget.BadgeView;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.ui.SignedActivity;
import com.lawyee.apppublic.ui.personalcenter.MyMessageActivity;
import com.lawyee.apppublic.ui.personalcenter.jals.JaglsEntrustActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.LgavActivityActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.LgavNoticeActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity;
import com.lawyee.apppublic.util.SessionIdUtil;
import com.lawyee.apppublic.util.db.ChatProvider;
import com.lawyee.apppublic.util.db.IMDBHelper;
import com.lawyee.apppublic.vo.UnreadVO;
import com.lawyee.apppublic.vo.UserVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import static com.lawyee.apppublic.R.id.rl_my_entrust;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity.CSTR_TYPE;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity.CSTR_URL;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_BASICLAWWORKER;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @Title: 标题
 * @Package com.lawyee.apppublic.ui.personalcenter.lawyer
 * @Description: 律师端-个人中心
 * @author:lzh
 * @date: 2017/8/9
 * @verdescript 2017/8/9  lzh 初建
 * @Copyright: 2017/8/9 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class LawyerPCenterActivity extends BaseActivity implements View.OnClickListener {


    private RelativeLayout mRlMyEntrust;
    private RelativeLayout mRlMyConsult;
    private RelativeLayout mRlMyMessage;
    private View mTvMessage;
    private TextView mTvLoginOut;
    private Context mContext;
    private BadgeView mBadgeView;
    private BadgeView mBadgeView_qwpf;
    private BadgeView mBadgeView_Entrust;
    private BadgeView mBadgeView_Consult;
    private BadgeView mBadgeView_Activity;
    private BadgeView mBadgeView_NoticeAnnouncement;
    private BadgeView mBadgeView_village;
    private BadgeView mBadgeView_duty;
    private int mNum;
    private ChatObserver mChatObserver = new ChatObserver();
    private Handler mChatHandler = new Handler();
    private RelativeLayout mRlMyQwpf;
    private RelativeLayout mRlMyActivity;
    private RelativeLayout mRlMyNoticeAnnouncement;
    private RelativeLayout mRlMyPersonalHomepage;
    private RelativeLayout mRlMySigned;
    private UnreadVO mUnreadVO;
    private View mIvMyQwpfRight;
    private View mViewMyQwpf;
    private View mIvMyEntrustRight;
    private View mIvMyConsultRight;
    private View mIvMyActivityRight;
    private View mViewMyActivity;
    private View mIvMyNoticeAnnouncementRight;
    private UserVO mUserVO;
    private View mViewMyconsult;
    private View mIvVillageAdvise;
    private RelativeLayout mRlVillageAdvise;
    private View mViewVillageAdvise;
    private RelativeLayout mRLDutyLaw;
    private View mViewDutyLaw;
    private View mIvDutyLaw;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lawyer_pcenter);
        mContext = this;
        initView();
        getContentResolver().registerContentObserver(
                ChatProvider.CONTENT_URI, true, mChatObserver);// 开始聊天数据库


    }

    @Override
    protected void onResume() {
        super.onResume();
        mUserVO = ApplicationSet.getInstance().getUserVO();
        judgeUser();
        judgeDuty();
        loadLocal();
        loadNoread();

    }

    private void judgeDuty() {
        if(ApplicationSet.getInstance().IsLogin()&&ApplicationSet.getInstance().getUserVO().getDutyFlag().equals("true")){
            mRLDutyLaw.setVisibility(View.VISIBLE);
            mViewDutyLaw.setVisibility(View.VISIBLE);
        }else{
            mRLDutyLaw.setVisibility(View.GONE);
            mViewDutyLaw.setVisibility(View.GONE);
        }
    }

    /**
     * 判断用户类型来显示列表
     */
    private void judgeUser() {
        if (mUserVO != null && mUserVO.getLawyerTeamFlag() != null) {
            mRlMySigned.setVisibility(View.GONE);
            if (mUserVO.getRole().equals(CSTR_USERROLE_BASICLAWWORKER)) {
                mRlMyConsult.setVisibility(View.GONE);
                mViewMyconsult.setVisibility(View.GONE);
            } else {
                mRlMyPersonalHomepage.setVisibility(View.VISIBLE);
                mRlMyConsult.setVisibility(View.VISIBLE);
                mViewMyconsult.setVisibility(View.VISIBLE);
            }
            if (mUserVO.getAdviserFlag().equals("true")) {
                mRlVillageAdvise.setVisibility(View.VISIBLE);
                mViewVillageAdvise.setVisibility(View.VISIBLE);
            } else {
                mRlVillageAdvise.setVisibility(View.GONE);
                mViewVillageAdvise.setVisibility(View.GONE);
            }
            if (!mUserVO.getLawyerTeamFlag().equals("1")) {
                mRlMyQwpf.setVisibility(View.GONE);
                mViewMyQwpf.setVisibility(View.GONE);
            } else {
                mRlMyQwpf.setVisibility(View.VISIBLE);
                mViewMyQwpf.setVisibility(View.VISIBLE);
                mRlMyActivity.setVisibility(View.VISIBLE);
                mViewMyActivity.setVisibility(View.VISIBLE);
                mRlMySigned.setVisibility(View.VISIBLE);
            }
        } else {
            mRlMyQwpf.setVisibility(View.GONE);
            mViewMyQwpf.setVisibility(View.GONE);
            mRlMyActivity.setVisibility(View.GONE);
            mViewMyActivity.setVisibility(View.GONE);
            mRlMySigned.setVisibility(View.GONE);
            mRlVillageAdvise.setVisibility(View.GONE);
            mViewVillageAdvise.setVisibility(View.GONE);

        }
    }

    private void initView() {
        mRlMyEntrust = (RelativeLayout) findViewById(R.id.rl_my_entrust);
        mRlMyConsult = (RelativeLayout) findViewById(R.id.rl_my_consult);
        mViewMyconsult = findViewById(R.id.view_myconsult);
        mRlMyMessage = (RelativeLayout) findViewById(R.id.rl_my_message);
        mRlMyQwpf = (RelativeLayout) findViewById(R.id.rl_my_qwpf);
        mRlMyActivity = (RelativeLayout) findViewById(R.id.rl_my_activity);
        mRlMyNoticeAnnouncement = (RelativeLayout) findViewById(R.id.rl_my_notice_announcement);
        mRlMyPersonalHomepage = (RelativeLayout) findViewById(R.id.rl_my_personal_homepage);
        mRlMySigned = (RelativeLayout) findViewById(R.id.rl_my_signed);
        mTvMessage = findViewById(R.id.iv_message_right);
        mIvMyQwpfRight = findViewById(R.id.iv_my_qwpf_right);
        mViewMyQwpf = findViewById(R.id.view_my_qwpf);
        mIvMyEntrustRight = findViewById(R.id.iv_my_entrust_right);
        mIvMyConsultRight = findViewById(R.id.iv_my_consult_right);
        mIvMyActivityRight = findViewById(R.id.iv_my_activity_right);
        mViewMyActivity = findViewById(R.id.view_my_activity);
        mIvVillageAdvise = findViewById(R.id.iv_village_advise);
        mRlVillageAdvise = (RelativeLayout) findViewById(R.id.rl_village_advise);
        mViewVillageAdvise = findViewById(R.id.view_village_advise);
        mIvMyNoticeAnnouncementRight = findViewById(R.id.iv_my_notice_announcement_right);
        mRLDutyLaw= (RelativeLayout) findViewById(R.id.rl_duty_law);
        mViewDutyLaw=findViewById(R.id.view_duty_law);
        mIvDutyLaw=findViewById(R.id.iv_duty_law);
        mTvLoginOut = (TextView) findViewById(R.id.tv_login_out);
        mRLDutyLaw.setOnClickListener(this);
        mRlMyEntrust.setOnClickListener(this);
        mRlVillageAdvise.setOnClickListener(this);
        mRlMyConsult.setOnClickListener(this);
        mRlMyMessage.setOnClickListener(this);
        mRlMyQwpf.setOnClickListener(this);
        mRlMyActivity.setOnClickListener(this);
        mRlMyNoticeAnnouncement.setOnClickListener(this);
        mRlMyPersonalHomepage.setOnClickListener(this);
        mRlMySigned.setOnClickListener(this);
        mTvLoginOut.setOnClickListener(this);
        mBadgeView = new BadgeView(mContext);
        createBadgeView(mBadgeView, mTvMessage);
        mBadgeView_qwpf = new BadgeView(mContext);
        createBadgeView(mBadgeView_qwpf, mIvMyQwpfRight);
        mBadgeView_Entrust = new BadgeView(mContext);
        createBadgeView(mBadgeView_Entrust, mIvMyEntrustRight);
        mBadgeView_Consult = new BadgeView(mContext);
        createBadgeView(mBadgeView_Consult, mIvMyConsultRight);
        mBadgeView_Activity = new BadgeView(mContext);
        createBadgeView(mBadgeView_Activity, mIvMyActivityRight);
        mBadgeView_NoticeAnnouncement = new BadgeView(mContext);
        createBadgeView(mBadgeView_NoticeAnnouncement, mIvMyNoticeAnnouncementRight);
        mBadgeView_village = new BadgeView(mContext);
        createBadgeView(mBadgeView_village, mIvVillageAdvise);
        mBadgeView_duty = new BadgeView(mContext);
        createBadgeView(mBadgeView_duty, mIvDutyLaw);
        if (ApplicationSet.getInstance().getUserVO() != null) {
            if (ApplicationSet.getInstance().getUserVO().getRealName() != null && !ApplicationSet.getInstance().getUserVO().getRealName().equals("")) {
                setTitle(ApplicationSet.getInstance().getUserVO().getRealName()+getString(R.string.welcome));
            } else {
                setTitle(ApplicationSet.getInstance().getUserVO().getLoginId()+getString(R.string.welcome));
            }
        }
    }

    /**
     * 设置badgeView
     *
     * @param badgeView
     * @param view
     */
    private void createBadgeView(BadgeView badgeView, View view) {

        badgeView.setTargetView(view);
        badgeView.setBadgeGravity(Gravity.CENTER);
        badgeView.setTypeface(Typeface.create(Typeface.SANS_SERIF,
                Typeface.ITALIC));
        badgeView.setVisibility(View.GONE);
    }

    public void onToolbarClick(View view) {
        startActivity(new Intent(mContext, SettingActivity.class));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case rl_my_entrust://委托
                if (ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_BASICLAWWORKER)) {
                    startActivity(new Intent(mContext, JaglsEntrustActivity.class));
                } else {
                    startActivity(new Intent(mContext, LawyerEntrustActivity.class));
                }
                break;
            case R.id.rl_my_consult://咨询
                startActivity(new Intent(mContext, ConsultListActivity.class));
                break;
            case R.id.rl_my_message://我的消息
                startActivity(new Intent(mContext, MyMessageActivity.class));
                break;
            case R.id.rl_my_personal_homepage://个人主页

                if (mUserVO.getLawyerTeamFlag().equals("1")) {
                    Intent intent = new Intent(mContext, WebViewShowActivity.class);
                    intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.personal_homepage));
                    String url =  getString(R.string.url_base) + getString(R.string.law_home_page) + SessionIdUtil.getUserSessionId(mContext) +
                            getString(R.string.url_appstamp) +  SessionIdUtil.getAppstamp(mContext);
                    intent.putExtra(CSTR_TYPE, 4);
                    intent.putExtra(CSTR_URL, url);
                    startActivity(intent);
                } else {
                    startActivity(new Intent(mContext, SettingActivity.class));
                }


                break;
            case R.id.rl_my_signed://我的签到
                Intent intent2 = new Intent(mContext, SignedActivity.class);
                intent2.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.signed));
                startActivity(intent2);
                break;
            case R.id.rl_my_qwpf://黔微普法
                Intent MyProblemintent1 = new Intent(LawyerPCenterActivity.this, MyProblemActivity.class);
                MyProblemintent1.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_LGAV);
                MyProblemintent1.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_team_problem));

                startActivity(MyProblemintent1);
                break;
            case R.id.rl_village_advise://法律顾问问题
                Intent MyProblemintent2 = new Intent(LawyerPCenterActivity.this, MyProblemActivity.class);
                MyProblemintent2.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_RODIE);
                MyProblemintent2.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_advise_problem));

                startActivity(MyProblemintent2);
                break;
            case R.id.rl_duty_law://值班律师问题
                Intent MyProblemintent3 = new Intent(LawyerPCenterActivity.this, MyProblemActivity.class);
                MyProblemintent3.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_LAW);
                MyProblemintent3.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.duty_lawyer_problem));

                startActivity(MyProblemintent3);
                break;
            case R.id.rl_my_activity://我的活动
                Intent Lgavintent = new Intent(LawyerPCenterActivity.this, LgavActivityActivity.class);
                startActivity(Lgavintent);
                break;
            case R.id.rl_my_notice_announcement://通知公告
                Intent intent3 = new Intent(LawyerPCenterActivity.this, LgavNoticeActivity.class);
                startActivity(intent3);
                break;
            case R.id.tv_login_out://退出登录
                new MaterialDialog.Builder(this)
                        .content("您确定要退出当前帐号吗?")
                        .positiveText(R.string.dl_btn_confirm)
                        .negativeText(R.string.dl_btn_cancel)
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                toLogout();
                            }
                        })
                        .show();
                break;
        }
    }


    //从网络加载加载未读信息
    private void loadNoread() {
        if (getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.getMessageNoRead(new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);

                if (values == null || values.isEmpty() || !(values.get(0) instanceof UnreadVO)) {
                    T.showLong(mContext, getString(R.string.get_error_noeffectdata));
                    return;
                }
                mUnreadVO = (UnreadVO) values.get(0);
                setNoReadData();

            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext, msg);
            }
        });
    }

    //绑定未读信息
    private void setNoReadData() {
        mNum = mNum + Integer.parseInt(mUnreadVO.getMessageCount());
        setBadgView(mBadgeView, mNum);
        setBadgView(mBadgeView_Entrust, Integer.parseInt(mUnreadVO.getEntrustCount()));
        setBadgView(mBadgeView_Consult, Integer.parseInt(mUnreadVO.getConsultCount()));
        setBadgView(mBadgeView_NoticeAnnouncement, Integer.parseInt(mUnreadVO.getNoticeCount()));
        setBadgView(mBadgeView_Activity, Integer.parseInt(mUnreadVO.getActiveCount()));
        if (mUserVO.getLawyerTeamFlag().equals("1")) {
            setBadgView(mBadgeView_qwpf, Integer.parseInt(mUnreadVO.getTeamLawCount()));
            if(mUserVO.getDutyFlag().equals("true")){
                setBadgView(mBadgeView_duty, Integer.parseInt(mUnreadVO.getTeamDutyCount()));
            }
        }
        if(mUserVO.getAdviserFlag().equals("true")){
            setBadgView(mBadgeView_village, Integer.parseInt(mUnreadVO.getTeamVillageCount()));
        }
    }


    //加载聊天数
    private void loadLocal() {
        if (ApplicationSet.getInstance().getUserVO() != null) {
            mNum = IMDBHelper.getInstance().getNoReadMessage(ApplicationSet.getInstance().getUserVO().getOpenfireLoginId());
        }
    }


    /**
     * 聊天数据库变化监听
     */
    private class ChatObserver extends ContentObserver {
        public ChatObserver() {
            super(mChatHandler);
        }

        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            updateChatStatus();
        }
    }

    private void updateChatStatus() {
        Observable<Boolean> observable = Observable.create(
                new ObservableOnSubscribe<Boolean>() {
                    @Override
                    public void subscribe(@NonNull ObservableEmitter<Boolean> e) throws Exception {
                        int num = IMDBHelper.getInstance().getNoReadMessage(ApplicationSet.getInstance().getUserVO().getOpenfireLoginId());
                        if (mNum != num) {
                            if (mUnreadVO != null) {
                                mNum = num + Integer.parseInt(mUnreadVO.getMessageCount());
                            } else {
                                mNum = num;
                            }

                            e.onNext(true);
                        }

                    }
                }
        );
        Observer<Boolean> subscriber = new Observer<Boolean>() {
            @Override
            public void onSubscribe(@NonNull Disposable d) {

            }

            @Override
            public void onNext(Boolean b) {
                if (b) {
                    setBadgView(mBadgeView, mNum);
                }
            }

            @Override
            public void onError(Throwable t) {
                T.showLong(mContext, t.getMessage());
            }

            @Override
            public void onComplete() {
            }
        };
        observable.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(subscriber);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getContentResolver().unregisterContentObserver(mChatObserver);
    }
}
