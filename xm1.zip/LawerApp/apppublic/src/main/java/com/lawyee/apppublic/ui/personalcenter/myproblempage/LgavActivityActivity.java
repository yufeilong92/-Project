package com.lawyee.apppublic.ui.personalcenter.myproblempage;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.andview.refreshview.XRefreshView;
import com.andview.refreshview.XRefreshViewFooter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.LgavAdapter;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavActivityService;
import com.lawyee.apppublic.ui.BaseActivity;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LgavActivityActivity.java
 * @Package com.lawyee.apppublic.ui.personalcenter.myhomepage
 * @Description: 我的活动
 * @author: YFL
 * @date: 2017/9/28 15:53
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/9/28 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavActivityActivity extends BaseActivity {
    /**
     * 数据是否处理中，用于服务端请求数据时标识，防止重复申请
     */
    boolean mInProgess;
    private RecyclerView mRlvLgavActivityView;
    private XRefreshView mXrefreshView;
    private TextView mXrvLgavActivityEmptyDetail;
    private Context mContext;
    private ArrayList mDataList;
    private LgavAdapter mLgavAdapter;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lgav_activity);
        initView();
        bindListData();
    }

    private void bindListData() {
        //获取获取 数据
        clearDataList();
        //设置适配器
        setRecyclerAdapter();
        requestService(true, 1);

    }


    //加载更多
    private void loadMoreDatas() {
        if (mInProgess) {
            return;
        }
        mInProgess = true;
        LgavActivityService service = new LgavActivityService(mContext);
        service.queryLgavActivityList(getNowPage() + 1, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                if (values == null || values.isEmpty()) {
                    mXrefreshView.setLoadComplete(true);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    return;
                }
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    // 设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else
                    mXrefreshView.setLoadComplete(true);
                mLgavAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopLoadMore();
                T.showLong(mContext, msg);
            }
        });
    }

    //加载新数据
    private void LoadNewData() {
        if (mInProgess)
            return;
        mInProgess = true;
        requestService(false, 1);

    }

    /**
     * @param isfisrt 是否显示提示框
     * @param page
     */
    private void requestService(boolean isfisrt, int page) {
        LgavActivityService activityService = new LgavActivityService(mContext);
        activityService.setShowProgress(isfisrt);
        activityService.setProgressShowContent(getResources().getString(R.string.get_ing));
        activityService.queryLgavActivityList(page, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                if (values == null || values.isEmpty()) {
                    T.showShort(getApplication(), content);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    mLgavAdapter.notifyDataSetChanged();
                    return;
                }
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else
                    mXrefreshView.setLoadComplete(true);
                mLgavAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                T.showShort(getApplicationContext(), msg);
            }
        });

    }

    /**
     * 设置适配器
     */
    private void setRecyclerAdapter() {
        mLgavAdapter = new LgavAdapter(mContext, mDataList, LgavAdapter.LGAVACTIVITY);
        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 1);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        mRlvLgavActivityView.setLayoutManager(layoutManager);
        mLgavAdapter.setCustomLoadMoreView( new XRefreshViewFooter(mContext));
        mRlvLgavActivityView.setAdapter(mLgavAdapter);
        mLgavAdapter.setItemOnClickListener(new LgavAdapter.OnRecyclerItemOnClickListener() {
            @Override
            public void onItemClickListener(View view, Object content) {
                String oid = (String) content;
                LgavActivityDetailActivity.onNewIntent(mContext, oid);

            }
        });

    }

    private void initView() {
        mContext = this;
        mRlvLgavActivityView = (RecyclerView) findViewById(R.id.rlv_lgavActivity_view);
        mXrefreshView = (XRefreshView) findViewById(R.id.xrv_lgavActivity_detail);
        mXrvLgavActivityEmptyDetail = (TextView) findViewById(R.id.xrv_lgavActivity_empty_detail);
        //设置是否能上拉刷新
        mXrefreshView.setPullLoadEnable(false);
        //设置是否下拉刷新
        mXrefreshView.setPullRefreshEnable(true);
        mXrefreshView.restoreLastRefreshTime(0l);
        mXrefreshView.setEmptyView(findViewById(R.id.xrv_lgavActivity_empty_detail));
        mXrefreshView.setXRefreshViewListener(new XRefreshView.SimpleXRefreshListener() {
            @Override
            public void onRefresh(boolean isPullDown) {
                LoadNewData();
            }


            @Override
            public void onLoadMore(boolean isSilence) {
                loadMoreDatas();
            }
        });
    }


    /**
     * 当前数据有几页
     *
     * @return
     */
    private int getNowPage() {
        if (mDataList == null || mDataList.isEmpty())
            return 0;
        if (mDataList.size() % Constants.CINT_PAGE_SIZE == 0)
            return mDataList.size() / Constants.CINT_PAGE_SIZE;
        else
            return mDataList.size() / Constants.CINT_PAGE_SIZE + 1;
    }

    /**
     * 清除数据
     */
    private void clearDataList() {
        if (mDataList == null) {
            mDataList = new ArrayList();
        } else {
            mDataList.clear();
        }
    }

    /**
     * 增加列表数据
     */
    private void addDataList(List<?> list) {
        if (mDataList == null) {
            clearDataList();
        }
        if (list == null || list.isEmpty()) {
            return;
        }
        mDataList.addAll(list);
    }

}


