package com.lawyee.apppublic.ui.personalcenter.myproblempage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.DataManage;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavActivityService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.LgavActivityDetailVO;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LgavActivityDetailActivity.java
 * @Package com.lawyee.apppublic.ui.personalcenter.myproblempage
 * @Description:
 * @author: YFL
 * @date: 2017/10/9 11:16
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/10/9 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavActivityDetailActivity extends BaseActivity implements View.OnClickListener {

    private Context mContent;
    private TextView mTvLgavActivityTitle;
    private TextView mTextView18;
    private TextView mTvLgavActivityStarttime;
    private TextView mTvLgavActivityEndtime;
    private TextView mTvLgavActivityaddress;
    private TextView mTvLgavActivitymodality;
    private TextView mTvLgavActivityjionpeople;
    private TextView mTvLgavActivitychargepeople;
    private TextView mTvLgavActivityhostunit;
    private TextView mTvLgavActivityunit;
    private TextView mTvLgavActivityDetailContent;
    private RelativeLayout mRllgavActivityInfomContent;
    /**
     * 活动oid
     */
    public static final String ACTIVITYOID = "activityoid";
    private String mActivityOid;

    /**
     * 跳转
     *
     * @param context
     * @param mActivityOid 活动oid
     */
    public static void onNewIntent(Context context, String mActivityOid) {
        Intent intent = new Intent(context, LgavActivityDetailActivity.class);
        intent.putExtra(ACTIVITYOID, mActivityOid);
        context.startActivity(intent);
    }
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lgav_detail);
        Intent intent = getIntent();
        mActivityOid = intent.getStringExtra(ACTIVITYOID);
        initView();
        loadRequestServioe();
    }

    /**
     * 请求网络
     */
    private void loadRequestServioe() {
        LgavActivityService activityService = new LgavActivityService(mContent);
        activityService.setShowProgress(true);
        activityService.setProgressShowContent(getString(R.string.get_ing));
        activityService.queryLgavActiviyDetail(1, mActivityOid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
               if (values == null || values.isEmpty()) {
                    T.showShort(mContent, R.string.prompt_network_receiving_data_error);
                    return;
                }
                LgavActivityDetailVO detailVo = (LgavActivityDetailVO) values.get(0);
                if (detailVo == null)
                    return;
                bindViewData(detailVo);

            }


            @Override
            public void onError(String msg, String content) {
                T.showShort(mContent, msg);
            }
        });
    }

    /**
     * @param detailVo
     */
    private void bindViewData(LgavActivityDetailVO detailVo) {
        mTvLgavActivityTitle.setText(detailVo.getTitle());
        mTvLgavActivityaddress.setText(getActivityAddress(detailVo));
        mTvLgavActivitymodality.setText(detailVo.getWay());
        mTvLgavActivityjionpeople.setText(detailVo.getParticipant());
        mTvLgavActivitychargepeople.setText(detailVo.getCharge());
        mTvLgavActivityhostunit.setText(detailVo.getSponsor());
        mTvLgavActivityunit.setText(detailVo.getCosponsor());
        if (StringUtil.isEmpty(detailVo.getIntroduction())) {
            mRllgavActivityInfomContent.setVisibility(View.GONE);
        }else {
            mRllgavActivityInfomContent.setVisibility(View.VISIBLE);
            String string = Html.fromHtml(detailVo.getIntroduction()).toString();
            mTvLgavActivityDetailContent.setText(string);
        }
        mTvLgavActivityStarttime.setText(detailVo.getActivityStartTime());
        mTvLgavActivityEndtime.setText(detailVo.getActivityEndTime());
    }


    private void initView() {
        mContent = this;
        mTvLgavActivityTitle = (TextView) findViewById(R.id.tv_lgav_activity_title);
        mTvLgavActivityTitle.setOnClickListener(this);
        mTvLgavActivityStarttime = (TextView) findViewById(R.id.tv_lgav_activitystarttime);
        mTvLgavActivityEndtime = (TextView) findViewById(R.id.tv_lgav_activityendtime);
        mTvLgavActivityStarttime.setOnClickListener(this);
        mTvLgavActivityaddress = (TextView) findViewById(R.id.tv_lgav_activityaddress);
        mTvLgavActivityaddress.setOnClickListener(this);
        mTvLgavActivitymodality = (TextView) findViewById(R.id.tv_lgav_activitymodality);
        mTvLgavActivitymodality.setOnClickListener(this);
        mTvLgavActivityjionpeople = (TextView) findViewById(R.id.tv_lgav_activityjionpeople);
        mTvLgavActivityjionpeople.setOnClickListener(this);
        mTvLgavActivitychargepeople = (TextView) findViewById(R.id.tv_lgav_activitychargepeople);
        mTvLgavActivitychargepeople.setOnClickListener(this);
        mTvLgavActivityhostunit = (TextView) findViewById(R.id.tv_lgav_activityhostunit);
        mTvLgavActivityhostunit.setOnClickListener(this);
        mTvLgavActivityunit = (TextView) findViewById(R.id.tv_lgav_activityunit);
        mTvLgavActivityunit.setOnClickListener(this);
        mTvLgavActivityDetailContent = (TextView) findViewById(R.id.tv_lgav_activity_detailContent);
        mTvLgavActivityDetailContent.setOnClickListener(this);
        mRllgavActivityInfomContent = (RelativeLayout) findViewById(R.id.rl_lgav_activity_infomContent);
        mRllgavActivityInfomContent.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

    }

    private String getActivityAddress(LgavActivityDetailVO detailVo) {
        StringBuffer buffer = new StringBuffer();
        String provinceName = detailVo.getProvinceName();
        String cityName = detailVo.getCityName();
        String countyName = detailVo.getCountyName();
        String provinceName1 = DataManage.getInstance().getAreaStr(detailVo.getProvince());
        String cityName1 = DataManage.getInstance().getAreaStr(detailVo.getCity());
        String countyName1 = DataManage.getInstance().getAreaStr(detailVo.getCounty());
        if (!StringUtil.isEmpty(provinceName)) {
            buffer.append(provinceName);
        } else {
            buffer.append(provinceName1);
        }
        if (StringUtil.isEmpty(cityName)) {
            buffer.append(cityName1);
        } else {
            buffer.append(cityName);
        }
        if (StringUtil.isEmpty(countyName)) {
            buffer.append(countyName1);
        } else {
            buffer.append(countyName);
        }
        if (!StringUtil.isEmpty(detailVo.getAddress())) {
            buffer.append(detailVo.getAddress());
        }

        return buffer.toString();
    }

}
