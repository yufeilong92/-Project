package com.lawyee.apppublic.util;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.nostra13.universalimageloader.core.ImageLoader;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.util
 * @Description: $todo$
 * @author: YFL
 * @date: 2017/7/20 10:20
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class ShowOrHide {
    /**
     * 公众选中匿名
     */
    private static final String ANONYMOUSFLAG = "true";

    /**
     * 过滤特殊字符规则
     */
    private static final String RULE = "^[\\u4E00-\\u9FA5A-Za-z0-9]+$";

    public interface GetInputOutString {
        /**
         * 用户输入内容
         *
         * @param content
         */
        public void inputOutString(String content);

        /**
         * 用户点击取消
         */
        public void dismissDialog();
    }

    private GetInputOutString inputOutString = null;

    public GetInputOutString getInputOutString() {
        return inputOutString;
    }

    public void setInputOutString(GetInputOutString inputOutString) {
        this.inputOutString = inputOutString;
    }

    public static void showOrHide(Object o, ImageView iv) {
        if (o != null && iv != null) {
            if (o instanceof RelativeLayout) {
                RelativeLayout layout;
                layout = (RelativeLayout) o;
                if (layout.getVisibility() == View.GONE) {
                    layout.setVisibility(View.VISIBLE);
                    iv.setImageResource(R.mipmap.icon_lawvote_down);
                } else if (layout.getVisibility() == View.VISIBLE) {
                    layout.setVisibility(View.GONE);
                    iv.setImageResource(R.mipmap.icon_lawvote_packup);
                }

            } else if (o instanceof LinearLayout) {
                LinearLayout layout;
                layout = (LinearLayout) o;
                if (layout.getVisibility() == View.GONE) {
                    layout.setVisibility(View.VISIBLE);
                    iv.setImageResource(R.mipmap.icon_lawvote_down);
                } else if (layout.getVisibility() == View.VISIBLE) {
                    layout.setVisibility(View.GONE);
                    iv.setImageResource(R.mipmap.icon_lawvote_packup);
                }
            } else if (o instanceof RecyclerView) {
                RecyclerView rlv;
                rlv = (RecyclerView) o;
                if (rlv.getVisibility() == View.GONE) {
                    rlv.setVisibility(View.VISIBLE);
                    iv.setImageResource(R.mipmap.icon_lawvote_down);
                } else if (rlv.getVisibility() == View.VISIBLE) {
                    rlv.setVisibility(View.GONE);
                    iv.setImageResource(R.mipmap.icon_lawvote_packup);
                }
            } else if (o instanceof ImageView) {
                ImageView image;
                image = (ImageView) o;
                if (image.getVisibility() == View.GONE) {
                    image.setVisibility(View.VISIBLE);
                    iv.setImageResource(R.mipmap.icon_lawvote_down);
                } else if (image.getVisibility() == View.VISIBLE) {
                    image.setVisibility(View.GONE);
                    iv.setImageResource(R.mipmap.icon_lawvote_packup);
                }

            }
        }
    }

    /**
     * @param rlv  法治人物
     * @param rlv1 法治事件
     * @param btn  提交按钮
     */
    public static void showOrHideBtn(RecyclerView rlv, RecyclerView rlv1, Button btn) {
        if (rlv == null || rlv1 == null || btn == null)
            return;
        if (rlv.getVisibility() == View.VISIBLE || rlv1.getVisibility() == View.VISIBLE) {
            btn.setVisibility(View.VISIBLE);
        }
        if (rlv.getVisibility() == View.GONE && rlv1.getVisibility() == View.GONE) {
            btn.setVisibility(View.GONE);
        }

    }

    public static void showDataDialog(Context context, final TextView tv) {
        LayoutInflater inflater = LayoutInflater.from(context);
        final View view = inflater.inflate(R.layout.dialog_datepicker, null);
        new MaterialDialog.Builder(context)
                .customView(view, false)
                .positiveText(android.R.string.ok)
                .negativeText(android.R.string.cancel)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        DatePicker mDate = (DatePicker) view.findViewById(R.id.datePicker);
                        int year = mDate.getYear();
                        int month = mDate.getMonth() + 1;
                        int dayOfMonth = mDate.getDayOfMonth();
                        tv.setText(year + "-" + month + "-" + dayOfMonth);
                    }
                })
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    /**
     * @param context 上下文
     * @param tv      显示控件
     */
    public static void getDialogYMDHms(final Context context, final TextView tv) {
        LayoutInflater inflater = LayoutInflater.from(context);
        final View view = inflater.inflate(R.layout.dialog_datepickermedia, null);
        final DatePicker mDate = (DatePicker) view.findViewById(R.id.datePicker);
        final TimePicker timePicker = (TimePicker) view.findViewById(R.id.timepick);
        Button btncancel = (Button) view.findViewById(R.id.btn_cancel);
        final Button btnOK = (Button) view.findViewById(R.id.btn_sure);

        MaterialDialog.Builder builder = new MaterialDialog.Builder(context);
        builder
                .customView(view, false);
        final MaterialDialog dialog = builder.build();
        dialog.show();
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDate.getVisibility() == View.VISIBLE && timePicker.getVisibility() == View.GONE) {
                    dialog.dismiss();
                } else if (mDate.getVisibility() == View.GONE && timePicker.getVisibility() == View.VISIBLE) {
                    timePicker.setVisibility(View.GONE);
                    mDate.setVisibility(View.VISIBLE);
                    btnOK.setText("设置时分");
                    return;
                }
            }
        });
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int year=0000, month = 00, dayOfMonth = 00,hour=00,minute=00;
                if (timePicker.getVisibility() == View.GONE && mDate.getVisibility() == View.VISIBLE) {
                    btnOK.setText(context.getResources().getString(R.string.dl_btn_ok));
                    timePicker.setVisibility(View.VISIBLE);
                    mDate.setVisibility(View.GONE);
                } else if (timePicker.getVisibility() == View.VISIBLE && mDate.getVisibility() == View.GONE) {
                    year = mDate.getYear();
                    month = mDate.getMonth() + 1;
                    dayOfMonth = mDate.getDayOfMonth();
                    int currentApiVersion = android.os.Build.VERSION.SDK_INT;
                    if (currentApiVersion > android.os.Build.VERSION_CODES.LOLLIPOP_MR1){
                        hour = timePicker.getHour();
                        minute = timePicker.getMinute();
                    } else {
                        hour = timePicker.getCurrentHour();
                        minute = timePicker.getCurrentMinute();
                    }
                   tv.setText(year + "-" + month + "-" + dayOfMonth+" "+hour+":"+minute+":00");
                   dialog.dismiss();
                }
            }
        });

    }

    /**
     * @param context
     * @param inputOutString 弹出输入内容回调
     */
    public static void ShowInputBoxDialog(final Context context, final GetInputOutString inputOutString) {
        LayoutInflater inflater = LayoutInflater.from(context);
        final String result = "";
        final View view = inflater.inflate(R.layout.input_dialog, null);
        final EditText etInputAnwser = (EditText) view.findViewById(R.id.et_input_anwser);
        //处理特殊字符
//        InputFilter[] emojiFilters = {getInputFilter(context)};
//        etInputAnwser.setFilters(emojiFilters);
        Button btncancel = (Button) view.findViewById(R.id.cancel);
        Button btnOK = (Button) view.findViewById(R.id.sure);
        MaterialDialog.Builder builder = new MaterialDialog.Builder(context);

        builder

                .customView(view, false)
                .cancelable(false)
//                .positiveText(android.R.string.ok)
//                .negativeText(android.R.string.cancel)
//                .onPositive(new MaterialDialog.SingleButtonCallback() {
//                    @Override
//                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
//                        String etInputContent = etInputAnwser.getText().toString().trim();
//                        inputOutString.inputOutString(etInputContent);
//                        dialog.dismiss();
//                    }
//                })
//
//                .onNegative(new MaterialDialog.SingleButtonCallback() {
//                    @Override
//                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
//                        inputOutString.dismissDialog();
//                        dialog.dismiss();
//                    }
//                })
        ;
        // .show();
        final MaterialDialog dialog = builder.build();
        dialog.show();
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String etInputContent = etInputAnwser.getText().toString().trim();
                if (StringUtil.isEmpty(etInputContent)) {
                    T.showShort(context, context.getString(R.string.please_answer_enmpty));
                    return;
                }
                inputOutString.inputOutString(etInputContent);
                dialog.dismiss();

            }
        });
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputOutString.dismissDialog();
                dialog.dismiss();
            }
        });


    }

    /**
     * @param mContext      上下文
     * @param address       图片id
     * @param iv            显示图片的控件
     * @param anonymousFlag
     */
    public static void showPhotoPicture(Context mContext, String address, ImageView iv, String anonymousFlag) {
        if (StringUtil.isEmpty(address)) {
            iv.setImageResource(R.drawable.ic_session_avatar);
            return;
        }
        //匿名显示默认头像
        if (anonymousFlag.equals(ANONYMOUSFLAG)) {
            iv.setImageResource(R.drawable.ic_session_avatar);
            return;
        }
        ImageLoader.getInstance().displayImage(UrlUtil.getImageFileUrl(mContext, address), iv);
    }

    /**
     * 优先返回内容
     *
     * @param tag  内容
     * @param tag1 内容
     * @return
     */
    public static String getStringWithStr(String tag, String tag1) {
        if (!StringUtil.isEmpty(tag)) {
            return tag;
        }
        if (!StringUtil.isEmpty(tag1)) {
            return tag1;
        }
        return "";
    }

    /**
     * 过滤特殊字符
     *
     * @param context
     * @return
     */
    private static InputFilter getInputFilter(final Context context) {
        InputFilter inputFilter = new InputFilter() {
            Pattern pattern = Pattern.compile(RULE);

            @Override
            public CharSequence filter(CharSequence charSequence, int i, int i1, Spanned spanned, int i2, int i3) {
                Matcher matcher = pattern.matcher(charSequence);
                if (!matcher.find()) {
                    T.showShort(context, "只允许输入中文、字母、数字");
                    return "";
                } else {
                    return null;
                }

            }
        };
        return inputFilter;
    }
}
