package com.lawyee.apppublic.util;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.TimeUtil;

import java.math.BigDecimal;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.util
 * @Description: 时间计算差
 * @author: YFL
 * @date: 2017/9/27 8:39
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class TimeSampUtil {
    /**
     * 获取当前时间戳
     *
     * @param date 当时时间
     * @return
     */
    public static String getStringTimeStamp(String date) {
        if (StringUtil.isEmpty(date))
            return "";
        String commonDateStr = TimeUtil.getCommonDateStr(date);
        long nowTime = TimeUtil.intervalNow(commonDateStr);
        String result = "";
        long ms = nowTime / 1000;
        BigDecimal decimal = new BigDecimal(ms).setScale(0, BigDecimal.ROUND_HALF_UP);
        //秒数
        long longNow = decimal.longValue();
        long temp = 0;
        if (longNow < 60) {
            result = "刚刚";
        } else if ((temp = longNow / 60) < 60) {
            result = temp + "分前";
        } else if ((temp = temp / 60) < 24) {
            result = temp + "小时前";
        } else if ((temp = temp / 24) < 30) {
            result = temp + "天前";
        } else if ((temp = temp / 30) < 12) {
            result = temp + "月前";
        } else {
            temp = temp / 12;
            result = temp + "年前";
        }
        return result;
    }

    private static final int MIN_CLICK_DELAY_TIME = 1000;
    private static long lastClickTime = 0;

    /***
     * 处理多次点击问题
     * @return
     */
    public static boolean handleOnDoubleClick() {
        long l = System.currentTimeMillis();
        if (l - lastClickTime > MIN_CLICK_DELAY_TIME) {
            lastClickTime = l;
           return true;
        }
        return false;
    }


}
