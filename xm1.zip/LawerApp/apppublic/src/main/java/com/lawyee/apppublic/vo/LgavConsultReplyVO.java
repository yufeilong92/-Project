package com.lawyee.apppublic.vo;

import net.lawyee.mobilelib.vo.BaseVO;

import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: $todo$
 * @author: YFL
 * @date: 2017/10/13 16:46
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavConsultReplyVO extends BaseVO{

    private static final long serialVersionUID = -7714245753847385647L;
    /**
     *律师或顾问id"
     */
    private String userId;
    /**
     *律师或顾问名称",
     */
    private String userName;
    /**
     *用户类型，1律师团队、2户籍地顾问、3工作地顾问、4居住地顾问",
     */
    private String userType;
    /**
     *律师或顾问头像",
     */
    private String userPhoto;
    /**
     *获得解答权时间",
     */
    private String gainTime;
    /**
     *解答状态，-1取消、0未回复、1已回复、2已超时",
     */
    private String gainStatus;
    /**
     *回复内容",
     */
    private String replyContent;
    /**
     *回复时间",
     */
    private String replyTime;
    /**
     *评价等级",
     */
    private String evaluateLevel;
    /**
     *评价时间",
     */
    private String evaluateContent;
    /**
     *评价内容"
     */
    private String evaluateTime;

    /**
     *  追答追问列表
     */
    private List<LgavConsultReplyAskVO>asks;
    private String consultId;

    public String getConsultId() {
        return consultId;
    }

    public void setConsultId(String consultId) {
        this.consultId = consultId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getGainTime() {
        return gainTime;
    }

    public void setGainTime(String gainTime) {
        this.gainTime = gainTime;
    }

    public String getGainStatus() {
        return gainStatus;
    }

    public void setGainStatus(String gainStatus) {
        this.gainStatus = gainStatus;
    }

    public String getReplyContent() {
        return replyContent;
    }

    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent;
    }

    public String getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(String replyTime) {
        this.replyTime = replyTime;
    }

    public String getEvaluateLevel() {
        return evaluateLevel;
    }

    public void setEvaluateLevel(String evaluateLevel) {
        this.evaluateLevel = evaluateLevel;
    }

    public String getEvaluateContent() {
        return evaluateContent;
    }

    public void setEvaluateContent(String evaluateContent) {
        this.evaluateContent = evaluateContent;
    }

    public String getEvaluateTime() {
        return evaluateTime;
    }

    public void setEvaluateTime(String evaluateTime) {
        this.evaluateTime = evaluateTime;
    }

    public List<LgavConsultReplyAskVO> getAsks() {
        return asks;
    }

    public void setAsks(List<LgavConsultReplyAskVO> asks) {
        this.asks = asks;
    }
}
