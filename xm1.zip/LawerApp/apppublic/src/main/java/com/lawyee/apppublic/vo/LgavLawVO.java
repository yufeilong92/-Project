package com.lawyee.apppublic.vo;

import android.content.Context;

import net.lawyee.mobilelib.utils.TimeUtil;
import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 以案释法
 * @author: YFL
 * @date: 2017/12/27 15:33
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavLawVO extends BaseVO {
    private static final long serialVersionUID = -750578607931564761L;
    /**
     *"通知ID"
     */
    private String oid;
    /**
     *"供稿标题",
     */
    private String title;
    /**
     *"标题图片",
     */
    private String titlePic;
    /**
     *微信url",
     */
    private String wechatUrl;
    /**
     *发布时间，yyyy-MM-dd",
     */
    private String publishDatetime;
    /**
     *"供稿时间，yyyy-MM-dd "
     */
    private String feedsTime;

    /**
     * 发布标题
     * @return
     */
    private String wechatTitle;

    public String getWechatTitle() {
        return wechatTitle;
    }

    public void setWechatTitle(String wechatTitle) {
        this.wechatTitle = wechatTitle;
    }

    @Override
    public String getOid() {
        return oid;
    }

    @Override
    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitlePic() {
        return titlePic;
    }

    public void setTitlePic(String titlePic) {
        this.titlePic = titlePic;
    }

    public String getWechatUrl() {
        return wechatUrl;
    }

    public void setWechatUrl(String wechatUrl) {
        this.wechatUrl = wechatUrl;
    }

    public String getPublishDatetime() {
        return TimeUtil.getYMDT(publishDatetime);
    }

    public void setPublishDatetime(String publishDatetime) {
        this.publishDatetime = publishDatetime;
    }

    public String getFeedsTime() {
        return TimeUtil.getYMDT(feedsTime);
    }

    public void setFeedsTime(String feedsTime) {
        this.feedsTime = feedsTime;
    }

    public static String dataFileName(Context context, String filename) {
        return dataFileName(context, serialVersionUID, filename);
    }
}
