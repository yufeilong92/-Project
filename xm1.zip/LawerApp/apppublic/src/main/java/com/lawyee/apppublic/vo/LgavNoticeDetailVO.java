package com.lawyee.apppublic.vo;

import android.content.Context;

import net.lawyee.mobilelib.Constants;
import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.TimeUtil;
import net.lawyee.mobilelib.vo.BaseVO;

import java.util.Date;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 通知公告详情vo
 * @author: YFL
 * @date: 2017/10/17 15:58
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavNoticeDetailVO extends BaseVO {
    private static final long serialVersionUID = -4332834358611301600L;
    /**
     * 标题
     */
    private String title;
    /**
     * 类型
     */
    private String category;
    /**
     * 内容
     */
    private String content;
    /**
     * 发送人
     */
    private String sender;
    /**
     * 最小有效期，yyyy-MM-dd
     */
    private String minExpiryDate;
    /**
     * 最大有效期，yyyy-MM-dd
     */
    private String maxExpiryDate;
    /**
     * 阅读状态（0-未读，1-已读）
     */
    private String readStatus;
    /**
     * 阅读时间，yyyy-MM-dd
     */
    private String readTime;
    /**
     * 是否置顶
     */
    private String isTop;
    /**
     * 发布时间，yyyy-MM-dd
     */
    private String publishDate;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMinExpiryDate() {
        return minExpiryDate;
    }

    public void setMinExpiryDate(String minExpiryDate) {
        this.minExpiryDate = minExpiryDate;
    }

    public String getMaxExpiryDate() {
        return maxExpiryDate;
    }

    public void setMaxExpiryDate(String maxExpiryDate) {
        this.maxExpiryDate = maxExpiryDate;
    }

    public String getReadStatus() {
        return readStatus;
    }

    public void setReadStatus(String readStatus) {
        this.readStatus = readStatus;
    }

    public String getReadTime() {
        return readTime;
    }

    public void setReadTime(String readTime) {
        this.readTime = readTime;
    }

    public String getIsTop() {
        return isTop;
    }

    public void setIsTop(String isTop) {
        this.isTop = isTop;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public static String datafileName(Context context) {
        return dataFileName(context, serialVersionUID);
    }

    public String getDataFileName(Context c) {
        return Constants.getDataStoreDir(c)
                + Constants.CSTR_DETAILDIR
                + getOid()
                + TimeUtil.dateToString(
                TimeUtil.strToDate(getPublishDate(), new Date()),
                "yyyyMMddHHmmss") + ".pd";
    }
    /**
     * 返回详情HTML标题
     *
     * @return
     */
    public String getHtmlTitle() {
        String result = "<br/><div align=\"center\" style=\"font-size: 16pt;\"><font color=\"#333333\"><strong>"
                + title + "</strong></font></div><br/>";
        return result;
    }
    /**
     * 返回详情HTML子标题
     *
     * @return
     */
    public String getHtmlSubTitle() {
        String result = "<div align=\"center\" style=\"margin-top: 8px;margin-bottom: 8px;font-size: 10.5pt;\">" +
                "<font color=\"#666666\">发布机构:</font>" +
                "<font color=\"#999999\">"+((StringUtil.isEmpty(getSender())) ? ""
                : getSender())
                +"&nbsp;&nbsp;</font>" +
                "<font color=\"#666666\">发布时间:</font>" +
                "<font color=\"#999999\">"+ TimeUtil.dateToString(TimeUtil.strToDate(getPublishDate(),null),"yyyy-MM-dd")+"</font>" +
                "</div>" +
                "<div style=\"height:0;border-bottom:1px solid #999999;margin-bottom: 8px;margin-right: 8px;margin-left: 8px\"></div>";
        return result;
    }
}
