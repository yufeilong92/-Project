package com.lawyee.apppublic.vo;

import android.content.Context;

import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 通知公告listvO
 * @author: YFL
 * @date: 2017/10/17 15:50
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavNoticeVO extends BaseVO {
    private static final long serialVersionUID = -237197427610357145L;
    /**
     * 标题
     */
    private String title;
    /**
     * 类型
     */
    private String category;
    /**
     * 最小有效期，yyyy-MM-dd
     */
    private String minExpiryDate;
    /**
     * 最大有效期，yyyy-MM-dd"
     */
    private String maxExpiryDate;
    /**
     * 阅读状态（0-未读，1-已读）
     */
    private String readStatus;
    /**
     * 阅读时间，yyyy-MM-dd
     */
    private String readTime;
    /**
     * 是否置顶
     */
    private String isTop;
    /**
     * 发布时间，yyyy-MM-dd"
     */
    private String publishDate;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMinExpiryDate() {
        return minExpiryDate;
    }

    public void setMinExpiryDate(String minExpiryDate) {
        this.minExpiryDate = minExpiryDate;
    }

    public String getMaxExpiryDate() {
        return maxExpiryDate;
    }

    public void setMaxExpiryDate(String maxExpiryDate) {
        this.maxExpiryDate = maxExpiryDate;
    }

    public String getReadStatus() {
        return readStatus;
    }

    public void setReadStatus(String readStatus) {
        this.readStatus = readStatus;
    }

    public String getReadTime() {
        return readTime;
    }

    public void setReadTime(String readTime) {
        this.readTime = readTime;
    }

    public String getIsTop() {
        return isTop;
    }

    public void setIsTop(String isTop) {
        this.isTop = isTop;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public static String datafileName(Context context) {
        return dataFileName(context, serialVersionUID);
    }
}
