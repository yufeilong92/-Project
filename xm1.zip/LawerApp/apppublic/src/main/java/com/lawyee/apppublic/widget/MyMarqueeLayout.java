package com.lawyee.apppublic.widget;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.example.uustrong.text4
 * @Description: ${todo}(用一句话描述该文件做什么)
 * @author: uustrong
 * @date: 2017/9/25 14:53
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.vo.MarqueeBean;

import java.util.ArrayList;


public class MyMarqueeLayout extends LinearLayout implements OnClickListener, AnimationListener{

    private Context mContext;
    private FrameLayout mainLayout;
    private LinearLayout oneLayout, twoLayout;
    private TextView oneTitleTV, twoTitleTV;
    private ArrayList<MarqueeBean> arrayList = new ArrayList<MarqueeBean>();
    private int index;
    private int h;
    private onClickPositionListener positionListener;

    public MyMarqueeLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        initView();
    }

    public MyMarqueeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        initView();
    }

    public MyMarqueeLayout(Context context) {
        super(context);
        this.mContext = context;
        initView();
    }


    private void initView(){
        View view = LayoutInflater.from(mContext).inflate(R.layout.base_marqueelayout_item, null,false);
        view.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        this.addView(view);//把view添加到我们的MyMarqueeLayout里并设置大小
        measureView(view);//计算跑马灯显示区的大小
        h = view.getMeasuredHeight();
        mainLayout = (FrameLayout)view.findViewById(R.id.marqueelayout_layout);
        oneLayout = (LinearLayout)view.findViewById(R.id.marqueelayout_one);
        twoLayout = (LinearLayout)view.findViewById(R.id.marqueelayout_two);
        oneTitleTV = (TextView)view.findViewById(R.id.marqueelayout_one_title);
        twoTitleTV = (TextView)view.findViewById(R.id.marqueelayout_two_title);

        if(arrayList.size() >= 2){//初始化文本
            oneTitleTV.setText(arrayList.get(0).getTitle());
            twoTitleTV.setText(arrayList.get(1).getTitle());
        }
        mainLayout.setOnClickListener(this);//给内容显示区添加点击事件
    }

    /**
     * 计算子view 大小（注意这个方面只能在LinearLayout下）
     * @param childView
     */
    private void measureView(View childView) {
        LayoutParams p = (LayoutParams) childView.getLayoutParams();
        if (p == null) {
            p = (LayoutParams) new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        int childWidthSpec = ViewGroup.getChildMeasureSpec(0, 0 + 0, p.width);
        int height = p.height;
        int childHeightSpec;
        if (height > 0) {
            childHeightSpec = MeasureSpec.makeMeasureSpec(height,
                    MeasureSpec.EXACTLY);
        } else {
            childHeightSpec = MeasureSpec.makeMeasureSpec(0,
                    MeasureSpec.UNSPECIFIED);
        }
        childView.measure(childWidthSpec, childHeightSpec);
    }

    /**
     * 动画效果
     * @param firstLayout
     * @param seconedLayout
     */
    private void startAnim(LinearLayout firstLayout, LinearLayout seconedLayout){
        TranslateAnimation t1 = new TranslateAnimation(0, 0, 0, -h);// 水平动画
        t1.setDuration(500);
        t1.setFillAfter(true);
        t1.setStartOffset(3000);// 延迟1秒
        TranslateAnimation t2 = new TranslateAnimation(0, 0, h, 0);// 水平动画
        t2.setDuration(500);
        t2.setStartOffset(3000);
        t2.setFillAfter(true);
        firstLayout.startAnimation(t1);
        seconedLayout.startAnimation(t2);
        t1.setAnimationListener(this);//添加动画监听
    }

    /**
     * 填充数据
     * @param list
     */
    public void setList(ArrayList<MarqueeBean> list){
        stop();
        index=0;
        this.arrayList = list;
        if(arrayList.size() == 1){
            oneTitleTV.setText(arrayList.get(0).getTitle());
        }
        if(arrayList.size() == 2){
            oneTitleTV.setText(arrayList.get(0).getTitle());
            twoTitleTV.setText(arrayList.get(1).getTitle());
        }
    }

    public void stop(){
        oneLayout.clearAnimation();
        twoLayout.clearAnimation();
    }
    /**
     *
     *
     */
    public void start(){
        if(arrayList.size() > 1){ //只有内容条数大于1的时候 才实现跑马灯动画效果
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startAnim(oneLayout, twoLayout);
                }
            }, 2000);
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.marqueelayout_layout:
                //根据计数器index 得到点击的位置
                if(positionListener != null){
                    if(index < arrayList.size()){
                        positionListener.onClick(index);
                    }else{
                        int position = (index)%arrayList.size();
                        positionListener.onClick(position);
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onAnimationStart(Animation animation) {
    }

    @Override
    public void onAnimationEnd(Animation animation) {
        if(arrayList.size()==1){
            return;
        }
        int position = (index+2)%arrayList.size();//找到下一个显示内容
        if(index%2 == 0){ // 根据计数器 动态填充TextView 内容
            oneTitleTV.setText(arrayList.get(position).getTitle());
            startAnim(twoLayout, oneLayout);
        }else{
            twoTitleTV.setText(arrayList.get(position).getTitle());
            startAnim(oneLayout, twoLayout);
        }
        index ++;
    }

    @Override
    public void onAnimationRepeat(Animation animation) {
    }

    /**
     * 走马灯 点击位置 接口类
     * @author YC
     */
    public interface onClickPositionListener {
        void onClick(int position);
    }

    public void setListener(onClickPositionListener listener){
        this.positionListener = listener;
    }
}