package com.lawyee.apppublic.widget.myDateView;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

/**
 *  原版DatePicker
 */
public class DatePicker2 extends LinearLayout {
    private DPTManager mTManager;// 主题管理器
    private DPLManager mLManager;// 语言管理器

    public MonthView getMonthView() {
        return monthView;
    }

    private MonthView monthView;// 月视图
    private TextView tvYear, tvMonth;// 年份 月份显示
    private TextView tvEnsure;// 确定按钮显示

    private int lastXIntercept, lastYIntercept, lastX, lastY;


    private DatePicker.OnDateSelectedListener onDateSelectedListener;// 日期多选后监听

    public DatePicker2(Context context) {
        this(context, null);
    }

    public DatePicker2(final Context context, AttributeSet attrs) {
        super(context, attrs);
        mTManager = DPTManager.getInstance();
        mLManager = DPLManager.getInstance();

        // 设置排列方向为竖向
        setOrientation(VERTICAL);

        LayoutParams llParams =
                new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

        // 标题栏根布局
        RelativeLayout rlTitle = new RelativeLayout(context);
        rlTitle.setBackgroundColor(mTManager.colorTitleBG());
        int rlTitlePadding = MeasureUtil.dp2px(context, 10);
        rlTitle.setPadding(rlTitlePadding, rlTitlePadding, rlTitlePadding, rlTitlePadding);

        // 周视图根布局
        LinearLayout llWeek = new LinearLayout(context);
        llWeek.setBackgroundColor(mTManager.colorTitleBG());
        llWeek.setOrientation(HORIZONTAL);
        int llWeekPadding = MeasureUtil.dp2px(context, 3);
        llWeek.setPadding(0, llWeekPadding, 0, llWeekPadding);
        LayoutParams lpWeek = new LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lpWeek.weight = 1;

        // 标题栏子元素布局参数
        RelativeLayout.LayoutParams lpYear =
                new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lpYear.addRule(RelativeLayout.CENTER_VERTICAL);
        RelativeLayout.LayoutParams lpMonth =
                new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lpMonth.addRule(RelativeLayout.CENTER_IN_PARENT);
        RelativeLayout.LayoutParams lpEnsure =
                new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lpEnsure.addRule(RelativeLayout.CENTER_VERTICAL);
        lpEnsure.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

        // --------------------------------------------------------------------------------标题栏
        // 年份显示
        tvYear = new TextView(context);
        tvYear.setText("2015");
        tvYear.setPadding(0,0,10,0);
        tvYear.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tvYear.setTextColor(mTManager.colorTitle());

        // 月份显示
        tvMonth = new TextView(context);
        tvMonth.setText("6月");
        tvMonth.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tvMonth.setTextColor(mTManager.colorTitle());

        // 确定显示
        tvEnsure = new TextView(context);
        tvEnsure.setText(mLManager.titleEnsure());
        tvEnsure.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tvEnsure.setTextColor(mTManager.colorTitle());
        tvEnsure.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != onDateSelectedListener) {
                    onDateSelectedListener.onDateSelected(monthView.getDateSelected());
                }
            }
        });
        LinearLayout linearLayout =new LinearLayout(context);
        linearLayout.setBackgroundColor(mTManager.colorTitleBG());
        linearLayout.setOrientation(HORIZONTAL);
        linearLayout.addView(tvYear);
        linearLayout.addView(tvMonth);
        rlTitle.addView(linearLayout, lpMonth);
        rlTitle.addView(tvEnsure, lpEnsure);

        addView(rlTitle, llParams);

        // --------------------------------------------------------------------------------周视图
        for (int i = 0; i < mLManager.titleWeek().length; i++) {
            TextView tvWeek = new TextView(context);
            tvWeek.setText(mLManager.titleWeek()[i]);
            tvWeek.setGravity(Gravity.CENTER);
            tvWeek.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            tvWeek.setTextColor(mTManager.colorTitle());
            llWeek.addView(tvWeek, lpWeek);
        }
        addView(llWeek, llParams);

        // ------------------------------------------------------------------------------------月视图
        monthView = new MonthView(context);
        monthView.setOnDateChangeListener(new MonthView.OnDateChangeListener() {
            @Override
            public void onMonthChange(int month) {
                Log.e("月",month+"");
                tvMonth.setText(month+"月");
            }

            @Override
            public void onYearChange(int year) {
                Log.e("年",year+"");
                String tmp = String.valueOf(year);
                if (tmp.startsWith("-")) {
                    tmp = tmp.replace("-", mLManager.titleBC());
                }
                tvYear.setText(tmp+"年");
            }

            @Override
            public void onAllChange(int year, int month) {

            }
        });
//        monthView.setOnDateScrollChangeListener(new MonthView.OnDateScrollChangeListener() {
//            @Override
//            public void scrollLeft(int year, int month) {
//                String str = "向左滑动=="+"年份="+year+"--月份=="+month;
//                Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void scrollRight(int year, int month) {
//                String str = "向右滑动=="+"年份="+year+"--月份=="+month;
//                Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void scrollTop(int year, int month) {
//                String str = "向上滑动=="+"年份="+year+"--月份=="+month;
//                Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void scrollBottom(int year, int month) {
//                String str = "向下滑动=="+"年份="+year+"--月份=="+month;
//                Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
//            }
//        });
        addView(monthView, llParams);
    }

    /**
     * 设置初始化年月日期
     *
     * @param year  ...
     * @param month ...
     */
    public void setDate(int year, int month) {
        if (month < 1) {
            month = 1;
        }
        if (month > 12) {
            month = 12;
        }
        monthView.setDate(year, month);
    }

    public void setDPDecor(DPDecor decor) {
        monthView.setDPDecor(decor);
    }

    /**
     * 设置日期选择模式
     *
     * @param mode ...
     */
    public void setMode(DPMode mode) {
        if (mode != DPMode.MULTIPLE) {
            tvEnsure.setVisibility(GONE);
        }
        monthView.setDPMode(mode);
    }

    /**
     * 节日标识
     * @param isFestivalDisplay
     */
    public void setFestivalDisplay(boolean isFestivalDisplay) {
        monthView.setFestivalDisplay(isFestivalDisplay);
    }

    /**
     * 今天标识
     * @param isTodayDisplay
     */
    public void setTodayDisplay(boolean isTodayDisplay) {
        monthView.setTodayDisplay(isTodayDisplay);
    }

    /**
     * 假期标识
     * @param isHolidayDisplay
     */
    public void setHolidayDisplay(boolean isHolidayDisplay) {
        monthView.setHolidayDisplay(isHolidayDisplay);
    }

    /**
     * 补休标识
     * @param isDeferredDisplay
     */
    public void setDeferredDisplay(boolean isDeferredDisplay) {
        monthView.setDeferredDisplay(isDeferredDisplay);
    }

    /**
     * 设置单选监听器
     *
     * @param onDatePickedListener ...
     */
    public void setOnDatePickedListener(DatePicker.OnDatePickedListener onDatePickedListener) {
//        if (monthView.getDPMode() != DPMode.SINGLE) {
//            throw new RuntimeException(
//                    "Current DPMode does not SINGLE! Please call setMode set DPMode to SINGLE!");
//        }
        monthView.setOnDatePickedListener(onDatePickedListener);
    }

    /**
     * 设置多选监听器
     *
     * @param onDateSelectedListener ...
     */
    public void setOnDateSelectedListener(DatePicker.OnDateSelectedListener onDateSelectedListener) {
//        if (monthView.getDPMode() != DPMode.MULTIPLE) {
//            throw new RuntimeException(
//                    "Current DPMode does not MULTIPLE! Please call setMode set DPMode to MULTIPLE!");
//        }
        this.onDateSelectedListener = onDateSelectedListener;
    }

    public void setIsSelChangeColor(boolean isSelChangeColor,int selChangeTextColor) {
        monthView.setIsSelChangeColor(isSelChangeColor,selChangeTextColor);
    }
}
