package com.lawyee.apppublic.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.ui.basiclaw.BasicLawServiceActivity;
import com.lawyee.apppublic.ui.lawyerService.LawServiceActivity;
import com.lawyee.apppublic.ui.org.JaaidActivity;
import com.lawyee.apppublic.ui.org.JamedOrgActivity;
import com.lawyee.apppublic.ui.org.JanotaOrgActivity;
import com.lawyee.apppublic.ui.org.LegalpublicityActivity;
import com.lawyee.apppublic.ui.personalcenter.MyMessageActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity;
import com.lawyee.apppublic.util.SessionIdUtil;
import com.lawyee.apppublic.util.ToLoginDialogUtil;
import com.lawyee.apppublic.vo.InfomationVO;
import com.lawyee.apppublic.vo.UserVO;
import com.oguzdev.circularfloatingactionmenu.library.FloatingActionMenu;
import com.oguzdev.circularfloatingactionmenu.library.SubActionButton;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;
import com.youth.banner.listener.OnLoadImageListener;

import net.lawyee.mobilelib.utils.StringUtil;

import java.util.ArrayList;
import java.util.List;

import static com.lawyee.apppublic.ui.BaseActivity.CSTR_EXTRA_TITLE_STR;
import static com.lawyee.apppublic.ui.lawyerService.LawServiceActivity.ISON;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity.CSTR_URL;
import static com.lawyee.apppublic.util.ToLoginDialogUtil.alertTiptoLogin;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_BASICLAWWORKER;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_JALAW;


/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.adapter
 * @Description: (首页RecycleView的Adpater)
 * @author: czq
 * @date: 2017/5/15 11:24
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class HomeAdpater extends RecyclerView.Adapter {
    /**
     * 3种类型
     */
    public static final int BANNER = 0;//横幅图片
    public static final int CENTREMODE = 1;//中间新模块入口
    public static final int CHANNEL = 2;//各模块入口
    public static final int INFO = 3;//最新资讯信息
    private Context mContext;
    private ArrayList mData = new ArrayList<InfomationVO>();
    private LayoutInflater mLayoutInflater;
    private boolean isRefresh = false;
    /**
     * 当前类型
     */
    public int currentType = BANNER;
//获取在线咨询的弹出按钮
    public FloatingActionMenu getCentreModeConsultantButton() {
        if(centreMode==null){
            return  null;
        }
        return centreMode.getMfamOnlineConsultant();
    }
    //获取在线服务的弹出按钮
    public FloatingActionMenu getCentreModeSuppoButton() {
        if(centreMode==null){
            return  null;
        }
        return centreMode.getMfamOnlineSupport();
    }
    //刷新中间视图
    public void setCenterView() {
        if(centreMode!=null) {
            centreMode.setData();
        }
    }
    CentreMode centreMode;

    public OnClickInfoServiceListener getOnItemListener() {
        return onItemListener;
    }

    public void setOnItemListener(OnClickInfoServiceListener onItemListener) {
        this.onItemListener = onItemListener;
    }

    private OnClickInfoServiceListener onItemListener = null;
    public HomeAdpater(Context context, ArrayList list) {
        this.mContext = context;
        this.mData = list;
        mLayoutInflater = LayoutInflater.from(mContext);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == BANNER) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        } else if (viewType == CENTREMODE) {
            return new CentreMode(mContext, mLayoutInflater.inflate(R.layout.centre_mode, null));
        } else if (viewType == CHANNEL) {
            return new ChannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.channer_viewpager, null));
        } else if (viewType == INFO) {
            return new InfoViewHolder(mContext, mLayoutInflater.inflate(R.layout.info_item, null));
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (isRefresh) {
            if (getItemViewType(position) == INFO) {
                InfoViewHolder seckillViewHolder = (InfoViewHolder) holder;
                seckillViewHolder.setData(mData);
            }
        } else {
            if (getItemViewType(position) == BANNER) {
                BannerViewHolder bannerViewHolder = (BannerViewHolder) holder;
                bannerViewHolder.setData();
            } else if (getItemViewType(position) == CENTREMODE) {
                 centreMode = (CentreMode) holder;
                 centreMode.setData();
            } else if (getItemViewType(position) == CHANNEL) {
                ChannerViewHolder channerViewHolder = (ChannerViewHolder) holder;
                channerViewHolder.setData();
            } else if (getItemViewType(position) == INFO) {
                InfoViewHolder seckillViewHolder = (InfoViewHolder) holder;
                seckillViewHolder.setData(mData);
            }
        }

    }

    /**
     * 根据位置得到类型-系统调用
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        switch (position) {
            case BANNER:
                currentType = BANNER;
                break;
            case CENTREMODE:
                currentType = CENTREMODE;
                break;
            case CHANNEL:
                currentType = CHANNEL;
                break;
            case INFO:
                currentType = INFO;
                break;
        }
        return currentType;
    }

    @Override
    public int getItemCount() {
        return 4;
    }

    //横幅Viewholder
    class BannerViewHolder extends RecyclerView.ViewHolder {
        private Context mContext;
        private Banner banner;

        public BannerViewHolder(Context mContext, View view) {
            super(view);
            this.mContext = mContext;
            this.banner = (Banner) itemView.findViewById(R.id.banner);
        }

        //设置数据
        public void setData() {
            final List<Integer> imgUrls = new ArrayList<>();
            imgUrls.add(R.drawable.ic_banner);
            imgUrls.add(R.drawable.ic_banner2);
            imgUrls.add(R.drawable.ic_banner3);
            //设置循环指示器
            banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
            //设置播放样式
            banner.setBannerAnimation(Transformer.Default);
            banner.setImages(imgUrls, new OnLoadImageListener() {
                @Override
                public void OnLoadImage(ImageView view, Object url) {
                    view.setImageResource((Integer) url);
                }
            });
        }
    }
//中间模块的
    class CentreMode extends RecyclerView.ViewHolder {
        private RelativeLayout mRlOnlineConsultant;
        private RelativeLayout mRlOnlineSupport;
        private RelativeLayout mRlKnowledgeService;
        private RelativeLayout mRlIconInfoService;


        private FloatingActionMenu mfamOnlineConsultant;//在线咨询的弹出按钮
        private FloatingActionMenu mfamOnlineSupport;//在线服务的弹出按钮
        private Context mContext;



        public CentreMode(Context context, View itemView) {

            super(itemView);
            this.mContext = context;
            mRlOnlineConsultant= (RelativeLayout) itemView.findViewById(R.id.rl_online_consultant);
            mRlOnlineSupport= (RelativeLayout) itemView.findViewById(R.id.rl_online_support);
            mRlKnowledgeService= (RelativeLayout) itemView.findViewById(R.id.rl_knowledge_service);
            mRlIconInfoService= (RelativeLayout) itemView.findViewById(R.id.rl_icon_info_service);
            int blueSubActionButtonSize = mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_2);//弹出按钮的大小
            int blueSubActionButtonContentMargin = mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_margin2);//内容margin
            setData();
            setOnlineSupport(blueSubActionButtonSize,blueSubActionButtonContentMargin);


            mRlIconInfoService.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                  if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                      mfamOnlineSupport.close(false);
                  }
                  if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                      mfamOnlineConsultant.close(false);
                  }
                    if (onItemListener != null) {
                        onItemListener.onItemListener(v);
                    }
                }
            });
            mRlKnowledgeService.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                  //// TODO: 2017/10/18 知识服务点击
                    Intent intent = new Intent(mContext, WebViewShowActivity.class);
                    intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.knowledge_service));
                    String url =mContext.getString(R.string.url_base) +mContext.getString(R.string.url_knowledge_service);
                    intent.putExtra(CSTR_URL, url);
                    mContext.startActivity(intent);
                }
            });
        }
        //设置Textview
        private void setMyText(TextView textView, int stringId){
            textView.setText(stringId);
            textView.setTextSize(14);
          //  textView.setPadding(10,10,10,10);
            textView.setGravity(Gravity.CENTER);
            textView.setTextColor(mContext.getResources().getColor(R.color.white));
        }
        //设置subBuilder
        private void setSubBuilder(SubActionButton.Builder subBuilder,int id,int blueSubActionButtonSize,int blueSubActionButtonContentMargin ){
            subBuilder.setBackgroundDrawable(mContext.getResources().getDrawable(id));
            FrameLayout.LayoutParams blueContentParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT);
            blueContentParams.setMargins(blueSubActionButtonContentMargin,
                    blueSubActionButtonContentMargin,
                    blueSubActionButtonContentMargin,
                    blueSubActionButtonContentMargin);
            subBuilder.setLayoutParams(blueContentParams);
            FrameLayout.LayoutParams blueParams = new FrameLayout.LayoutParams(blueSubActionButtonSize, blueSubActionButtonSize);
            subBuilder.setLayoutParams(blueParams);
        }
        public  void setData(){

            int blueSubActionButtonSize = mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_2);//弹出按钮的大小
            int blueSubActionButtonContentMargin = mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_margin2);//内容margin
            final UserVO  userVO=ApplicationSet.getInstance().getUserVO();
            if(userVO!=null&&
                    (userVO.getRole().equals(CSTR_USERROLE_JALAW)||
                            userVO.getRole().equals(CSTR_USERROLE_BASICLAWWORKER))){
                if((userVO.getRole().equals(CSTR_USERROLE_JALAW)&&
                        !userVO.getLawyerTeamFlag().equals("1")&&
                        userVO.getAdviserFlag().equals("false"))||
                        (userVO.getRole().equals(CSTR_USERROLE_BASICLAWWORKER)&&userVO.getAdviserFlag().equals("true"))) {
                    mRlOnlineConsultant.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (userVO.getRole().equals(CSTR_USERROLE_JALAW)) {
                                mContext.startActivity(new Intent(mContext, MyMessageActivity.class));
                            } else {
                                Intent MyProblemintent2 = new Intent(mContext, MyProblemActivity.class);
                                MyProblemintent2.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_RODIE);
                                MyProblemintent2.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_advise_problem));
                                mContext.startActivity(MyProblemintent2);
                            }
                        }
                    });
                }else if((userVO.getLawyerTeamFlag().equals("1")&&
                        userVO.getAdviserFlag().equals("false"))||(!userVO.getLawyerTeamFlag().equals("1")&&
                        userVO.getAdviserFlag().equals("true"))
                        ){
                    if(userVO.getLawyerTeamFlag().equals("1")){
                        setOnlineConsultant(2,0,blueSubActionButtonSize,blueSubActionButtonContentMargin,true);
                    }else{
                        setOnlineConsultant(2,1,blueSubActionButtonSize,blueSubActionButtonContentMargin,true);
                    }

                }else if(userVO.getLawyerTeamFlag().equals("1")&&
                        userVO.getAdviserFlag().equals("true")){
                    setOnlineConsultant(3,0,blueSubActionButtonSize,blueSubActionButtonContentMargin,true);
                }else if(userVO.getRole().equals(CSTR_USERROLE_BASICLAWWORKER)&&
                        !userVO.getLawyerTeamFlag().equals("1")&&
                       !userVO.getAdviserFlag().equals("true")){
                    setOnlineConsultant(3,0,blueSubActionButtonSize,blueSubActionButtonContentMargin,false);
                }
            }else{
                setOnlineConsultant(3,0,blueSubActionButtonSize,blueSubActionButtonContentMargin,false);
            }
        }
        //设置在线咨询的弹出按钮
        private void setOnlineConsultant(int type , int isLawteam, int blueSubActionButtonSize, int blueSubActionButtonContentMargin, final boolean isNew){

            TextView tvOnetoone= new TextView(mContext);
          //  TextView tvLeaveWords = new TextView(mContext);
            TextView tvLaywerTeam = new TextView(mContext);
            TextView tvLegalAdviser= new TextView(mContext);
            setMyText(tvOnetoone,R.string.one_to_one);
         //   setMyText(tvLeaveWords,R.string.leave_words);
            setMyText(tvLaywerTeam,R.string.laywer_team);
            setMyText(tvLegalAdviser,R.string.legal_adviser);
            SubActionButton.Builder subBuilder1 = new SubActionButton.Builder((Activity) mContext);
            // SubActionButton.Builder subBuilder2 = new SubActionButton.Builder((Activity) mContext);
            SubActionButton.Builder subBuilder3 = new SubActionButton.Builder((Activity) mContext);
            SubActionButton.Builder subBuilder4 = new SubActionButton.Builder((Activity) mContext);
            setSubBuilder(subBuilder1,R.drawable.shape_homepage_onetonebg,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            //   setSubBuilder(subBuilder2,R.drawable.button_action_blue_selector,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            setSubBuilder(subBuilder3,R.drawable.shape_homepage_law_team_bg,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            setSubBuilder(subBuilder4,R.drawable.shape_homepage_law_advise_bg,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            if(type==2){
                if(isLawteam==0){
                    mfamOnlineConsultant = new FloatingActionMenu.Builder((Activity) mContext)
                            .setStartAngle(145) // A whole circle! 这边这个是角度的调整
                            .setEndAngle(265)//4个的角度325
                            .setRadius(mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_radius))
                            .addSubActionView(subBuilder1.setContentView(tvOnetoone).build())
                            //     .addSubActionView(subBuilder2.setContentView(tvLeaveWords).build())
                            .addSubActionView(subBuilder3.setContentView(tvLaywerTeam).build())
                           // .addSubActionView(subBuilder4.setContentView(tvLegalAdviser).build())
                            .attachTo(mRlOnlineConsultant)
                            .build();
                }else {
                    mfamOnlineConsultant = new FloatingActionMenu.Builder((Activity) mContext)
                            .setStartAngle(145) // A whole circle! 这边这个是角度的调整
                            .setEndAngle(265)//4个的角度325
                            .setRadius(mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_radius))
                            .addSubActionView(subBuilder1.setContentView(tvOnetoone).build())
                            //     .addSubActionView(subBuilder2.setContentView(tvLeaveWords).build())
                           // .addSubActionView(subBuilder3.setContentView(tvLaywerTeam).build())
                            .addSubActionView(subBuilder4.setContentView(tvLegalAdviser).build())
                            .attachTo(mRlOnlineConsultant)
                            .build();
                }

            }else {
                mfamOnlineConsultant = new FloatingActionMenu.Builder((Activity) mContext)
                        .setStartAngle(145) // A whole circle! 这边这个是角度的调整
                        .setEndAngle(265)//4个的角度325
                        .setRadius(mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_radius))
                        .addSubActionView(subBuilder1.setContentView(tvOnetoone).build())
                        //     .addSubActionView(subBuilder2.setContentView(tvLeaveWords).build())
                        .addSubActionView(subBuilder3.setContentView(tvLaywerTeam).build())
                        .addSubActionView(subBuilder4.setContentView(tvLegalAdviser).build())
                        .attachTo(mRlOnlineConsultant)
                        .build();
            }

            tvOnetoone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    if(isNew){
                        mContext.startActivity(new Intent(mContext, MyMessageActivity.class));
                    }else{
                         Intent  intent =new Intent(mContext, LawServiceActivity.class);
                         intent.putExtra(ISON, 1);
                        mContext.startActivity(intent);
                    }

                }
            });
//            tvLeaveWords.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if(mfamOnlineSupport.isOpen())  {
//                        mfamOnlineSupport.close(false);
//                    }
//                    if(mfamOnlineConsultant.isOpen()){
//                        mfamOnlineConsultant.close(false);
//                    }
//
//                }
//            });
            tvLaywerTeam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!= null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    if(isNew){
                        //律师角色进入我的问题界面
                        Intent MyProblemintent1 = new Intent(mContext, MyProblemActivity.class);
                        MyProblemintent1.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_LGAV);
                        MyProblemintent1.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_team_problem));
                        mContext.startActivity(MyProblemintent1);
                    }else {
                        UserVO userVO = ApplicationSet.getInstance().getUserVO();
                        if (userVO == null || StringUtil.isEmpty(userVO.getLoginId())) {
                            ToLoginDialogUtil.alertToLogin(mContext);
                        } else {
                            if (!userVO.isPublicUser()) {
                                alertTiptoLogin(mContext);
                            } else {

                                    Intent intent = new Intent(mContext, WebViewShowActivity.class);
                                    intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.laywer_team2));
                                    String url= mContext.getString(R.string.url_base) +
                                            mContext. getString(R.string.url_law_team) + SessionIdUtil.getUserSessionId(mContext)+
                                    mContext.getString(R.string.url_appstamp) + SessionIdUtil.getAppstamp(mContext);
                                    intent.putExtra(CSTR_URL, url);
                                    mContext.startActivity(intent);

                            }

                        }
                    }

                }
            });
            tvLegalAdviser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    if(isNew){
                        Intent MyProblemintent2 = new Intent(mContext, MyProblemActivity.class);
                        MyProblemintent2.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_RODIE);
                        MyProblemintent2.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_advise_problem));
                       mContext.startActivity(MyProblemintent2);
                    }else {
                        UserVO userVO = ApplicationSet.getInstance().getUserVO();
                        if (userVO == null || StringUtil.isEmpty(userVO.getLoginId())) {
                            ToLoginDialogUtil.alertToLogin(mContext);
                        } else {
                            if (!userVO.isPublicUser()) {
                                alertTiptoLogin(mContext);
                            } else {

                                    Intent intent = new Intent(mContext, WebViewShowActivity.class);
                                    intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.legal_adviser2));
                                    String url= mContext.getString(R.string.url_base) +
                                            mContext. getString(R.string.url_law_adviser) + SessionIdUtil.getUserSessionId(mContext)+
                                            mContext.getString(R.string.url_appstamp) + SessionIdUtil.getAppstamp(mContext);
                                    intent.putExtra(CSTR_URL, url);
                                    mContext.startActivity(intent);

                            }

                        }
                    }


                }
            });
        }
    //设置在线服务的弹出按钮
        private void setOnlineSupport(int blueSubActionButtonSize,int blueSubActionButtonContentMargin){
            TextView tvAidApplication= new TextView(mContext);
            TextView tvJamedApplication = new TextView(mContext);
            TextView tvLaywerEntrust= new TextView(mContext);
            setMyText(tvAidApplication,R.string.aid_application);
            setMyText(tvJamedApplication,R.string.jamed_application);
            setMyText(tvLaywerEntrust,R.string.laywer_entrust);

            SubActionButton.Builder subBuilder1 = new SubActionButton.Builder((Activity) mContext);
            SubActionButton.Builder subBuilder2 = new SubActionButton.Builder((Activity) mContext);
            SubActionButton.Builder subBuilder3 = new SubActionButton.Builder((Activity) mContext);
            setSubBuilder(subBuilder1,R.drawable.shape_homepage_law_team_bg,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            setSubBuilder(subBuilder2,R.drawable.shape_homepage_leave_message_bg,blueSubActionButtonSize,blueSubActionButtonContentMargin);
            setSubBuilder(subBuilder3,R.drawable.shape_homepage_onetonebg,blueSubActionButtonSize,blueSubActionButtonContentMargin);

            mfamOnlineSupport = new FloatingActionMenu.Builder((Activity) mContext)
                    .setStartAngle(270) // A whole circle! 这边这个是角度的调整
                    .setEndAngle(390)
                    .setRadius(mContext.getResources().getDimensionPixelSize(R.dimen.home_oval_radius))
                    .addSubActionView(subBuilder1.setContentView(tvAidApplication).build())
                    .addSubActionView(subBuilder2.setContentView(tvJamedApplication).build())
                    .addSubActionView(subBuilder3.setContentView(tvLaywerEntrust).build())
                    .attachTo(mRlOnlineSupport)
                    .build();
            tvAidApplication.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    mContext.startActivity(new Intent(mContext, JaaidActivity.class));
                }
            });
            tvJamedApplication.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    mContext.startActivity(new Intent(mContext, JamedOrgActivity.class));
                }
            });
            tvLaywerEntrust.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mfamOnlineSupport!=null&&mfamOnlineSupport.isOpen())  {
                        mfamOnlineSupport.close(false);
                    }
                    if(mfamOnlineConsultant!=null&&mfamOnlineConsultant.isOpen()){
                        mfamOnlineConsultant.close(false);
                    }
                    mContext.startActivity(new Intent(mContext, LawServiceActivity.class));
                }
            });
        }


        public RelativeLayout getmRlOnlineSupport() {
            return mRlOnlineSupport;
        }

        public FloatingActionMenu getMfamOnlineConsultant() {
            return mfamOnlineConsultant;
        }

        public FloatingActionMenu getMfamOnlineSupport() {
            return mfamOnlineSupport;
        }
        public RelativeLayout getmRlOnlineConsultant() {
            return mRlOnlineConsultant;
        }
    }

    //模块入口holder
    class ChannerViewHolder extends RecyclerView.ViewHolder {
        private Context mContext;
        private GridView gridView;
        private ChannerAdpater channerAdpater;

        public ChannerViewHolder(final Context mContext, View inflate) {
            super(inflate);
            this.mContext = mContext;
            gridView = (GridView) inflate.findViewById(R.id.gv_channel);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long M) {
                    String title = (String) adapterView.getItemAtPosition(i);
                    if (!TextUtils.isEmpty(title)) {
                        if (title.equals(mContext.getString(R.string.legal_aid))) {//法律援助
                            mContext.startActivity(new Intent(mContext, JaaidActivity.class));

                        } else if (title.equals(mContext.getString(R.string.legal_publicity))) {//法治宣传
                /*            Intent intent = new Intent(mContext, InformationActivity.class);
                            intent.putExtra(InformationActivity.CSTR_EXTRA_INFOTYPENAME_STRARRAY,mContext.getResources().getStringArray(R.array.FZXCInfoName));
                            intent.putExtra(InformationActivity.CSTR_EXTRA_INFOTYPEID_STRARRAY,mContext.getResources().getStringArray(R.array.FZXCInfoID));
                            intent.putExtra(InformationActivity.CSTR_EXTRA_TITLE_STR,title);*/
                            Intent intent = new Intent(mContext, LegalpublicityActivity.class);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR, title);
                            mContext.startActivity(intent);
                        } else if (title.equals(mContext.getString(R.string.lawyer_service))) {//律师服务
                            mContext.startActivity(new Intent(mContext, LawServiceActivity.class));
                        } else if (title.equals(mContext.getString(R.string.notary_public))) {//公证服务
                            Intent intent = new Intent(mContext, JanotaOrgActivity.class);
                            intent.putExtra(JanotaOrgActivity.JANOTATYPE, JanotaOrgActivity.JANOTATITLEZONE);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR, title);
                            mContext.startActivity(intent);
                        /*}else if (title.equals(mContext.getString(R.string.judicial_examination))){//司法考试
                            Intent intent = new Intent(mContext, InformationActivity.class);
                            intent.putExtra("type",0);
                            intent.putExtra("title",title);
                            mContext.startActivity(intent);*/
                        } else if (title.equals(mContext.getString(R.string.judicial_expertise))) {//鉴定机构
                            Intent intent = new Intent(mContext, JanotaOrgActivity.class);
                            intent.putExtra(JanotaOrgActivity.JANOTATYPE, JanotaOrgActivity.JANOTATITLEONE);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR, title);
                            mContext.startActivity(intent);
                        } else if (title.equals(mContext.getString(R.string.people_mediation))) {//人民调解
                            mContext.startActivity(new Intent(mContext, JamedOrgActivity.class));
                        } else if (title.equals(mContext.getString(R.string.duty_lawyers))) {
                            Intent intent1 = new Intent(mContext, WebViewShowActivity.class);
                            intent1.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.duty_lawyers));
                            String url= mContext.getString(R.string.url_base) +mContext.getString(R.string.url_duty_lawyer);
                            intent1.putExtra(CSTR_URL, url);
                            mContext.startActivity(intent1);
                        } else if (title.equals(mContext.getString(R.string.basic_legal_service))) {
                            mContext.startActivity(new Intent(mContext, BasicLawServiceActivity.class));
                        }

                    }
                }
            });
        }


        public void setData() {
            //得到数据  设置G日的view的适配器
            ArrayList<String> arrayList = new ArrayList<>();
            arrayList.add(mContext.getString(R.string.legal_aid));
            arrayList.add(mContext.getString(R.string.notary_public));
            arrayList.add(mContext.getString(R.string.people_mediation));
            arrayList.add(mContext.getString(R.string.lawyer_service));
            arrayList.add(mContext.getString(R.string.duty_lawyers));
            arrayList.add(mContext.getString(R.string.legal_publicity));
            arrayList.add(mContext.getString(R.string.judicial_expertise));
            arrayList.add(mContext.getString(R.string.basic_legal_service));
            //arrayList.add(mContext.getString(R.string.judicial_examination));
            channerAdpater = new ChannerAdpater(mContext, arrayList);
            gridView.setAdapter(channerAdpater);
        }
    }

    //最新资讯holder
    class InfoViewHolder extends RecyclerView.ViewHolder {
        public Context mContext;
        public RecyclerView mRvInfo;
        public GridLayoutManager mLayoutManager;
        public InfoAdpater mAdpater;

        public InfoViewHolder(Context context, View itemView) {
            super(itemView);
            this.mContext = context;
            mRvInfo = (RecyclerView) itemView.findViewById(R.id.rv_info);


        }

        public void setData(ArrayList<InfomationVO> list) {
            mAdpater = new InfoAdpater(list, mContext);
            mRvInfo.setAdapter(mAdpater);
            mLayoutManager = new GridLayoutManager(mContext, 1);
            mRvInfo.setLayoutManager(mLayoutManager);
            mRvInfo.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        }
    }
    //信息服务的点击回调
    public interface OnClickInfoServiceListener {
        void onItemListener(View view);
    }
}
