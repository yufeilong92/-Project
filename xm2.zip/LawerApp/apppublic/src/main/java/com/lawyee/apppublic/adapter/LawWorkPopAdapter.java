package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.jauker.widget.BadgeView;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.ui.personalcenter.MyMessageActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.ConsultListActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerEntrustActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerPCenterActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity;
import com.lawyee.apppublic.vo.JaLawWorkVO;

import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.adapter
 * @Description: 律师工作列表
 * @author: uustrong
 * @date: 2017/12/20 10:43
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class LawWorkPopAdapter extends RecyclerView.Adapter<LawWorkPopAdapter.ViewHolder> {
    private Context mContext;
    private List<JaLawWorkVO> datas;
    private ItemCallback1 itemCallback;


    public LawWorkPopAdapter(List<JaLawWorkVO> datas, Context context) {
        this.datas = datas;
        this.mContext = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.item_law_work, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
              holder.tv_text.setText(datas.get(position).getContent());
              BadgeView mBadgeView = new BadgeView(mContext);
              createBadgeView(mBadgeView, holder.iv_message_right);
              switch (datas.get(position).getType()){
                  case 1:
                      holder.iv_biao.setImageResource(R.drawable.ic_mymessage2);
                      break;
                  case 2:
                      holder.iv_biao.setImageResource(R.drawable.icon_qwpf);
                      break;
                  case 3:
                      holder.iv_biao.setImageResource(R.drawable.icon_legal_counsel);
                      break;
                  case 4:
                      holder.iv_biao.setImageResource(R.drawable.ic_law_service2);
                      break;
                  case 5:
                      holder.iv_biao.setImageResource(R.drawable.ic_mymessage2);
                      break;
                  case 6:
                      holder.iv_biao.setImageResource(R.drawable.icon_home_page);
                      holder.view_diviler.setVisibility(View.GONE);
                      break;
                  case 7:
                      holder.iv_biao.setImageResource(R.drawable.icon_duty_lawyer);
                      break;
              }
        setBadgView(mBadgeView, datas.get(position).getNoReadNum());
              holder.rl_my_message.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      Intent intent = null;
                      switch (datas.get(position).getType()){
                          case 1:
                              intent=new Intent(mContext, MyMessageActivity.class);
                               
                              break;
                          case 2:
                              intent=new Intent(mContext, MyProblemActivity.class);
                              intent.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_LGAV);
                              intent.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_team_problem));
                              break;
                          case 3:
                              intent=new Intent(mContext, MyProblemActivity.class);
                              intent.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_RODIE);
                              intent.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.law_advise_problem));
                              break;
                          case 4:
                              intent=new Intent(mContext, LawyerEntrustActivity.class);
                              break;
                          case 5:
                              intent=new Intent(mContext, ConsultListActivity.class);
                              break;
                          case 6:
                              intent=new Intent(mContext, LawyerPCenterActivity.class);
                              break;
                          case 7://值班律师跳转
                              intent=new Intent(mContext, MyProblemActivity.class);
                              intent.putExtra(MyProblemActivity.LAWYERROLE,MyProblemActivity.LAWYERROLE_LAW);
                              intent.putExtra(MyProblemActivity.CSTR_EXTRA_TITLE_STR,mContext.getResources().getString(R.string.duty_lawyer_problem));
                              break;
                      }
                      mContext.startActivity(intent);
                      if(itemCallback!=null){
                          itemCallback.onItemClicked();
                      }

                  }
              });

    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_biao;
        private ImageView iv_message_right1;
        private View iv_message_right;
        private TextView tv_text;
        private RelativeLayout rl_my_message;
        private View view_diviler;
        public ViewHolder(View itemView) {
            super(itemView);
            iv_biao = (ImageView) itemView.findViewById(R.id.iv_biao);
            iv_message_right1 = (ImageView) itemView
                    .findViewById(R.id.iv_message_right1);
            tv_text = (TextView) itemView
                    .findViewById(R.id.tv_text);
            iv_message_right= itemView
                    .findViewById(R.id.iv_message_right);
            rl_my_message= (RelativeLayout) itemView
                    .findViewById(R.id.rl_my_message);
            view_diviler=  itemView.findViewById(R.id.view_diviler1);

        }
    }
    private void createBadgeView(BadgeView badgeView, View view) {

        badgeView.setTargetView(view);
        badgeView.setBadgeGravity(Gravity.CENTER);
        badgeView.setTypeface(Typeface.create(Typeface.SANS_SERIF,
                Typeface.ITALIC));
        badgeView.setVisibility(View.GONE);
    }
    public void setBadgView(BadgeView badgeView,int num){
        if (num == 0) {
            badgeView.setVisibility(View.GONE);
        } else {
            badgeView.setVisibility(View.VISIBLE);
            if(num>99){
                badgeView.setText(R.string.num_99);
            }else {
                badgeView.setBadgeCount(num);
            }
        }
    }
    public interface ItemCallback1 {

        void onItemClicked();
    }

    public void setItemCallback(ItemCallback1 itemCallback) {
        this.itemCallback = itemCallback;
    }


}
