package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.andview.refreshview.recyclerview.BaseRecyclerAdapter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.util.UrlUtil;
import com.lawyee.apppublic.vo.LgavLawVO;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: 以案释法适配器
 * @author: YFL
 * @date: 2017/12/27 15:39
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavLawAdapter extends BaseRecyclerAdapter<LgavLawAdapter.ViewHolde> implements View.OnClickListener {


    private Context mContext;
    private ArrayList mDatas;
    private final LayoutInflater mInflater;

    public LgavLawAdapter(Context mContext, ArrayList mDatas) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        mInflater = LayoutInflater.from(mContext);
    }

    public  interface LgavLawOnClickListener{
        public void onItemClicklistener(Object item);

    }

    public LgavLawOnClickListener lawOnClickListener;

    public LgavLawOnClickListener getLawOnClickListener() {
        return lawOnClickListener;
    }

    public void setLawOnClickListener(LgavLawOnClickListener lawOnClickListener) {
        this.lawOnClickListener = lawOnClickListener;
    }

    @Override
    public ViewHolde getViewHolder(View view) {
        return new ViewHolde(view);
    }

    @Override
    public ViewHolde onCreateViewHolder(ViewGroup viewGroup, int i, boolean b) {
        View view = mInflater.inflate(R.layout.lgavlaw, null);
        ViewHolde holde = new ViewHolde(view);
        view.setOnClickListener(this);
        return holde;
    }

    @Override
    public void onBindViewHolder(ViewHolde viewHolde, int position, boolean b) {
        LgavLawVO vo = (LgavLawVO) mDatas.get(position);
        viewHolde.item_tv_lgavlaw_time.setText(vo.getFeedsTime());
        viewHolde.item_tv_lgavlaw__title.setText(vo.getWechatTitle());
        String imageUrl = vo.getTitlePic();
        if (!TextUtils.isEmpty(imageUrl)){
            viewHolde.iv_infom_lgavlaw_url.setVisibility(View.VISIBLE);
            ImageLoader.getInstance().displayImage(UrlUtil.getImageFileUrl(mContext,imageUrl), viewHolde.iv_infom_lgavlaw_url);
        }else {
            viewHolde.iv_infom_lgavlaw_url.setVisibility(View.GONE);
        }
        viewHolde.itemView.setTag(vo);
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas.size();
    }

    @Override
    public void onClick(View v) {
     if (lawOnClickListener!=null){
         lawOnClickListener.onItemClicklistener(v.getTag());
     }
    }

    public class ViewHolde extends RecyclerView.ViewHolder {
        public TextView item_tv_lgavlaw__title;
        public TextView item_tv_lgavlaw_time;
        public LinearLayout lgavlaw_title;
        public ImageView iv_infom_lgavlaw_url;
        public ViewHolde(View itemView) {
            super(itemView);
            this.item_tv_lgavlaw__title = (TextView) itemView.findViewById(R.id.item_tv_lgavlaw__title);
            this.item_tv_lgavlaw_time = (TextView) itemView.findViewById(R.id.item_tv_lgavlaw_time);
            this.lgavlaw_title = (LinearLayout) itemView.findViewById(R.id.lgavlaw_title);
            this.iv_infom_lgavlaw_url = (ImageView) itemView.findViewById(R.id.iv_infom_lgavlaw_url);
        }
    }

}
