package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.andview.refreshview.recyclerview.BaseRecyclerAdapter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.util.TimeSampUtil;
import com.lawyee.apppublic.vo.LgavConsultReplyAskVO;
import com.lawyee.apppublic.vo.LgavConsultReplyVO;
import com.lawyee.apppublic.vo.LgavConsultVO;

import net.lawyee.mobilelib.utils.StringUtil;

import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: 解答界面适配器
 * @author: YFL
 * @date: 2017/9/28 14:10
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MyLaywerAnswerAdapter extends BaseRecyclerAdapter {

    private Context mContext;
    private List<?> mDatas;
    private final LayoutInflater mInflater;
    private String mPersonAvatar;
    private String mPersonName;
    /**
     * 整个资讯vo
     */
    private LgavConsultVO mDetailVo;
    /***
     * 律师第一次回复
     */
    private static final String REPLYTYPEONE = "1";
    /***
     * 公众有追问
     */
    private static final String REPLYTYPETWO = "2";
    /**
     * 已经评价
     */
    private static final String EVALUATESTATUSONE = "1";
    /**
     * 公众选中匿名
     */
    public static final String ANONYMOUSFLAG = "true";


    /**
     * @param mContext
     * @param mDatas   评价数据
     *                 咨询人头像
     */
    public MyLaywerAnswerAdapter(Context mContext, List<?> mDatas, LgavConsultVO vo) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.mPersonAvatar = vo.getPersonPhoto();
        this.mPersonName = vo.getPersonName();
        this.mDetailVo = vo;
        mInflater = LayoutInflater.from(mContext);
    }

    public void setNewData(List<?> mDatas, LgavConsultVO vo) {
        this.mDatas = mDatas;
        this.mPersonAvatar = vo.getPersonPhoto();
        this.mPersonName = vo.getPersonName();
        notifyDataSetChanged();
    }

    public interface BtnSubmitListener {
        /**
         * 追问后继续解答按钮
         *
         * @param replyConte
         * @param oid
         */
        public void btnSubmitClickL(String replyConte, String oid);

        public void dismissDialog();
    }

    private BtnSubmitListener submitListener = null;

    public BtnSubmitListener getSubmitListener() {
        return submitListener;
    }

    public void setSubmitListener(BtnSubmitListener submitListener) {
        this.submitListener = submitListener;
    }

    @Override
    public RecyclerView.ViewHolder getViewHolder(View view) {
        return new LaywerListViewHolder(view);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i, boolean b) {
        View view = mInflater.inflate(R.layout.item_mypro_lawyer_answer_detail, null);
        return new LaywerListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position, boolean b) {
        //获取单条数据vo
        final LgavConsultReplyVO vo = (LgavConsultReplyVO) mDatas.get(position);
        //强转
        LaywerListViewHolder viewHolder = (LaywerListViewHolder) holder;
        //律师回答界面
        viewHolder.mTvItemMyproAnswercontent.setText(vo.getReplyContent());
        String timeStamp = TimeSampUtil.getStringTimeStamp(vo.getReplyTime());
        viewHolder.mTvItemMyproAnswertime.setText(timeStamp);
        viewHolder.mTvItemMyproAnswername.setText(vo.getUserName());
        //显示头像
        ShowOrHide.showPhotoPicture(mContext, vo.getUserPhoto(), viewHolder.mIvItemMyproAnswerphoto, mDetailVo.getAnonymousFlag());

        //评价界面
        //公众是否选中匿名

        //判断评价页面是否显示
        if (StringUtil.isEmpty(vo.getEvaluateContent())&&
                StringUtil.isEmpty(vo.getEvaluateLevel())) {
            viewHolder.mLinearEvaluate.setVisibility(View.GONE);
        } else {
            viewHolder.mLinearEvaluate.setVisibility(View.VISIBLE);
        }
        if (mDetailVo.getAnonymousFlag().equals(ANONYMOUSFLAG)) {
            viewHolder.mTvItemMyproEvaluatename.setText(R.string.anonymous);
        } else {
            viewHolder.mTvItemMyproEvaluatename.setText(mDetailVo.getPersonName());
        }
        String evaluatetime = TimeSampUtil.getStringTimeStamp(vo.getEvaluateTime());
        viewHolder.mTvItemMyproEvaluatetime.setText(evaluatetime);
        viewHolder.mTvItemMyproEvaluatecontent.setText(vo.getEvaluateContent());
        //设置评价等级
        setRtbEvaluate(vo.getEvaluateLevel(), viewHolder);
        ShowOrHide.showPhotoPicture(mContext, mDetailVo.getPersonPhoto(), viewHolder.mIvItemMyproEvaluatePhoto, mDetailVo.getAnonymousFlag());
        List<LgavConsultReplyAskVO> asks = vo.getAsks();

        setReplyAskAdapterData(asks, viewHolder, vo, mDetailVo);


    }

    /**
     * 设置公众追问界面
     *
     * @param asks
     * @param viewHolder
     * @param vo
     * @param mDetailVo
     */
    private void setReplyAskAdapterData(List<LgavConsultReplyAskVO> asks, LaywerListViewHolder viewHolder, final LgavConsultReplyVO vo, LgavConsultVO mDetailVo) {
        PeopleAnswerReplyAdpater replyAdpater = new PeopleAnswerReplyAdpater(mContext, asks, mDetailVo, vo);
        GridLayoutManager manager = new GridLayoutManager(mContext, 1);
        manager.setOrientation(GridLayoutManager.VERTICAL);
        viewHolder.mRlvItemReplyask.setLayoutManager(manager);
        viewHolder.mRlvItemReplyask.setAdapter(replyAdpater);
        //继续解答按钮
        replyAdpater.setReplyAskClikcListener(new PeopleAnswerReplyAdpater.ReplyAskClikcListener() {
            @Override
            public void ReplyAskClickListener(View view) {
                ShowOrHide.ShowInputBoxDialog(mContext, new ShowOrHide.GetInputOutString() {
                    @Override
                    public void inputOutString(String content) {
                        if (submitListener != null) {
                            submitListener.btnSubmitClickL(content, vo.getOid());
                        }
                    }

                    @Override
                    public void dismissDialog() {
                        submitListener.dismissDialog();
                    }
                });

            }
        });


    }

    /**
     * 设置评价级别
     *
     * @param evaluateLevel
     * @param viewHolder
     */
    private void setRtbEvaluate(String evaluateLevel, LaywerListViewHolder viewHolder) {
        if (StringUtil.isEmpty(evaluateLevel))
            return;
        switch (evaluateLevel) {
            case "0":
                setIvBg(false, false, false, false, false, viewHolder);
                break;
            case "1":
                setIvBg(true, false, false, false, false, viewHolder);
                break;
            case "2":
                setIvBg(true, true, false, false, false, viewHolder);
                break;
            case "3":
                setIvBg(true, true, true, false, false, viewHolder);
                break;
            case "4":
                setIvBg(true, true, true, true, false, viewHolder);
                break;
            case "5":
                setIvBg(true, true, true, true, true, viewHolder);
                break;
            default:
                break;
        }

    }


    private void setIvBg(boolean isOneSelect, boolean isTwoSelect,
                         boolean isThreeSelect, boolean isFourSelect,
                         boolean isFiveSelect, LaywerListViewHolder viewHolder) {
        viewHolder.mIvRatubgbarOne.setImageResource(isOneSelect ? R.drawable.icon_ratubgbar_press : R.drawable.icon_ratingbar_unpress);
        viewHolder.mIvRatubgbarTwo.setImageResource(isTwoSelect ? R.drawable.icon_ratubgbar_press : R.drawable.icon_ratingbar_unpress);
        viewHolder.mIvRatubgbarThree.setImageResource(isThreeSelect ? R.drawable.icon_ratubgbar_press : R.drawable.icon_ratingbar_unpress);
        viewHolder.mIvRatubgbarFour.setImageResource(isFourSelect ? R.drawable.icon_ratubgbar_press : R.drawable.icon_ratingbar_unpress);
        viewHolder.mIvRatubgbarFive.setImageResource(isFiveSelect ? R.drawable.icon_ratubgbar_press : R.drawable.icon_ratingbar_unpress);
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas.size();
    }



    public static class LaywerListViewHolder extends RecyclerView.ViewHolder {
        public ImageView mIvItemMyproAnswerphoto;
        public TextView mTvItemMyproAnswername;
        public TextView mTvItemMyproAnswertime;
        public TextView mTvItemMyproAnswercontent;
        public LinearLayout mLinearAnswerview;
        public LinearLayout mLinearLawyerAnswerView;
        public ImageView mIvItemMyproEvaluatePhoto;
        public TextView mTvItemMyproEvaluatename;
        public TextView mTvItemMyproEvaluatetime;
        public ImageView mIvRatubgbarOne;
        public ImageView mIvRatubgbarTwo;
        public ImageView mIvRatubgbarThree;
        public ImageView mIvRatubgbarFour;
        public ImageView mIvRatubgbarFive;
        public LinearLayout mLineRatubgbar;
        public TextView mTvItemMyproEvaluatecontent;
        public LinearLayout mLinearEvaluate;
        public RecyclerView mRlvItemReplyask;

        public LaywerListViewHolder(View rootView) {
            super(rootView);
            this.mIvItemMyproAnswerphoto = (ImageView) rootView.findViewById(R.id.iv_item_mypro_answerphoto);
            this.mTvItemMyproAnswername = (TextView) rootView.findViewById(R.id.tv_item_mypro_answername);
            this.mTvItemMyproAnswertime = (TextView) rootView.findViewById(R.id.tv_item_mypro_answertime);
            this.mTvItemMyproAnswercontent = (TextView) rootView.findViewById(R.id.tv_item_mypro_answercontent);
            this.mLinearAnswerview = (LinearLayout) rootView.findViewById(R.id.linear_answerview);
            this.mLinearLawyerAnswerView = (LinearLayout) rootView.findViewById(R.id.linear_lawyer_answerView);
            this.mIvItemMyproEvaluatePhoto = (ImageView) rootView.findViewById(R.id.iv_item_mypro_evaluatePhoto);
            this.mTvItemMyproEvaluatename = (TextView) rootView.findViewById(R.id.tv_item_mypro_evaluatename);
            this.mTvItemMyproEvaluatetime = (TextView) rootView.findViewById(R.id.tv_item_mypro_evaluatetime);
            this.mIvRatubgbarOne = (ImageView) rootView.findViewById(R.id.iv_ratubgbar_one);
            this.mIvRatubgbarTwo = (ImageView) rootView.findViewById(R.id.iv_ratubgbar_two);
            this.mIvRatubgbarThree = (ImageView) rootView.findViewById(R.id.iv_ratubgbar_three);
            this.mIvRatubgbarFour = (ImageView) rootView.findViewById(R.id.iv_ratubgbar_four);
            this.mIvRatubgbarFive = (ImageView) rootView.findViewById(R.id.iv_ratubgbar_five);
            this.mLineRatubgbar = (LinearLayout) rootView.findViewById(R.id.line_ratubgbar);
            this.mTvItemMyproEvaluatecontent = (TextView) rootView.findViewById(R.id.tv_item_mypro_evaluatecontent);
            this.mLinearEvaluate = (LinearLayout) rootView.findViewById(R.id.linear_evaluate);
            this.mRlvItemReplyask = (RecyclerView) rootView.findViewById(R.id.rlv_item_replyask);
        }

    }
}
