package com.lawyee.apppublic.dal;

import android.content.Context;

import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.vo.UserVO;

import net.lawyee.mobilelib.json.JsonCreater;
import net.lawyee.mobilelib.utils.SecurityUtil;
import net.lawyee.mobilelib.utils.StringUtil;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.dal
 * @Description: 我的活动
 * @author: YFL
 * @date: 2017/10/12 14:06
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavActivityService extends BaseJsonService {
    /**
     * @param c
     */
    public LgavActivityService(Context c) {
        super(c);
    }

    /**
     *  查询我的活动接口
     * @param pageNo 页
     * @param listener
     */
    public void queryLgavActivityList(int pageNo,  IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin())
        {
            listener.onError("请先进行用户登录","");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId",  SecurityUtil.Encrypt(userVO.getSessionId(),SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));
        creater.setParam("pageSize",Constants.CINT_PAGE_SIZE);

        creater.setParam("pageNo", pageNo < 1 ? 1 : pageNo);
        mCommandName = "mmUserGetLgavActivityList";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_LIST);
        getData(json, null);
    }

    /**
     * 查询活动详情接口
     * @param pageNo 页
     * @param activityID 活动id
     * @param listener
     */
    public void queryLgavActiviyDetail(int pageNo, String activityID , IResultInfoListener listener){
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if(!ApplicationSet.getInstance().IsLogin())
        {
            listener.onError("请先进行用户登录","");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId",  SecurityUtil.Encrypt(userVO.getSessionId(),SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        creater.setParam("pageNo", pageNo < 1 ? 1 : pageNo);
        creater.setParam("pageSize",Constants.CINT_PAGE_SIZE);
        if (!StringUtil.isEmpty(activityID))
            creater.setParam("activityID",activityID);
        mCommandName = "mmUserGetLgavActivityDetail";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);

    }
}
