package com.lawyee.apppublic.ui.frag;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;

import com.andview.refreshview.XRefreshView;
import com.andview.refreshview.XRefreshViewFooter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.LgavLawAdapter;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LegalService;
import com.lawyee.apppublic.ui.org.japub.ImageLookActivity;
import com.lawyee.apppublic.vo.LgavLawVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawCaseFragment.java
 * @Package com.lawyee.apppublic.ui.frag
 * @Description: 以案释法
 * @author: YFL
 * @date: 2017/12/27 15:19
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/12/27 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LawCaseFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private RecyclerView mRlvInformItem;
    private XRefreshView mXrefreshview;
    /**
     * 保存数据
     */
    public static final String LGAVCASESAVE="lgavcasesave";
    /**
     * 数据是否处理中，用于服务端请求数据时标识，防止重复申请
     */
    private Boolean mInProgess= false;
    /**
     * 数据列表
     */
    @SuppressWarnings("rawtypes")
    protected ArrayList mDataList;
    private Context mContext;
    private LgavLawAdapter mLgavLawAdapter;

    public static LawCaseFragment newInstance(String param1, String param2) {
        LawCaseFragment fragment = new LawCaseFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_law_case, container, false);
        initView(view);
        loadData();
        return view;
    }

    private void initView(View view) {
        mContext = getActivity();
        mRlvInformItem = (RecyclerView) view.findViewById(R.id.information_law_case_rlv);
        mXrefreshview = (XRefreshView) view.findViewById(R.id.information_lawcase_xrv);
        // 设置是否可以下拉刷新
        mXrefreshview.setPullRefreshEnable(true);
        // 设置是否可以上拉加载
        mXrefreshview.setPullLoadEnable(false);
        mXrefreshview.restoreLastRefreshTime(0l);
        mXrefreshview.setEmptyView(view.findViewById(R.id.information_empty_lawcase_tv));
        mXrefreshview.setXRefreshViewListener(new XRefreshView.SimpleXRefreshListener() {
            @Override
            public void onRefresh(boolean isPullDown) {
                loadNewData();
            }

            @Override
            public void onLoadMore(boolean isSilence) {
                loadMoreData();
            }

            @Override
            public void onRelease(float direction) {
                super.onRelease(direction);
            }
        });
    }

    /**
     * 加载更多
     */
    private void loadMoreData() {

        if(mInProgess)
            return;
        mInProgess=true;
        LegalService service = new LegalService(getActivity());
        service.queryUserGetLgavLawList( getNowPage()+1, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                if(values==null||values.isEmpty()) {
                    mXrefreshview.setLoadComplete(true);
                    return;
                }

                ArrayList list = (ArrayList) values
                        .get(0);
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                }else
                {
                    mXrefreshview.setLoadComplete(true);
                    mLgavLawAdapter.notifyDataSetChanged();
                    return;
                }
                LgavLawVO.saveVOList(mDataList,LGAVCASESAVE);
                if(!mDataList.isEmpty()&&mDataList.size()%Constants.CINT_PAGE_SIZE==0){
                    // 设置是否可以上拉加载
                    mXrefreshview.setPullLoadEnable(true);
                    mXrefreshview.setLoadComplete(false);
                }
                else
                    mXrefreshview.setLoadComplete(true);
                mLgavLawAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshview.stopLoadMore();
                T.showLong(getActivity(),msg);
            }
        });
    }

    /**
     * 刷新数据
     */
    private void loadNewData() {
        if(mInProgess)
            return;
        mInProgess=true;
        LegalService service = new LegalService(getActivity());
        service.queryUserGetLgavLawList( 1, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshview.stopRefresh();
                if(values==null||values.isEmpty()) {
                    T.showShort(getActivity(),content);
                    return;
                }

                ArrayList list = (ArrayList) values
                        .get(0);
                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                }else {
                    mLgavLawAdapter.notifyDataSetChanged();
                    mXrefreshview.setLoadComplete(true);
                    return;
                }
                //缓存数据
                LgavLawVO.saveVOList(mDataList,LGAVCASESAVE);
                if(!mDataList.isEmpty()&&mDataList.size()%Constants.CINT_PAGE_SIZE==0) {
                    // 设置是否可以上拉加载
                    mXrefreshview.setPullLoadEnable(true);
                    mXrefreshview.setLoadComplete(false);
                }
                else
                    mXrefreshview.setLoadComplete(true);
                mLgavLawAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshview.stopRefresh();
                T.showLong(getActivity(),msg);
            }
        });
    }

    /**
     * 读取数据
     */
    private void loadData()
    {
        clearDataList();
        //读取缓存
        List  list = LgavLawVO.loadVOList(LGAVCASESAVE);
        if(list!=null&&!list.isEmpty())
        {
            addDataList(list);
        }
        setAdapetData();
        Boolean mustRefresh = true;
        //判断是否在有效期内
        if(mDataList!=null&&!mDataList.isEmpty())
        {
            LgavLawVO vo;
            Object o = mDataList.get(0);
            if(o instanceof  LgavLawVO)
            {
                vo = (LgavLawVO)o;
                mXrefreshview.restoreLastRefreshTime(vo.getVoCreateDate().getTime());
                if(vo.isEffectiveTimeData(Constants.CINT_EFFECTIVE_NEWS_TIME))
                    mustRefresh =false;
            }
            if(mDataList.size()%Constants.CINT_PAGE_SIZE==0)
                // 设置是否可以上拉加载
                mXrefreshview.setPullLoadEnable(true);
        }
        if(mustRefresh) {
            mXrefreshview.startRefresh();
        }
    }

    private void setAdapetData() {
        mLgavLawAdapter = new LgavLawAdapter(mContext,mDataList);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext,1);
        gridLayoutManager.setOrientation(GridLayout.VERTICAL);
        mRlvInformItem.setLayoutManager(gridLayoutManager);
        mLgavLawAdapter.setCustomLoadMoreView(new XRefreshViewFooter(getActivity()));
        mRlvInformItem.addItemDecoration(new DividerItemDecoration(getActivity(),
                DividerItemDecoration.VERTICAL));
        mRlvInformItem.setAdapter(mLgavLawAdapter);
        mLgavLawAdapter.setLawOnClickListener(new LgavLawAdapter.LgavLawOnClickListener() {
            @Override
            public void onItemClicklistener(Object item) {
                if (item==null||!(item instanceof LgavLawVO)){
                    return;
                }
                LgavLawVO vo= (LgavLawVO) item;
                Intent intent = new Intent(mContext, ImageLookActivity.class);
                intent.putExtra(ImageLookActivity.CONTENT_PARRMTER_TYPE,ImageLookActivity.CONTENT_PARRMTER_WEB);
                intent.putExtra(ImageLookActivity.CSTR_EXTRA_TITLE_STR,"以案释法");
                intent.putExtra(ImageLookActivity.CONTNETPARAMETER_URL, vo.getWechatUrl());
                 startActivity(intent);
            }
        });
    }

    /**
     * 清除数据
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private void clearDataList() {
        if (mDataList == null) {
            mDataList = new ArrayList();
        } else
            mDataList.clear();
    }

    /**
     * 增加列表数据
     *
     * @param list
     */
    @SuppressWarnings({ "unchecked" })
    private void addDataList(List<?> list) {
        if (mDataList == null)
            clearDataList();
        if (list == null || list.isEmpty())
            return;
        mDataList.addAll(list);
    }
    /**
     * 当前数据有几页
     * @return
     */
    private int getNowPage()
    {
        if(mDataList==null||mDataList.isEmpty())
            return 0;
        if(mDataList.size()%Constants.CINT_PAGE_SIZE==0)
            return mDataList.size()/Constants.CINT_PAGE_SIZE;
        else
            return mDataList.size()/Constants.CINT_PAGE_SIZE+1;
    }
}
