package com.lawyee.apppublic.ui.frag.myanswer;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.andview.refreshview.XRefreshView;
import com.andview.refreshview.XRefreshViewFooter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.MyProblemAdapter;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavProblemService;
import com.lawyee.apppublic.ui.frag.fragService.BaseFragment;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemDetailActivity;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.vo.LgavConsultDetailVO;
import com.lawyee.apppublic.vo.LgavConsultVO;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity.ANSWERFLAG;
import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity.CANCELACTION;
import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity.KNOCKACTION;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: UnansweredFragment.java
 * @Package com.lawyee.apppublic.ui.frag.myproblem
 * @Description: 已解答页
 * @author: YFL
 * @date: 2017/9/25 15:25
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/9/25 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class UnansweredFragment extends BaseFragment {
    /**
     * 请求角色
     */
    private static final String DATASCORE = "datascore";
    /**
     * 数据范围
     */
    private static final String OBJECTTYPE = "objecttype";
    private ArrayList mDataList;
    private String mDataScore;
    private String mObjectType;
    private RecyclerView mRlvMyproView;
    private Context mContext;
    private XRefreshView mXrefreshView;
    /**
     * 数据是否处理中，用于服务端请求数据时标识，防止重复申请
     */
    boolean mInProgess;

    /**
     * 是否已提交
     */
    private boolean mIsSubmit = false;
    /**
     * 该咨询已结束
     */
    private static final String INFOMSTATUSOVER = "1";
    /**
     * 判断是否刷新
     */
    private boolean mIsResume = false;
    private MyProblemAdapter mProblemAdapter;
    /**
     * 是否抢答
     */
    private boolean mIsKnock = false;

    /**
     * @param datascore    问题类型
     * @param objectType 业务类型
     * @return
     */
    public static UnansweredFragment newInstance(String datascore, String objectType) {
        UnansweredFragment fragment = new UnansweredFragment();
        Bundle args = new Bundle();
        args.putString(DATASCORE, datascore);
        args.putString(OBJECTTYPE, objectType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mDataScore = getArguments().getString(DATASCORE);
            mObjectType = getArguments().getString(OBJECTTYPE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_unanswered, container, false);
        initView(view);
        initRefresh(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();


    }

    private void initData() {
        clearDataList();
        //判断数据是为空，空->请求网络
        //绑定数据 - 初始化适配器
        setAdapterData();
        requestService(true, 1);

    }

    /**
     * 请求网络
     *
     * @param isFirst 显示加载框
     * @param pageNo
     */
    private void requestService(boolean isFirst, int pageNo) {
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.setShowProgress(isFirst);
        problemService.queryLgavGetConsultList(pageNo, mDataScore, mObjectType, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    mProblemAdapter.notifyDataSetChanged();
                    return;
                }
                //缓存数据
//                JamedOrgVO.saveVOList(mDataList, JamedOrgVO.dataListFileName(getApplicationContext(), SAVELISTDATAS));
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else
                    mXrefreshView.setLoadComplete(true);
                mProblemAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                T.showShort(mContext, msg);
            }
        });

    }

    private void setAdapterData() {
        // 转值班律师
        String objecttypethree = "-1";
        mProblemAdapter = new MyProblemAdapter(mContext, mDataList,mDataScore);
        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 1);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        mRlvMyproView.setLayoutManager(layoutManager);
        mProblemAdapter.setCustomLoadMoreView(new XRefreshViewFooter(mContext));
         if (mObjectType.equals(objecttypethree)){
            mProblemAdapter.setLawMark(objecttypethree);
        }
        mRlvMyproView.setAdapter(mProblemAdapter);
        //按钮监听
        mProblemAdapter.setButtonOnlickListener(new MyProblemAdapter.OnRecyclerButtonOnlickListener() {
            @Override
            public void OnButtonClickListener(View view, Object o,String name,int position) {
                showInputBoxDialog(o);
            }
        });
        mProblemAdapter.setCancelListener(new MyProblemAdapter.onBtnCancelListener() {
            @Override
            public void OnCancelListener(View view, String id, String actiontype,int positon) {
                if (actiontype.equals(KNOCKACTION)) {//抢答的
                    submitKnockService(id, KNOCKACTION,true,positon);
                    return;
                }
                if (actiontype.equals(CANCELACTION)) {//取消解答
                    submitKnockService(id, CANCELACTION,false,positon);
                    return;
                }
            }
        });

        // item监听
        mProblemAdapter.setSetOnRecyclerViewItemOnlickListener(new MyProblemAdapter.setOnRecyclerViewItemOnlickListener() {
            @Override
            public void setOnRecyclerView(View view, Object o) {
                if (o == null)
                    return;
                LgavConsultVO vo = (LgavConsultVO) o;
                MyProblemDetailActivity.newInstance(mContext, vo.getOid(),mDataScore,mObjectType);
            }
        });

    }

    /***
     * 提交抢答
     * @param id id
     * @param actiontype 类型
     */
    private void submitKnockService(final String id, String actiontype, final boolean isKnock, final int positon) {
        if (mIsKnock) {
            return;
        }
        mIsKnock = true;
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.setShowProgress(true);
        problemService.setProgressShowContent(isKnock?"抢答中...":"取消解答...");
        problemService.submitLgavAcitonAnswer(id,actiontype, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null) {
                    T.showShort(mContext, "抢答失败");
                    return;
                }
                T.showShort(mContext, isKnock?"抢答成功":"取消解答成功");

                mIsKnock = false;

                querProblemInfom(id,positon,isKnock);

//                if (mXrefreshView != null)
//                    mXrefreshView.startRefresh();
            }

            @Override
            public void onError(String msg, String content) {
                mIsKnock = false;
                T.showShort(mContext, msg);
            }
        });

    }

    private void querProblemInfom(String id, final int positon, final boolean isKnock) {
        queryMyProblemInfom(id, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, R.string.prompt_network_receiving_data_error);
                    return;
                }
                LgavConsultDetailVO detailVO = (LgavConsultDetailVO) values.get(0);
                if (mProblemAdapter==null)
                    return;

               mProblemAdapter.replaceNewItemData(positon, detailVO.getAnswerFlag(), detailVO.getConsultStatus());

            }

            @Override
            public void onError(String msg, String content) {

            }
        });
    }

    /***
     *  提示框
     * @param o
     */
    private void showInputBoxDialog(final Object o) {
        // 显示解答框
        ShowOrHide.ShowInputBoxDialog(mContext, new ShowOrHide.GetInputOutString() {
            @Override
            public void inputOutString(String content) {
                LgavConsultVO vo = (LgavConsultVO) o;
                //结束是不显示提示框
                if (vo.getConsultStatus().equals(INFOMSTATUSOVER)) {
                    MyProblemDetailActivity.newInstance(mContext, vo.getOid(),mDataScore,mObjectType);
                } else {
                    if (vo.getAnswerFlag().equals(ANSWERFLAG)) {
                        showSubmitInputBoxDialog(content, vo.getOid(),true);
                    }else {
                        showSubmitInputBoxDialog(content, vo.getOid(),false);
                    }

                }
            }

            @Override
            public void dismissDialog() {
                mIsSubmit = false;
            }
        });
    }

    /***
     *
     * @param content 回复内容
     * @param oid 咨询id
     */
    private void showSubmitInputBoxDialog(String content, String oid,final boolean isAnswer) {
        if (mIsSubmit) {
            return;
        }
        mIsSubmit = true;
        if (StringUtil.isEmpty(content)) {
            T.showShort(mContext, mContext.getString(R.string.please_answer_enmpty));
            mIsSubmit = false;
            return;
        }
        submitService(content, isAnswer, oid, new ResultIResultInfoListener() {
            @Override
            public void resultIResultInfoListener(ArrayList<Object> values, String content) {
                mIsSubmit = false;
                if (mXrefreshView != null)
                    mXrefreshView.startRefresh();
            }

            @Override
            public void resultIErrorResultInfoListener() {
                mIsSubmit = false;
            }
        });
    }

    private void initView(View view) {
        mContext = getContext();
        mRlvMyproView = (RecyclerView) view.findViewById(R.id.rlv_mypro_unasw_view);
        mXrefreshView = (XRefreshView) view.findViewById(R.id.xrv_mypro_unasw);
    }

    /**
     * 刷新控件设置
     */
    private void initRefresh(View view) {
        //设置是否能上拉刷新
        mXrefreshView.setPullLoadEnable(false);
        //设置是否下拉刷新
        mXrefreshView.setPullRefreshEnable(true);
        mXrefreshView.restoreLastRefreshTime(0l);
        mXrefreshView.setEmptyView(view.findViewById(R.id.xrv_mypro_empty_unasw));
        mXrefreshView.setXRefreshViewListener(new XRefreshView.SimpleXRefreshListener() {
            @Override
            public void onRefresh(boolean isPullDown) {
                LoadNewData();
            }


            @Override
            public void onLoadMore(boolean isSilence) {
                loadMoreDatas();
            }
        });
    }

    //加载更多
    private void loadMoreDatas() {
        if (mInProgess) {
            return;
        }
        mInProgess = true;
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.queryLgavGetConsultList(getNowPage() + 1,  mDataScore,mObjectType, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                if (values == null || values.isEmpty()) {
                    mXrefreshView.setLoadComplete(true);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    mProblemAdapter.notifyDataSetChanged();
                    return;
                }
                //缓存数据
//                JamedOrgVO.saveVOList(mDataList, JamedOrgVO.dataListFileName(getApplicationContext(), SAVELISTDATAS));
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else {
                    mXrefreshView.setLoadComplete(true);
                }
                mProblemAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopLoadMore();
                T.showShort(mContext, msg);
            }
        });

    }

    //加载新数据
    private void LoadNewData() {
        if (mInProgess)
            return;
        mInProgess = true;
        requestService(false, 1);
    }

    /**
     * 当前数据有几页
     *
     * @return
     */
    private int getNowPage() {
        if (mDataList == null || mDataList.isEmpty())
            return 0;
        if (mDataList.size() % Constants.CINT_PAGE_SIZE == 0)
            return mDataList.size() / Constants.CINT_PAGE_SIZE;
        else
            return mDataList.size() / Constants.CINT_PAGE_SIZE + 1;
    }

    /**
     * 清除数据
     */
    private void clearDataList() {
        if (mDataList == null) {
            mDataList = new ArrayList();
        } else {
            mDataList.clear();
        }
    }

    /**
     * 增加列表数据
     */
    private void addDataList(List<?> list) {
        if (mDataList == null) {
            clearDataList();
        }
        if (list == null || list.isEmpty()) {
            return;
        }
        mDataList.addAll(list);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!mIsResume) {
            return;
        }
        if (mXrefreshView != null)
            mXrefreshView.startRefresh();
    }

    @Override
    public void onResume() {
        super.onResume();
        mIsResume = false;
    }

    @Override
    public void onStop() {
        super.onStop();
        mIsResume = true;
    }

}
