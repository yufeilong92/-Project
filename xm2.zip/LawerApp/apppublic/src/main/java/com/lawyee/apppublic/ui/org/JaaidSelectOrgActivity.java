package com.lawyee.apppublic.ui.org;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;

import com.andview.refreshview.XRefreshView;
import com.andview.refreshview.XRefreshViewFooter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.JaaidOrgRlvAdapter;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JaaidService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.ui.frag.JaaidApplyOtherInformationFragment;
import com.lawyee.apppublic.vo.JaaidOrgVO;
import com.lawyee.apppublic.widget.RecycleViewDivider;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.ui.personalcenter
 * @Description: 申请页选择法援机构
 * @author: YFL
 * @date: 2017/6/10 9:34
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class JaaidSelectOrgActivity extends BaseActivity {
    /**
     * 市级机构id
     */
    public static final String SELECTORGOID = "selectorgoid";
    private RecyclerView mRlvSelectOrg;
    private String mOrgId;
    private ArrayList adapterData;
    private TextView mSelectContentEmptyTv;
    private JaaidOrgRlvAdapter adapter;
    private XRefreshView mXrefreshView;
    /**
     * 数据是否处理中，用于服务端请求数据时标识，防止重复申请
     */
    boolean mInProgess;


    private Context mContext;
    private ArrayList mDataList;
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_jaaid_selectorg);
        initView();
        Intent intent = getIntent();
        mOrgId = intent.getStringExtra(SELECTORGOID);
        handlerRequestOrg();
    }

    private void handlerRequestOrg() {
        clearDataList();
        //判断数据是为空，空->请求网络
        //绑定数据 - 初始化适配器
        setAdapterData();
        JaaidService jaaidService = new JaaidService(this);
        jaaidService.setShowProgress(true);
        jaaidService.setProgressShowContent(getString(R.string.loading));
        jaaidService.queryOrgList(1, Constants.PROVINCE_GUIZHOU_ID, mOrgId, null, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    adapter.notifyDataSetChanged();
                    return;
                }
                //缓存数据
//                JamedOrgVO.saveVOList(mDataList, JamedOrgVO.dataListFileName(getApplicationContext(), SAVELISTDATAS));
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else
                    mXrefreshView.setLoadComplete(true);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                T.showShort(mContext, msg);
            }
        });
    }

    private void initView() {
        mContext = this;
        mRlvSelectOrg = (RecyclerView) findViewById(R.id.rlv_select_org);
        mSelectContentEmptyTv = (TextView) findViewById(R.id.select_content_empty_tv);
        mXrefreshView =(XRefreshView)findViewById(R.id.xrv_myselectpro_unasw);
        mXrefreshView.setPullLoadEnable(false);
        //设置是否下拉刷新
        mXrefreshView.setPullRefreshEnable(true);
        mXrefreshView.restoreLastRefreshTime(0l);
        mXrefreshView.setEmptyView(findViewById(R.id.xrv_mypro_empty_unasw));
        mXrefreshView.setXRefreshViewListener(new XRefreshView.SimpleXRefreshListener() {
            @Override
            public void onRefresh(boolean isPullDown) {
                LoadNewData();
            }


            @Override
            public void onLoadMore(boolean isSilence) {
                loadMoreDatas();
            }
        });
    }

    private void loadMoreDatas() {
        if (mInProgess) {
            return;
        }
        mInProgess = true;
        JaaidService jaaidService = new JaaidService(this);
       // jaaidService.setShowProgress(true);
        //jaaidService.setProgressShowContent(getString(R.string.loading));
        jaaidService.queryOrgList(getNowPage() + 1, Constants.PROVINCE_GUIZHOU_ID, mOrgId, null, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                if (values == null || values.isEmpty()) {
                    mXrefreshView.setLoadComplete(true);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    adapter.notifyDataSetChanged();
                    return;
                }
                //缓存数据
//                JamedOrgVO.saveVOList(mDataList, JamedOrgVO.dataListFileName(getApplicationContext(), SAVELISTDATAS));
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else {
                    mXrefreshView.setLoadComplete(true);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopLoadMore();
                T.showShort(mContext, msg);
            }
        });
    }

    private void LoadNewData() {
        JaaidService jaaidService = new JaaidService(this);
        jaaidService.queryOrgList(1, Constants.PROVINCE_GUIZHOU_ID, mOrgId, null, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                ArrayList list = (ArrayList) values.get(0);
                clearDataList();
                if (list != null && !list.isEmpty()) {
                    addDataList(list);
                } else {
                    mXrefreshView.setLoadComplete(true);
                    adapter.notifyDataSetChanged();
                    return;
                }
                //缓存数据
//                JamedOrgVO.saveVOList(mDataList, JamedOrgVO.dataListFileName(getApplicationContext(), SAVELISTDATAS));
                if (!mDataList.isEmpty() && mDataList.size() % Constants.CINT_PAGE_SIZE == 0) {
                    //设置是否可以上拉加载
                    mXrefreshView.setPullLoadEnable(true);
                    mXrefreshView.setLoadComplete(false);
                } else
                    mXrefreshView.setLoadComplete(true);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                mInProgess = false;
                mXrefreshView.stopRefresh();
                T.showShort(mContext, msg);
            }
        });
    }
    /**
     * 增加列表数据
     */
    private void addDataList(List<?> list) {
        if (mDataList == null) {
            clearDataList();
        }
        if (list == null || list.isEmpty()) {
            return;
        }
        mDataList.addAll(list);
    }
    /**
     * 清除数据
     */
    private void clearDataList() {
        if (mDataList == null) {
            mDataList = new ArrayList();
        } else {
            mDataList.clear();
        }
    }
    public void setAdapterData() {
        adapter = new JaaidOrgRlvAdapter(mDataList, this);
        GridLayoutManager manager = new GridLayoutManager(this, 1);
        manager.setOrientation(GridLayout.VERTICAL);
        mRlvSelectOrg.setLayoutManager(manager);
        mRlvSelectOrg.addItemDecoration(new RecycleViewDivider(this, GridLayoutManager.VERTICAL, R.drawable.bg_rlv_diving));
        adapter.setCustomLoadMoreView(new XRefreshViewFooter(mContext));
        mRlvSelectOrg.setAdapter(adapter);
        adapter.setItemClickListener(new JaaidOrgRlvAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void ItemClickListenet(View view, JaaidOrgVO vo, int position) {
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString(JaaidApplyOtherInformationFragment.ORGNAME, vo.getName());
                bundle.putString(JaaidApplyOtherInformationFragment.ORGOID, vo.getOid());
                intent.putExtras(bundle);
                setResult(1000, intent);
                finish();
            }
        });
    }

    /**
     * 当前数据有几页
     *
     * @return
     */
    private int getNowPage() {
        if (mDataList == null || mDataList.isEmpty())
            return 0;
        if (mDataList.size() % Constants.CINT_PAGE_SIZE == 0)
            return mDataList.size() / Constants.CINT_PAGE_SIZE;
        else
            return mDataList.size() / Constants.CINT_PAGE_SIZE + 1;
    }


}
