package com.lawyee.apppublic.ui.personalcenter;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.FunctionAdpater;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.UserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.UserVO;
import com.lawyee.apppublic.widget.RecycleViewDivider;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  标题
 * @Package com.lawyee.apppublic.ui.personalcenter
 * @Description:    找回密码Adpater
 * @author:czq
 * @date:   2017/5/31
 * @version
 * @verdescript   2017/5/31  czq 初建
 * @Copyright: 2017/5/31 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class ForgetPwdActivity extends BaseActivity implements View.OnClickListener{


    private EditText mEtPhone;
    private EditText mEtAuthCode;
    private TextView mTvGetAuthCode;
    private EditText mEtPwd;
    private TextView mTvSure;
    private String mUserName;
    private Timer mTime;
    private long durationTime = 1000;
    private int countdown = 59;
    private  String mSecond;
    private String mRetry;
    private Context mContext;
    private TextView mTvChooseType;
    private MaterialDialog mPopWindowsShow;
    private String mRoleType="0";
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_forget_pwd);
        mContext=this;
        initView();
    }

    private void initView() {
        mEtPhone= (EditText) findViewById(R.id.et_phone);
        mEtAuthCode= (EditText) findViewById(R.id.et_auth_code);
        mTvGetAuthCode= (TextView) findViewById(R.id.tv_get_auth_code);
        mTvChooseType= (TextView) findViewById(R.id.tv_choose_type);
        mEtPwd= (EditText) findViewById(R.id.et_pwd);
        mTvSure= (TextView) findViewById(R.id.tv_sure);
        mTvGetAuthCode.setOnClickListener(this);
        mTvSure.setOnClickListener(this);
        mSecond=mContext.getString(R.string.second);
        mRetry=mContext.getString(R.string.retry);
        mTvChooseType.setOnClickListener(this);
        mTvChooseType.setText(R.string.public_people);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_get_auth_code:
                mUserName=mEtPhone.getText().toString().trim();
                if(mRoleType==null||mRoleType.equals("")){
                    T.showLong(mContext, getString(R.string.please_choose_role));
                    return;
                }
                getCode(mUserName);
                break;
            case R.id.tv_sure:
                String pwd=mEtPwd.getText().toString().trim();
                mUserName=mEtPhone.getText().toString().trim();
                String code=mEtAuthCode.getText().toString().trim();
                if(mRoleType==null||mRoleType.equals("")){
                    T.showLong(mContext, getString(R.string.please_choose_role));
                    return;
                }
                findPwd(mUserName,code,pwd);
                break;
            case R.id.tv_choose_type:
                List<String> mData=new ArrayList<>();
                mData.add("公众");
                mData.add("律师");
                mData.add("调解员");
                mData.add("媒体");
                mData.add("基层法律工作者");
                handlerPopWindos(mData);
                break;
        }
    }
    /**
     *
     * @param userName 手机号
     * @param code 验证码
     * @param pwd 密码
     *           请求找回密码
     */
    private void findPwd(String userName, String code, String pwd) {
        //判断有效性
        if(!StringUtil.validateMoblie(userName))
        {
            T.showLong(this,getString(R.string.please_input_phone_errorhint));
            mEtPhone.requestFocus();
            return;
        }
        if(StringUtil.isEmpty(code))
        {
            T.showLong(this,getString(R.string.please_input_vercode_errorhint));
            mEtAuthCode.requestFocus();
            return;
        }
        if(!UserVO.isEffPassword(pwd))
        {
            T.showLong(this,getString(R.string.please_input_pwd_errorhint));
            mEtPwd.requestFocus();
            return;
        }
        //
        if(getInProgess())
            return;
        setInProgess(true);
        UserService service = new UserService(mContext);
        service.setProgressShowContent(mContext.getString(R.string.find_pwd_ing));
        service.setShowProgress(true);
        service.changePwd(userName, pwd, code, mRoleType,new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                T.showShort(mContext,R.string.find_pwd_success);
                finish();
            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext,msg);
            }
        });
    }

    /***
     *
     * @param name  手机号
     *    获取验证码
     */
    private void getCode(String name){
        //判断有效性
        if(!StringUtil.validateMoblie(name))
        {
            T.showLong(this,getString(R.string.please_input_phone_errorhint));
            mEtPhone.requestFocus();
            return;
        }
        mTvGetAuthCode.setText(60+mSecond+mRetry);
        startTimer();
        if(getInProgess())
            return;
        setInProgess(true);
        UserService service = new UserService(mContext);
        service.getIdentifyingCode(name,UserService.CSTR_GETIDENTCODE_ACTION_FINDPWD,mRoleType, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);

            }

            @Override
            public void onError(String msg, String content) {
                setInProgess(false);
                T.showLong(mContext,msg);
                cancelTimer();
            }
        });
    }
    //验证码读秒
    private void startTimer() {
        cancelTimer();
        mTvGetAuthCode.setSelected(true);
        mTvGetAuthCode.setClickable(false);
        mTime = new Timer();
        mTime.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (countdown > 0) {
                            if(countdown<10){
                                mTvGetAuthCode.setText("0"+
                                        countdown +mSecond+mRetry);
                            }else {
                                mTvGetAuthCode.setText(
                                        countdown + mSecond + mRetry);
                            }
                            countdown--;
                        } else {
                            cancelTimer();
                        }

                    }
                });

            }
        }, durationTime, durationTime);

    }
    //取消定时器以及状态恢复
    private void cancelTimer() {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                countdown = 59;
                mTvGetAuthCode.setText(R.string.get_auth_code);
                mTvGetAuthCode.setClickable(true);
                mTvGetAuthCode.setSelected(false);
            }
        });
        if (mTime != null)
            mTime.cancel();
    }

    @Override
    protected void onDestroy() {
        cancelTimer();
        super.onDestroy();
    }
    /**
     * @param mData  数据
     */
    private void handlerPopWindos(final List<String> mData) {
        final FunctionAdpater applyPopAdapter = new FunctionAdpater(mData, this);
        final GridLayoutManager manager = new GridLayoutManager(this, 1);
        manager.setOrientation(LinearLayoutManager.VERTICAL);

        if (mPopWindowsShow == null || !mPopWindowsShow.isShowing()) {
            mPopWindowsShow = new MaterialDialog.Builder(this)
                    .adapter(applyPopAdapter, manager)
                    .backgroundColorRes(R.color.activity_content_bg)
                    .show();
            mPopWindowsShow.getRecyclerView().addItemDecoration(new RecycleViewDivider(this, GridLayoutManager.VERTICAL, R.drawable.bg_rlv_diving));
        }
        applyPopAdapter.setOnRecyclerItemClickListener(new FunctionAdpater.OnRecyclerItemClickListener() {
            @Override
            public void OnItemClickListener(View view, String itemVo, int position) {
                mTvChooseType.setText(itemVo);
                switch (position){
                    case 0:
                        mRoleType= UserVO.CSTR_USERROLE_PUBLIC;
                        break;
                    case 1:
                        mRoleType= UserVO.CSTR_USERROLE_JALAW;
                        break;
                    case 2:
                        mRoleType= UserVO.CSTR_USERROLE_JAMED;
                        break;
                    case 3:
                        mRoleType= UserVO.CSTR_USERROLE_MEDIAWORKER;
                        break;
                    case 4://// TODO: 2017/7/24  基层法律
                        mRoleType= UserVO.CSTR_USERROLE_BASICLAWWORKER;
                        break;
                }
                mPopWindowsShow.dismiss();
            }
        });
    }
}
