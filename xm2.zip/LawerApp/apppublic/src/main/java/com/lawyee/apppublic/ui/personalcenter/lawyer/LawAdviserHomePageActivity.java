package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.ui.BaseActivity;

public class LawAdviserHomePageActivity extends BaseActivity {


    private TextView mTvEdit;
    private ImageView mIvLawyerAvatar;
    private TextView mTvLawyerName;
    private TextView mTvLawyerFirm;
    private TextView mTvServicePhone;
    private TextView mTextView7;
    private TextView mTvWorkYear;
    private TextView mTvPracticeCertificateNumber;
    private TextView mTextView17;
    private TextView mTvArea2;
    private ImageView mIvBottom1;
    private TextView mTvLawyerIntro;
    private TextView mTvPackUp1;
    private LinearLayout mLlBottomDetail1;
    private TextView mTvLawyerIntro2;
    private TextView mTvEnter;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_law_adviser_home_page);
        initView();
    }

    private void initView() {
        mIvLawyerAvatar= (ImageView) findViewById(R.id.iv_lawyer_avatar);
        mTvLawyerName= (TextView) findViewById(R.id.tv_lawyer_name);
        mTvLawyerFirm= (TextView) findViewById(R.id.tv_lawyer_firm);
        mTvServicePhone= (TextView) findViewById(R.id.tv_service_phone);
        mTvWorkYear= (TextView) findViewById(R.id.tv_work_year);
        mTvPracticeCertificateNumber= (TextView) findViewById(R.id.tv_practice_certificate_number);
        mTvArea2= (TextView) findViewById(R.id.tv_area2);
        mTvEnter= (TextView) findViewById(R.id.tv_enter);
        mTvLawyerIntro2= (TextView) findViewById(R.id.tv_lawyer_intro2);
        mTvPackUp1  = (TextView) findViewById(R.id.tv_pack_up1);
        mLlBottomDetail1= (LinearLayout) findViewById(R.id.ll_bottom_detail1);
    }


}
