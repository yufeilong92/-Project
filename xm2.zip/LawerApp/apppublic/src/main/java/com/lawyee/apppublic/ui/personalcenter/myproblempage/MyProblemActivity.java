package com.lawyee.apppublic.ui.personalcenter.myproblempage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.View;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.InformationViewPageAdapter;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.ui.frag.myanswer.AllProblemFragment;
import com.lawyee.apppublic.ui.frag.myanswer.AnswerFragment;
import com.lawyee.apppublic.ui.frag.myanswer.NewProblemFragment;
import com.lawyee.apppublic.ui.frag.myanswer.UnansweredFragment;
import com.lawyee.apppublic.util.ObjectToList;
import com.lawyee.apppublic.widget.NoScrollViewPager;

import java.util.ArrayList;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: MyProblemActivity.java
 * @Package com.lawyee.apppublic.ui.personalcenter
 * @Description: 我的问题
 * @author: YFL
 * @date: 2017/9/25 16:54
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/9/25 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MyProblemActivity extends BaseActivity {

    private TabLayout mTabOrgMyproblem;
    private NoScrollViewPager mNoScrollViewPager;
    private List<String> mTabName;
    private Context mContext;
    private List<Fragment> mTabViewFragments;

    /**
     * 角色类型
     */
    public static final String LAWYERROLE = "casetype";
    /**
     *值班律师
     *
     */
    public static final String LAWYERROLE_LAW = "1";
    /**
     *村居顾问
     */
    public static final String LAWYERROLE_RODIE = "0";
    /**
     *黔微普法
     */
    public static final String LAWYERROLE_LGAV = "2";
    /**
     * 取消解答
     */
    public static final String CANCELACTION="1";
    /**
     * 抢答
     */
    public static final String KNOCKACTION= "0";

    /**
     * 已经解答过了
     */
    public static final String ANSWERFLAG = "2";

    private String mRoleType;

    /**
     *
     *：待解答
     */
    private   final String DATASCOREONE ="1";
    /**
     *
     *已解答
     */
    private   final String  DATASCORETWO="2";

    /**
     *
     *已结贴
     */
    private   final String  DATASCORETHREE="3";

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_my_problem);
        initView();
        selectShowProblem();


    }

    private void selectShowProblem() {
        if (mTabName == null) {
            mTabName = new ArrayList<>();
        }
        mTabName.clear();
        if (mRoleType.equals(LAWYERROLE_LAW)){//律师团队
            mTabName = ObjectToList.ArrayToList(mContext, R.array.my_problem_tab);
            initTablyoutLaw();
        }else if (mRoleType.equals(LAWYERROLE_RODIE)){//村居顾问
            mTabName = ObjectToList.ArrayToList(mContext, R.array.my_problem_tab);
            initTablyout();
        }else if (mRoleType.equals(LAWYERROLE_LGAV)){//黔微普法
            mTabName = ObjectToList.ArrayToList(mContext, R.array.my_problem_tab_lgav);
            initTablyoutLgav();
        }
    }

    private void initTablyoutLaw() {
        // 转值班律师
        String OBJECTTYPETHREE = "-1";
        //未解答
        UnansweredFragment unansweredFragment = UnansweredFragment.newInstance(DATASCOREONE, OBJECTTYPETHREE);
        //已解答
        AnswerFragment answerFragment = AnswerFragment.newInstance(DATASCORETWO, OBJECTTYPETHREE);
        //全部问题
        AllProblemFragment allProblemFragment = AllProblemFragment.newInstance(DATASCORETHREE, OBJECTTYPETHREE);
        if (mTabViewFragments == null) {
            mTabViewFragments = new ArrayList<>();
        }
        mTabViewFragments.clear();
        mTabViewFragments.add(unansweredFragment);
        mTabViewFragments.add(answerFragment);
        mTabViewFragments.add(allProblemFragment);
        initViewPagerAdapter();
    }

    private void initTablyoutLgav() {
     //团队咨询
        String OBJECTTYPEONE = "1";
    // 新问题
        String DATASCOREZONE = "0";
        NewProblemFragment newfragment=NewProblemFragment.newInstance(DATASCOREZONE, OBJECTTYPEONE);

        //待解答
        UnansweredFragment unansweredFragment = UnansweredFragment.newInstance(DATASCOREONE, OBJECTTYPEONE);
        //已解答
        AnswerFragment answerFragment = AnswerFragment.newInstance(DATASCORETWO, OBJECTTYPEONE);
        //已结贴
        AllProblemFragment allProblemFragment = AllProblemFragment.newInstance(DATASCORETHREE, OBJECTTYPEONE);
        if (mTabViewFragments == null) {
            mTabViewFragments = new ArrayList<>();
        }
        mTabViewFragments.clear();
        mTabViewFragments.add(newfragment);
        mTabViewFragments.add(unansweredFragment);
        mTabViewFragments.add(answerFragment);
        mTabViewFragments.add(allProblemFragment);
        initViewPagerAdapter();
    }


    private void initTablyout() {
        //法律顾问
        String OBJECTTYPETWO = "0";

        //未解答
        UnansweredFragment unansweredFragment = UnansweredFragment.newInstance(DATASCOREONE, OBJECTTYPETWO);
        //已解答
        AnswerFragment answerFragment = AnswerFragment.newInstance(DATASCORETWO, OBJECTTYPETWO);
        //全部问题
        AllProblemFragment allProblemFragment = AllProblemFragment.newInstance(DATASCORETHREE, OBJECTTYPETWO);
        if (mTabViewFragments == null) {
            mTabViewFragments = new ArrayList<>();
        }
        mTabViewFragments.clear();
        mTabViewFragments.add(unansweredFragment);
        mTabViewFragments.add(answerFragment);
        mTabViewFragments.add(allProblemFragment);
        initViewPagerAdapter();
    }

    private void initViewPagerAdapter() {
        if (mTabName.size() < 2) {
            mTabOrgMyproblem.setVisibility(View.GONE);
        } else {
            mTabOrgMyproblem.setVisibility(View.VISIBLE);
        }
        InformationViewPageAdapter pageAdapter = new InformationViewPageAdapter(getSupportFragmentManager(), mTabName, mTabViewFragments);
        mNoScrollViewPager.setAdapter(pageAdapter);
        mTabOrgMyproblem.setupWithViewPager(mNoScrollViewPager);
        mNoScrollViewPager.setOffscreenPageLimit(mTabName.size() < 2 ? 2 : mTabName.size());
    }


    private void initView() {
        mContext = this;
        mTabOrgMyproblem = (TabLayout) findViewById(R.id.tab_org_myproblem);
        mNoScrollViewPager = (NoScrollViewPager) findViewById(R.id.scrollView_org_myproble);
        mNoScrollViewPager.setPagingEnabled(false);
        Intent intent = getIntent();
        mRoleType = intent.getStringExtra(LAWYERROLE);

    }


}
