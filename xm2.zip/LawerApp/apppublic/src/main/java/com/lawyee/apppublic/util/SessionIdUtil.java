package com.lawyee.apppublic.util;

import android.content.Context;
import android.widget.Toast;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;

import net.lawyee.mobilelib.json.JsonCreater;
import net.lawyee.mobilelib.utils.PhoneInfoUtil;
import net.lawyee.mobilelib.utils.SecurityUtil;
import net.lawyee.mobilelib.utils.T;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.util
 * @Description: ${todo}(用一句话描述该文件做什么)
 * @author: uustrong
 * @date: 2017/12/29 15:41
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class SessionIdUtil {
    public static String  getUserSessionId( Context context){
        String sessionId="";
        JsonCreater creater = JsonCreater.startJson(getDevID(context));
        if(ApplicationSet.getInstance().getUserVO().getSessionId()==null){
            T.show(context, context.getString(R.string.no_login), Toast.LENGTH_SHORT);
            return sessionId;
        }
        sessionId = SecurityUtil.Encrypt(ApplicationSet.getInstance().getUserVO().getSessionId(), SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS);
        return sessionId;
    }
    public  static String  getAppstamp( Context context){
        JsonCreater creater = JsonCreater.startJson(getDevID(context));
        return creater.getId();
    }
    protected static String getDevID( Context context) {
        return PhoneInfoUtil.GetIMEI(context);
    }
}
