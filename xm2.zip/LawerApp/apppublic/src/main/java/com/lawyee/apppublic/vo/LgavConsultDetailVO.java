package com.lawyee.apppublic.vo;

import android.content.Context;

import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 黔微普法详情
 * @author: YFL
 * @date: 2017/10/13 16:21
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavConsultDetailVO extends LgavConsultVO {
    /**
     * 律师抢答问题和解答问题
     */
    private List<LgavConsultReplyVO> replyList;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    private static final long serialVersionUID = 4763227486117090933L;

    public static String dataFilename(Context context) {
        return dataListFileName(context, serialVersionUID);
    }

    public List<LgavConsultReplyVO> getReplyList() {
        return replyList;
    }

    public void setReplyList(List<LgavConsultReplyVO> replyList) {
        this.replyList = replyList;
    }

    /**
     * 判断状态
     * @return
     */
    public  String getStringWithConsultStatus() {
        String content = "";
        switch (getConsultStatus()) {
            case "0":
                content = "解答";
                break;
            case "1":
                content = "已结束";
                break;
            case "2":
                content = "继续解答";
                break;
            case "3":
                content="超时";
                break;
            case "4":
                content="继续解答";
                break;
            default:
                break;

        }
             return content;
    }

}
