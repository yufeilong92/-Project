package com.lawyee.apppublic.vo;

import android.content.Context;

import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 黔微普法活动列表vo
 * @author: YFL
 * @date: 2017/10/12 11:22
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavConsultVO extends BaseVO {
    private static final long serialVersionUID = -4599261852703543646L;
    /**
     * 咨询人姓名
     */
    private String personName;
    /**
     * 咨询人id
     */
    private String personId;
    /**
     * 咨询人头像地址
     */
    private String personPhoto;
    /**
     * 咨询主题
     */
    private String consultTopic;
    /**
     * 案件类型一级id
     */
    private String typeOneId;
    /**
     * 案件类型一级name
     */
    private String typeOneName;
    /**
     * 案件类型二级id
     */
    private String typeTwoId;
    /**
     * 案件类型二级name
     */
    private String typeTwoName;
    /**
     * 咨询内容
     */
    private String consultContent;
    /**
     * 咨询时间
     */
    private String consultTime;
    /**
     * 咨询状态（1 已结束 0未结束",
     */
    private String consultStatus;
    /**
     * 是否公开（1是 0否）
     */
    private String anonymousFlag;
    /**
     * 评价状态（1已评价 0未评价
     */
    private String evaluateStatus;

    /**
     * 提问类型ID
     */
    private String objectType;
    /**
     * 提问类型（村居法顾或律师团队）
     */
    private String objectTypeName;
    /**
     * 咨询广场
     */
    private String publishStatus;
    /**
     * 0可抢答、1可解答、-1不可解答
     */
    private String answerFlag;



    /**
     * 判断状态
     * @return
     */
    public  String getStringWithConsultStatus() {
        String content = "";
        switch (getConsultStatus()) {
            case "0":
                content = "解答";
                break;
            case "1":
                content = "已结束";
                break;
            case "2":
                content = "继续解答";
                break;
            case "3":
                content="超时";
                break;
            case "4":
                content="继续解答";
                break;
            default:
                break;
        }
        return content;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getPersonPhoto() {
        return personPhoto;
    }

    public void setPersonPhoto(String personPhoto) {
        this.personPhoto = personPhoto;
    }

    public String getConsultTopic() {
        return consultTopic;
    }

    public void setConsultTopic(String consultTopic) {
        this.consultTopic = consultTopic;
    }

    public String getTypeOneId() {
        return typeOneId;
    }

    public void setTypeOneId(String typeOneId) {
        this.typeOneId = typeOneId;
    }

    public String getTypeOneName() {
        return typeOneName;
    }

    public void setTypeOneName(String typeOneName) {
        this.typeOneName = typeOneName;
    }

    public String getTypeTwoId() {
        return typeTwoId;
    }

    public void setTypeTwoId(String typeTwoId) {
        this.typeTwoId = typeTwoId;
    }

    public String getTypeTwoName() {
        return typeTwoName;
    }

    public void setTypeTwoName(String typeTwoName) {
        this.typeTwoName = typeTwoName;
    }

    public String getConsultContent() {
        return consultContent;
    }

    public void setConsultContent(String consultContent) {
        this.consultContent = consultContent;
    }

    public String getConsultTime() {
        return consultTime;
    }

    public void setConsultTime(String consultTime) {
        this.consultTime = consultTime;
    }

    public String getConsultStatus() {
        return consultStatus;
    }

    public void setConsultStatus(String consultStatus) {
        this.consultStatus = consultStatus;
    }

    public String getAnonymousFlag() {
        return anonymousFlag;
    }

    public void setAnonymousFlag(String anonymousFlag) {
        this.anonymousFlag = anonymousFlag;
    }

    public String getEvaluateStatus() {
        return evaluateStatus;
    }

    public void setEvaluateStatus(String evaluateStatus) {
        this.evaluateStatus = evaluateStatus;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectTypeName() {
        return objectTypeName;
    }

    public void setObjectTypeName(String objectTypeName) {
        this.objectTypeName = objectTypeName;
    }

    public String getPublishStatus() {
        return publishStatus;
    }

    public void setPublishStatus(String publishStatus) {
        this.publishStatus = publishStatus;
    }

    public String getAnswerFlag() {
        return answerFlag;
    }

    public void setAnswerFlag(String answerFlag) {
        this.answerFlag = answerFlag;
    }

    public static String dataFileName(Context context, String filename) {
        return dataFileName(context, serialVersionUID, filename);
    }
}
