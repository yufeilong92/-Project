package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.andview.refreshview.recyclerview.BaseRecyclerAdapter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.ui.lawyerService.SessionActivity;
import com.lawyee.apppublic.ui.personalcenter.jals.JaglsEntrustDetailActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerEntrustDetailActivity;
import com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.LgavActivityDetailActivity;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemDetailActivity;
import com.lawyee.apppublic.util.SessionIdUtil;
import com.lawyee.apppublic.util.TextViewUtil;
import com.lawyee.apppublic.util.XMPPHelper;
import com.lawyee.apppublic.vo.ConsulationRecordVO;
import com.lawyee.apppublic.vo.UserMessageVO;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.TimeUtil;

import java.util.ArrayList;

import static com.lawyee.apppublic.config.Constants.MESSAGE_LAWACTIVITY;
import static com.lawyee.apppublic.config.Constants.MESSAGE_LAWBASCIENTRUST;
import static com.lawyee.apppublic.config.Constants.MESSAGE_LAWENTRUST;
import static com.lawyee.apppublic.config.Constants.MESSAGE_LAWPROBLEM;
import static com.lawyee.apppublic.ui.BaseActivity.CSTR_EXTRA_TITLE_STR;
import static com.lawyee.apppublic.ui.lawyerService.SessionActivity.CSTR_EXTRA_SESSION_STR;
import static com.lawyee.apppublic.ui.personalcenter.jals.JaglsEntrustDetailActivity.JAGLSENTRUSTDETAIL;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerEntrustDetailActivity.LAWENTRUSTDETAIL;
import static com.lawyee.apppublic.ui.personalcenter.lawyer.WebViewShowActivity.CSTR_URL;
import static com.lawyee.apppublic.ui.personalcenter.myproblempage.LgavActivityDetailActivity.ACTIVITYOID;
import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemDetailActivity.PROBLEMOID;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.adapter
 * @Description: (我的消息Adpater)
 * @author: czq
 * @date: 2017/5/27 14:30
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class MyMessageAdpater extends BaseRecyclerAdapter<MyMessageAdpater.ViewHolder> {
    /**
     * 3种类型
     */
    public static final int CHAT = 0;//聊天类型
    public static final int OTHER = 1;//其他类型
    private Context mContext;
    private ArrayList<UserMessageVO> mDatas;




    public MyMessageAdpater(ArrayList<UserMessageVO> list, Context context) {
        this.mDatas = list;
        this.mContext = context;
    }

    public void setmDatas(ArrayList<UserMessageVO> list) {
        this.mDatas = list;
        notifyDataSetChanged();
    }


    @Override
    public ViewHolder getViewHolder(View view) {
        return new ViewHolder(view);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i, boolean b) {
        View view = View.inflate(mContext, R.layout.item_my_message, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i, boolean b) {
        final UserMessageVO userMessageVO=mDatas.get(i);
        if(!StringUtil.isEmpty(mDatas.get(i).getCategory())&&mDatas.get(i).getCategory().equals("chat")){
                    viewHolder.mLlOtherItem.setVisibility(View.GONE);
            viewHolder.mLlItem.setVisibility(View.VISIBLE);
                    final ConsulationRecordVO consulationRecordVO = userMessageVO.getConsulationRecordVO();
                    TextViewUtil.isEmpty(viewHolder.mTvName, consulationRecordVO.getFriendName());
                    TextViewUtil.isEmpty(viewHolder.mTvTime, TimeUtil.getChatTime(Long.parseLong(consulationRecordVO.getSendTime())));
                    TextViewUtil.isEmpty(viewHolder.mTvContent, XMPPHelper.generShowMessage(mContext, consulationRecordVO.getContent()) + "");
                    if (consulationRecordVO.getNoReadnum() == 0) {
                        viewHolder.mTvTipNum.setVisibility(View.INVISIBLE);
                    } else {
                        viewHolder.mTvTipNum.setVisibility(View.VISIBLE);
                        if (consulationRecordVO.getNoReadnum() > 99) {
                            viewHolder.mTvTipNum.setText(R.string.num_99);
                        } else {
                            viewHolder.mTvTipNum.setText(consulationRecordVO.getNoReadnum() + "");
                        }
                    }
            viewHolder.mLlItem.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(mContext, SessionActivity.class);
                            intent.putExtra(CSTR_EXTRA_SESSION_STR, consulationRecordVO.getFriendId());
                            intent.putExtra(CSTR_EXTRA_TITLE_STR, consulationRecordVO.getFriendName());
                            mContext.startActivity(intent);
                        }
                    });
                }else{
               viewHolder.mLlOtherItem.setVisibility(View.VISIBLE);
                 viewHolder.mLlItem.setVisibility(View.GONE);
                        TextViewUtil.isEmpty(viewHolder.mTvOtherContent,userMessageVO.getContent());
                         TextViewUtil.isEmpty(viewHolder.mTvOtherTime,userMessageVO.getSendTime());
                        if(userMessageVO.getReadStatus().equals("false")){
                            viewHolder.mIvTip.setVisibility(View.VISIBLE);
                        }else {
                            viewHolder.mIvTip.setVisibility(View.INVISIBLE);
                        }
            viewHolder.mLlOtherItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(ApplicationSet.getInstance().getUserVO().isPublicUser()){
                        Intent intent = new Intent(mContext, WebViewShowActivity.class);
                        intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.my_message_detail));
                       String  url=mContext.getString(R.string.url_base) +mContext.getString(R.string.url_message)+userMessageVO.getOid()+ mContext.getString(R.string.url_sessionid) +SessionIdUtil.getUserSessionId(mContext) +
                               mContext. getString(R.string.url_appstamp) +  SessionIdUtil.getAppstamp(mContext);
                        intent.putExtra(CSTR_URL, url);
                        mContext.startActivity(intent);
                    }else{
                        if(userMessageVO.getPid()==null){
                            return;
                        }
                      if(userMessageVO.getCategory().equals(MESSAGE_LAWBASCIENTRUST)){//基层委托
                            Intent intent = new Intent(mContext, JaglsEntrustDetailActivity.class);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR,mContext.getString(R.string.entrust_detail));
                            intent.putExtra(JAGLSENTRUSTDETAIL, userMessageVO.getPid());
                            mContext.startActivity(intent);
                        }else if(userMessageVO.getCategory().equals(MESSAGE_LAWENTRUST)){//律师委托
                            Intent intent = new Intent(mContext, LawyerEntrustDetailActivity.class);
                            intent.putExtra(CSTR_EXTRA_TITLE_STR,mContext.getString(R.string.entrust_detail));
                            intent.putExtra(LAWENTRUSTDETAIL, userMessageVO.getPid());
                            mContext.startActivity(intent);
                        }else if(userMessageVO.getCategory().equals(MESSAGE_LAWACTIVITY)){//村居活动
                            Intent intent = new Intent(mContext, LgavActivityDetailActivity.class);
                            intent.putExtra(ACTIVITYOID, userMessageVO.getPid());
                            mContext.startActivity(intent);
                        }else if(userMessageVO.getCategory().equals(MESSAGE_LAWPROBLEM)){//黔微普法
                            Intent intent = new Intent(mContext, MyProblemDetailActivity.class);
                            intent.putExtra(PROBLEMOID, userMessageVO.getPid());
                            mContext.startActivity(intent);
                        }

                    }
                }
            });
                }

    }

    @Override
    public int getAdapterItemCount() {
        return mDatas.size();
    }



    class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView mListitemBaseIv;
        private TextView mTvName;
        private TextView mTvTime;
        private TextView mTvContent;
        private LinearLayout mLlItem;
        private TextView mTvTipNum;
        private TextView mTvOtherContent;
        private TextView mTvOtherTime;
        private ImageView mIvTip;
        private LinearLayout mLlOtherItem;
        public ViewHolder(View itemView) {
            super(itemView);
            mLlItem = (LinearLayout) itemView.findViewById(R.id.ll_item);
            mListitemBaseIv = (ImageView) itemView
                    .findViewById(R.id.listitem_base_iv);
            mTvName = (TextView) itemView
                    .findViewById(R.id.tv_name);
            mTvTime = (TextView) itemView
                    .findViewById(R.id.tv_time);
            mTvContent = (TextView) itemView
                    .findViewById(R.id.tv_content);
            mTvTipNum = (TextView) itemView.findViewById(R.id.tv_tip_num);
            mLlOtherItem = (LinearLayout) itemView.findViewById(R.id.ll_other_item);
            mTvOtherContent = (TextView) itemView
                    .findViewById(R.id.tv_other_content);
            mTvOtherTime = (TextView) itemView
                    .findViewById(R.id.tv_other_time);
            mIvTip = (ImageView) itemView.findViewById(R.id.iv_tip);

        }

        private void setData(int position) {

        }
    }
}
