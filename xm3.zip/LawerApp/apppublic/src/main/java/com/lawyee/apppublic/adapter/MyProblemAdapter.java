package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.andview.refreshview.recyclerview.BaseRecyclerAdapter;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.DataManage;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.util.TimeSampUtil;
import com.lawyee.apppublic.vo.LgavConsultVO;

import net.lawyee.mobilelib.utils.StringUtil;

import java.util.ArrayList;

import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity.CANCELACTION;
import static com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemActivity.KNOCKACTION;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: 我的问题适配器
 * @author: YFL
 * @date: 2017/9/25 16:46
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MyProblemAdapter extends BaseRecyclerAdapter<MyProblemAdapter.ViewHolder> implements View.OnClickListener {


    private Context mContext;
    private ArrayList mDatas;
    private final LayoutInflater mInflater;

    private setOnRecyclerViewItemOnlickListener setOnRecyclerViewItemOnlickListener = null;////itmeView接口

    private OnRecyclerButtonOnlickListener buttonOnlickListener = null;//按钮接口
    /**
     * 非公开显示名字
     */
    private static final String ANONYMOUSFLAGONE = "false";
    /**
     * 公开显示名字
     */
    private static final String ANONYMOUSFLAGTWO = "true";
    /**
     * 已评价状态
     */
    private static final String EVALUATESTATUSONE = "true";
    /**
     * 已结束状态
     */
    private static final String EVALUATESTATUSTWE = "1";
    /**
     * 0可抢答
     */
    public static final String ANSWERFLAGZERO = "0";
    /**
     * 1可解答
     */
    public static final String ANSWERFLAGONE = "1";
    /**
     * -1不可解答
     */
    public static final String ANSWERFLAGTWO = "-1";
    /**
     * 2已解答
     */
    public static final String ANSWERFLAGTHREE = "2";

    /**
     * 村居顾问标示
     */
    private static final String OBJECTTYPEZERO = "0";
    /**
     * 律师团队标示
     */
    private static final String OBJECTTYPEONE = "1";
    /**
     * 咨询状态
     */
    private static final String CONSULTSTATUSTHREE = "3";
    /**
     * 咨询状态
     */
    private static final String CONSULTSTATUTWO = "2";
    /**
     * 顾问标示
     */
    private String mMark;
    /**
     * 律师标示
     */
    private String lawMark;

    public interface OnRecyclerButtonOnlickListener {
        /**
         * 控件点击监听
         *
         * @param view
         * @param o
         * @param position
         */
        public void OnButtonClickListener(View view, Object o, String name, int position);

    }

    public interface onBtnCancelListener {
        /**
         * 控件点击监听
         *
         * @param view
         * @param id         OID
         * @param actiontype 按钮类型 0 抢答 1 取消
         */
        public void OnCancelListener(View view, String id, String actiontype, int position);

    }

    public onBtnCancelListener cancelListener = null;

    public onBtnCancelListener getCancelListener() {
        return cancelListener;
    }

    public void setCancelListener(onBtnCancelListener cancelListener) {
        this.cancelListener = cancelListener;
    }

    public OnRecyclerButtonOnlickListener getButtonOnlickListener() {
        return buttonOnlickListener;
    }

    public void setButtonOnlickListener(OnRecyclerButtonOnlickListener buttonOnlickListener) {
        this.buttonOnlickListener = buttonOnlickListener;
    }

    private MyProblemAdapter.setOnRecyclerViewItemOnlickListener getSetOnRecyclerViewItemOnlickListener() {
        return setOnRecyclerViewItemOnlickListener;
    }

    public void setSetOnRecyclerViewItemOnlickListener(MyProblemAdapter.setOnRecyclerViewItemOnlickListener setOnRecyclerViewItemOnlickListener) {
        this.setOnRecyclerViewItemOnlickListener = setOnRecyclerViewItemOnlickListener;
    }


    public interface setOnRecyclerViewItemOnlickListener {
        /**
         * item 项回调
         *
         * @param view 当前view
         * @param o
         */
        public void setOnRecyclerView(View view, Object o);
    }

    public MyProblemAdapter(Context mContext, ArrayList mDatas, String mark) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.mMark = mark;
        mInflater = LayoutInflater.from(mContext);
    }

    /**
     * @param position 更新数据的下标
     * @param obj      数据
     */
    public void replaceNewItemData(int position, Object obj) {
        if (obj == null)
            return;
        String answerflag = (String) obj;
        LgavConsultVO vo = (LgavConsultVO) mDatas.get(position);
        vo.setAnswerFlag(answerflag);
        mDatas.set(position, vo);
        notifyItemChanged(position);

    }


    /**
     * @param position 更新数据的下标
     * @param obj      数据
     */
    public void replaceNewItemData(int position, Object obj, String status) {
        if (obj == null)
            return;
        String answerflag = (String) obj;
        LgavConsultVO vo = (LgavConsultVO) mDatas.get(position);
        vo.setAnswerFlag(answerflag);
        vo.setConsultStatus(status);
        mDatas.set(position, vo);
        notifyItemChanged(position);

    }

    /**
     * 删除某条数据
     *
     * @param positon
     */
    public void deleteItemData(int positon) {
        mDatas.remove(positon);
        notifyItemRemoved(positon);
    }

    public void setLawMark(String lawMark) {
        this.lawMark = lawMark;
    }

    @Override
    public ViewHolder getViewHolder(View view) {
        return new ViewHolder(view);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i, boolean b) {
        View view = mInflater.inflate(R.layout.item_myproblem, null);
        view.setOnClickListener(this);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position, boolean b) {

        //数据
        final LgavConsultVO vo = (LgavConsultVO) mDatas.get(position);

        if (vo.getAnonymousFlag() != null && vo.getAnonymousFlag().equals(ANONYMOUSFLAGONE)) {
            holder.mTvMyproName.setText(vo.getPersonName());
        }
        if (vo.getAnonymousFlag() != null && vo.getAnonymousFlag().equals(ANONYMOUSFLAGTWO)) {
            holder.mTvMyproName.setText(R.string.anonymous);
        } else {
            holder.mTvMyproName.setText(vo.getPersonName());
        }
        //判断案件级别
        String evaluatestatus = getEvaluatestatus(vo);
        holder.mTvItemMyproTag.setText(evaluatestatus);
        holder.mTvItemMyproTitle.setText(vo.getConsultTopic());
        //计算时间戳
        String timeStamp = TimeSampUtil.getStringTimeStamp(vo.getConsultTime());
        holder.mTvMyproTime.setText(timeStamp);

        //隐藏律师标签
        holder.mLineTagLayout.setVisibility(View.GONE);
        holder.mTvMyproContent.setText(vo.getConsultContent());
        //设置头像
        ShowOrHide.showPhotoPicture(mContext, vo.getPersonPhoto(), holder.mIvItemMyproPhoto, vo.getAnonymousFlag());
        //显示已结束状态
        if (vo.getConsultStatus() != null && vo.getConsultStatus().equals(EVALUATESTATUSTWE)) {
            holder.mTvMyproStutas.setVisibility(View.VISIBLE);
            holder.mTvMyproStutas.setText(R.string.been_finished_2);
        } else {
            holder.mTvMyproStutas.setVisibility(View.GONE);
        }
//        if (vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEONE)) {//律师团队
            /// if (isShowAnswerView(vo)){
//                holder.mTvMyproStutas.setVisibility(View.VISIBLE);
//                holder.mTvMyproStutas.setText(vo.getStringWithConsultStatus());
//            }
            //抢答解答按钮
            if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGONE)) {//可以解答
                holder.mTvMyproStutas.setVisibility(View.GONE);
                holder.mRlItemMyprolistKnock.setVisibility(View.GONE);
                holder.mRlItemMyprolistAnswer.setVisibility(View.VISIBLE);
                holder.mBtnItemMyprolistCancel.setVisibility(View.VISIBLE);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGZERO)) {//可抢答
                holder.mRlItemMyprolistKnock.setVisibility(View.VISIBLE);
                holder.mRlItemMyprolistAnswer.setVisibility(View.GONE);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGTWO)) {//不可解答
                if (vo.getConsultStatus() != null && vo.getConsultStatus().equals(EVALUATESTATUSTWE)) {
                    holder.mRlItemMyprolistAnswer.setVisibility(View.VISIBLE);
                    holder.mBtnItemMyprolistCancel.setVisibility(View.GONE);
                } else {
                    holder.mRlItemMyprolistAnswer.setVisibility(View.GONE);
                }
                holder.mRlItemMyprolistKnock.setVisibility(View.GONE);
                holder.mBtnItemMyprolistStatusKnock.setClickable(false);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGTHREE)) {//已解答过
                holder.mRlItemMyprolistKnock.setVisibility(View.GONE);
                holder.mRlItemMyprolistAnswer.setVisibility(View.VISIBLE);
                holder.mBtnItemMyprolistCancel.setVisibility(View.GONE);
            }
//        } else if (vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEZERO)) {//村居顾问
//            holder.mRlItemMyprolistKnock.setVisibility(View.GONE);
//            holder.mRlItemMyprolistAnswer.setVisibility(View.VISIBLE);
//            holder.mBtnItemMyprolistCancel.setVisibility(View.GONE);
//        }
        //按钮状态回调 --回调内容
        //按钮显示
        if (mMark.equals("1") && isLawCase(vo)) {
            holder.mBtnMyproStatus.setText(mContext.getResources().getString(R.string.answer));
        } else if (mMark.equals("1") && lawMark != null && lawMark.equals("-1")) {
            holder.mBtnMyproStatus.setText(mContext.getResources().getString(R.string.answer));
        } else {
            holder.mBtnMyproStatus.setText(handlerBtnShowStatus(vo));
        }
        holder.mBtnMyproStatus.setOnClickListener(new View.OnClickListener() {//查看评价按钮
            @Override
            public void onClick(View v) {
                if (!TimeSampUtil.handleOnDoubleClick()) {
                    return;
                }
                if (buttonOnlickListener != null) {
                    buttonOnlickListener.OnButtonClickListener(v, vo, handlerBtnShowStatus(vo), position);
                }
            }
        });


        holder.mBtnItemMyprolistCancel.setOnClickListener(new View.OnClickListener() {//抢答按钮
            @Override
            public void onClick(View v) {
                if (cancelListener != null)
                    cancelListener.OnCancelListener(v, vo.getOid(), CANCELACTION, position);
            }
        });

        holder.mBtnItemMyprolistStatusKnock.setOnClickListener(new View.OnClickListener() {//取消解答按钮
            @Override
            public void onClick(View v) {
                if (cancelListener != null)
                    cancelListener.OnCancelListener(v, vo.getOid(), KNOCKACTION, position);
            }
        });

        //回调item点击回调内容
        holder.itemView.setTag(vo);

    }

    /**
     * @param vo
     * @return 是否是值班律师
     */
    private boolean isLaw(LgavConsultVO vo) {
        return vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEONE);
    }


    /**
     * @param vo
     * @return 是否是法顾
     */
    private boolean isLawCase(LgavConsultVO vo) {
        return vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEZERO);
    }

    private boolean isShowCancelView(LgavConsultVO vo) {
        return vo.getConsultStatus() != null && vo.getConsultStatus().equals(CONSULTSTATUTWO);
    }

    private boolean isShowAnswerView(LgavConsultVO vo) {//超时
        return vo.getConsultStatus() != null && vo.getConsultStatus().equals(CONSULTSTATUSTHREE);
    }

    private String getObjectTypeName(LgavConsultVO vo) {
        if (!StringUtil.isEmpty(vo.getObjectTypeName()))
            return vo.getObjectTypeName();
        if (!StringUtil.isEmpty(vo.getObjectType())) {
            return DataManage.getInstance().getNameWithOid(vo.getObjectType());
        }
        return "";
    }

    /**
     * @param vo
     * @return
     */
    private String handlerBtnShowStatus(LgavConsultVO vo) {

        //判断是否评价过
        if (vo.getEvaluateStatus().equals(EVALUATESTATUSONE)) {
            return "查看评价";
        }
        if (vo.getAnswerFlag().equals(ANSWERFLAGONE)) {
            return "解答";
        }
        if (vo.getAnswerFlag().equals(ANSWERFLAGTHREE)) {
            return "继续解答";
        }


        //根据是否回复过
        return vo.getStringWithConsultStatus();

    }

    /**
     * 获取案件类型
     *
     * @param vo
     * @return
     */
    private String getEvaluatestatus(LgavConsultVO vo) {
        if (!StringUtil.isEmpty(vo.getTypeTwoName())) {
            return vo.getTypeTwoName();
        }
        if (!StringUtil.isEmpty(vo.getTypeTwoId())) {
            return DataManage.getInstance().getNameWithOid(vo.getTypeTwoId());
        }
        if (!StringUtil.isEmpty(vo.getTypeOneName())) {
            return vo.getTypeOneName();
        }
        if (!StringUtil.isEmpty(vo.getTypeOneId())) {
            return DataManage.getInstance().getNameWithOid(vo.getTypeOneId());
        }
        return "";
    }

    @Override
    public void onClick(View v) {
        if (setOnRecyclerViewItemOnlickListener != null) {
            setOnRecyclerViewItemOnlickListener.setOnRecyclerView(v, v.getTag());
        }
    }

    @Override
    public int getAdapterItemCount() {
        return mDatas.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView mIvItemMyproPhoto;
        public TextView mTvMyproName;
        public TextView mTvItemMyproTab;
        public LinearLayout mLineTagLayout;
        public TextView mTvItemMyproTitle;
        public TextView mTvItemMyproTag;
        public TextView mTvMyproContent;
        public TextView mTvMyproTime;
        public TextView mTvMyproStutas;
        public Button mBtnMyproStatus;
        private Button mBtnItemMyprolistStatusKnock;
        private RelativeLayout mRlItemMyprolistKnock;
        private Button mBtnItemMyprolistCancel;
        private RelativeLayout mRlItemMyprolistAnswer;

        public ViewHolder(View itemView) {
            super(itemView);
            this.mIvItemMyproPhoto = (ImageView) itemView.findViewById(R.id.iv_item_myprolist_photo);
            this.mTvMyproName = (TextView) itemView.findViewById(R.id.tv_myprolist_name);
            this.mTvItemMyproTab = (TextView) itemView.findViewById(R.id.tv_item_myprolist_tab);
            this.mLineTagLayout = (LinearLayout) itemView.findViewById(R.id.line_taglist_layout);
            this.mTvItemMyproTitle = (TextView) itemView.findViewById(R.id.tv_item_myprolist_title);
            this.mTvItemMyproTag = (TextView) itemView.findViewById(R.id.tv_item_myprolist_tag);
            this.mTvMyproContent = (TextView) itemView.findViewById(R.id.tv_myprolist_content);
            this.mTvMyproTime = (TextView) itemView.findViewById(R.id.tv_myprolist_time);
            this.mTvMyproStutas = (TextView) itemView.findViewById(R.id.tv_myprolist_stutas);
            this.mBtnMyproStatus = (Button) itemView.findViewById(R.id.btn_item_myprolist_status);
            this.mBtnItemMyprolistCancel = (Button) itemView.findViewById(R.id.btn_item_myprolist_cancel);
            this.mBtnItemMyprolistStatusKnock = (Button) itemView.findViewById(R.id.btn_item_myprolist_status_knock);
            this.mRlItemMyprolistKnock = (RelativeLayout) itemView.findViewById(R.id.rl_item_myprolist_knock);
            this.mRlItemMyprolistAnswer = (RelativeLayout) itemView.findViewById(R.id.rl_item_myprolist_answer);
        }
    }
}
