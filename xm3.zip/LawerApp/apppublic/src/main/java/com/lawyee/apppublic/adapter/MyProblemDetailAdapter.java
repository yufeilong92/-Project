package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.DataManage;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavProblemService;
import com.lawyee.apppublic.ui.personalcenter.myproblempage.MyProblemDetailActivity;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.util.TimeSampUtil;
import com.lawyee.apppublic.vo.LgavConsultDetailVO;
import com.lawyee.apppublic.vo.LgavConsultReplyVO;
import com.lawyee.apppublic.vo.LgavConsultVO;
import com.lawyee.apppublic.vo.UserVO;
import com.lawyee.apppublic.widget.RecycleViewDivider;

import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

import static com.lawyee.apppublic.adapter.MyProblemAdapter.ANSWERFLAGONE;
import static com.lawyee.apppublic.adapter.MyProblemAdapter.ANSWERFLAGTHREE;
import static com.lawyee.apppublic.util.UIUtils.getContext;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: 问题详情页
 * @author: YFL
 * @date: 2017/9/26 15:18
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MyProblemDetailAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private Object mDatas;
    private LayoutInflater mInflater;
    public static final int ONEPROBLEM = 0;//问题界面
    public static final int TWOANSWER = 1;//律师回答布局
    private MyProblemDetailActivity activity;
    /**
     * 非公开显示名字
     */
    private static final String ANONYMOUSFLAGONE = "true";
    /**
     * 公开显示名字
     */
    private static final String ANONYMOUSFLAGTWO = "false";
    /**
     * 防止重复提交
     */
    private boolean mIsSubmit = false;
    /**
     * 当前布局
     */
    public int SHOWVIEW = ONEPROBLEM;
    /**
     * 已结束状态标签
     */
    private static final String EVALUATESTATUSONE = "1";
    /**
     * 咨询状态未回复
     */
    private static final String CONSULTSTATUSNO = "0";
    /**
     * 咨询状态
     */
    private static final String CONSULTSTATUSTHREE = "3";
    /**
     * 已回复状态标签
     */
    private static final String CONSULTSTATUSYES = "2";
    /**
     * 律师解答
     */
    private static final String REPLYTYPE = "1";
    /**
     * 律师回复
     */
    private static final String REPLYTYPEONE = "0";

    /**
     * 取消解答
     */
    private static final String CANCELACTION = "1";
    /**
     * 抢答
     */
    private static final String KNOCKACTION = "0";
    /**
     * 村居顾问标示
     */
    private static final String OBJECTTYPEZERO = "0";
    /**
     * 律师团队标示
     */
    private static final String OBJECTTYPEONE = "1";

    /**
     * 是否抢答
     */
    private boolean mIsKnock = false;
    /**
     * 模块id
     */
    private String mMark;
    /**
     * id
     */
    private MyLaywerAnswerAdapter mAnsweradapter;

    /**
     * @param mContext
     * @param mDatas                       数据
     * @param myProblemDetailActivityClass 上下文
     */
    public MyProblemDetailAdapter(Context mContext, Object mDatas, MyProblemDetailActivity myProblemDetailActivityClass) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.activity = myProblemDetailActivityClass;
        mInflater = LayoutInflater.from(mContext);
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == ONEPROBLEM) {//咨询问题界面
            return new ProblemViewHolder(mInflater.inflate(R.layout.item_myproblemdetail, null));
        } else if (viewType == TWOANSWER) {//回复界面
            return new AnswerViewHolder(mInflater.inflate(R.layout.item_mypro_laywer_detail, null));
        }
        return null;
    }

    public void setNewData(Object mDatas) {
        this.mDatas = mDatas;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        LgavConsultDetailVO vo = (LgavConsultDetailVO) mDatas;
        //处理本律师是否对改咨询进行解答
        if (getItemViewType(position) == ONEPROBLEM) {//问题详情
            //获取网络数据显示
            bindConsultProblemViewData(holder, position, vo);
        } else if (getItemViewType(position) == TWOANSWER) {//解答详情
            //获取律师回答问题
            bindLawyerAnswerViewData(holder, position, vo);
        }
    }

    //绑定律师回答数据
    private void bindLawyerAnswerViewData(RecyclerView.ViewHolder holder, int position, LgavConsultDetailVO vo) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        List<LgavConsultReplyVO> replys = vo.getReplyList();
        if (replys == null && replys.isEmpty())
            return;
        AnswerViewHolder viewHolder = (AnswerViewHolder) holder;
        ArrayList<LgavConsultReplyVO> objects = new ArrayList<>();
        for (int i = 0; i < replys.size(); i++) {
            LgavConsultReplyVO replyVO = replys.get(i);
            String status = replyVO.getGainStatus();
            String userId = userVO.getUserId();
            String replayId = replyVO.getUserId();
            if (status != null && !status.equals("1") && !status.equals("3")) {
                if (userId.equals(replayId)) {
                    objects.add(replyVO);
                } else {
                    continue;
                }
            } else {
                objects.add(replyVO);
            }

        }

        setLawyerAnserAdapter(viewHolder, objects, vo);
    }

    /**
     * 律师回答数据
     *
     * @param viewHolder
     * @param list       评价集合
     * @param vo         详情vo
     */
    private void setLawyerAnserAdapter(AnswerViewHolder viewHolder, List<?> list, final LgavConsultDetailVO vo) {
        mAnsweradapter = new MyLaywerAnswerAdapter(mContext, list, vo);
        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 1);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        viewHolder.mRlvMyproAnswer.addItemDecoration(new RecycleViewDivider(mContext, GridLayoutManager.VERTICAL, R.drawable.bg_rlv_diving_lgav));
        viewHolder.mRlvMyproAnswer.setLayoutManager(layoutManager);
        viewHolder.mRlvMyproAnswer.setAdapter(mAnsweradapter);
        //律师提交公众追问
        mAnsweradapter.setSubmitListener(new MyLaywerAnswerAdapter.BtnSubmitListener() {
            @Override
            public void btnSubmitClickL(String replyConte, String oid) {
                if (mIsSubmit) {
                    return;
                }
                mIsSubmit = true;
                if (StringUtil.isEmpty(replyConte)) {
                    T.showShort(mContext, mContext.getString(R.string.please_answer_enmpty));
                    mIsSubmit = false;
                    return;
                }
                submitService(replyConte, true, oid);
            }

            @Override
            public void dismissDialog() {
                mIsSubmit = false;
            }
        });

        mAnsweradapter.setSubmitContent(new MyLaywerAnswerAdapter.SubmitContent() {
            @Override
            public void submitContent(String str, String oid) {
                submitService(str, true, oid);
            }
        });

    }


    /**
     * //绑定问题详情
     *
     * @param holder
     * @param position
     * @param vo       详情vo
     */
    private void bindConsultProblemViewData(RecyclerView.ViewHolder holder, int position, final LgavConsultDetailVO vo) {
        ProblemViewHolder viewHolder = (ProblemViewHolder) holder;
        //显示时间戳
        if (vo.getConsultTime() != null && !StringUtil.isEmpty(vo.getConsultTime())) {
            String timeStamp = TimeSampUtil.getStringTimeStamp(vo.getConsultTime());
            viewHolder.mTvMyproTime.setText(timeStamp);
        }

        if (vo.getAnonymousFlag() != null && vo.getAnonymousFlag().equals(ANONYMOUSFLAGONE)) {
            viewHolder.mTvMyproName.setText(R.string.anonymous);
        } else if (vo.getAnonymousFlag() != null && vo.getAnonymousFlag().equals(ANONYMOUSFLAGTWO)) {
            viewHolder.mTvMyproName.setText(vo.getPersonName());
        } else {
            viewHolder.mTvMyproName.setText(vo.getPersonName());
        }

        //律师/村居标签处理
        viewHolder.mLineTagLayout.setVisibility(View.GONE);
        viewHolder.mTvItemMyproTag.setText(getEvaluatestatus(vo));
        viewHolder.mTvItemMyproTitle.setText(vo.getConsultTopic());
        viewHolder.mTvMyproContent.setText(vo.getConsultContent());
//        viewHolder.mBtnItemMyprodetialCancel.setText(R.string.cancelAnswer);

/*        if (vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEONE)) {//律师团队

//            if (isShowAnswerView(vo)){
//                viewHolder.mTvMyproStutas.setVisibility(View.VISIBLE);
//                viewHolder.mTvMyproStutas.setText(vo.getStringWithConsultStatus());
//
//            }
            //抢答解答按钮
            if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGONE)) {//可以解答
                viewHolder.mRlMyproKnock.setVisibility(View.GONE);
                viewHolder.mRlItemMyproAnswer.setVisibility(View.VISIBLE);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGZERO)) {//可抢答
                viewHolder.mRlMyproKnock.setVisibility(View.VISIBLE);
                viewHolder.mRlItemMyproAnswer.setVisibility(View.GONE);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGTWO)) {//不可解答
                viewHolder.mRlMyproKnock.setVisibility(View.GONE);
                viewHolder.mBtnItemMyprodetailStatusKnock.setClickable(false);
                viewHolder.mRlItemMyproAnswer.setVisibility(View.GONE);
            } else if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAGTHREE)) {//已解答过
                viewHolder.mRlMyproKnock.setVisibility(View.GONE);
                viewHolder.mRlItemMyproAnswer.setVisibility(View.VISIBLE);
                viewHolder.mBtnItemMyprodetialCancel.setVisibility(View.GONE);
                viewHolder.mBtnMyproStatus.setText(handlerBtnShowStatus(vo));
            }

        } else if (vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEZERO)) {//村居顾问
            viewHolder.mRlMyproKnock.setVisibility(View.GONE);
            viewHolder.mRlItemMyproAnswer.setVisibility(View.VISIBLE);
            viewHolder.mBtnItemMyprodetialCancel.setVisibility(View.GONE);
        }*/
//        //抢答
//        viewHolder.mBtnItemMyprodetailStatusKnock.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                submitKnockService(vo.getOid(), KNOCKACTION, true);
//
//            }
//        });
//        //取消解答接口
//        viewHolder.mBtnItemMyprodetialCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                submitKnockService(vo.getOid(), CANCELACTION, false);
//            }
//        });

        //判断是否结束 按钮是否显示
//        if (vo.getConsultStatus() != null && vo.getConsultStatus().equals(EVALUATESTATUSONE)) {//咨询结束
//            viewHolder.mTvMyproStutas.setVisibility(View.VISIBLE);
//            viewHolder.mTvMyproStutas.setText(R.string.been_finished_2);
//            viewHolder.mBtnMyproStatus.setVisibility(View.GONE);
//        } else {
//            if (mMark.equals("1") &&isLawCase(vo)) {//法顾
//                viewHolder.mBtnMyproStatus.setText(mContext.getResources().getString(R.string.answer));
//            } else if (lawMark!=null&&lawMark.equals("-1")&&mMark.equals("1")){//值班律师
//                viewHolder.mBtnMyproStatus.setText(mContext.getResources().getString(R.string.answer));
//            }else {
//                viewHolder.mBtnMyproStatus.setText(handlerBtnShowStatus(vo));
//
//            }
//        }

        //头像显示方法
        ShowOrHide.showPhotoPicture(mContext, vo.getPersonPhoto(), viewHolder.mIvItemMyproPhoto, vo.getAnonymousFlag());
//        viewHolder.mBtnMyproStatus.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //结束是不显示提示框
//                if (vo.getConsultStatus() != null && !vo.getConsultStatus().equals(EVALUATESTATUSONE)) {
//                    if (vo.getAnswerFlag() != null && vo.getAnswerFlag().equals(ANSWERFLAG)) {
//                        showInputBoxDialog(vo.getOid(), true);
//                    } else {
//                        showInputBoxDialog(vo.getOid(), false);
//                    }
//                }
//            }
//        });


    }

    /**
     * 是否值班律师
     *
     * @param vo
     * @return
     */
    private boolean isLaw(LgavConsultVO vo) {
        return vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEONE);
    }

    /**
     * @param vo
     * @return 是否是法顾
     */
    private boolean isLawCase(LgavConsultVO vo) {
        return vo.getObjectType() != null && vo.getObjectType().equals(OBJECTTYPEZERO);
    }

    private boolean isShowAnswerView(LgavConsultVO vo) {//超时
        return vo.getConsultStatus() != null && vo.getConsultStatus().equals(CONSULTSTATUSTHREE);
    }

    /***
     * 提交抢答
     * @param id id
     * @param actiontype 类型
     */
    private void submitKnockService(final String id, String actiontype, final boolean isKnock) {
        if (mIsKnock) {
            return;
        }
        mIsKnock = true;
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.setShowProgress(true);
        problemService.setProgressShowContent(isKnock ? "抢答中..." : "取消解答...");
        problemService.submitLgavAcitonAnswer(id, actiontype, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mIsKnock = false;
                activity.requestService(false);
                T.showShort(mContext, isKnock ? "抢答成功" : "取消解答成功");
            }

            @Override
            public void onError(String msg, String content) {
                mIsKnock = false;
                T.showShort(mContext, msg);
            }
        });

    }

    /**
     * 显示回答输入框
     *
     * @param oid
     * @param b
     */
    private void showInputBoxDialog(final String oid, final boolean b) {
        if (mIsSubmit) {
            return;
        }
        mIsSubmit = true;
        // 显示解答框
        ShowOrHide.ShowInputBoxDialog(mContext, new ShowOrHide.GetInputOutString() {
            @Override
            public void inputOutString(String content) {
                if (StringUtil.isEmpty(content)) {
                    T.showShort(mContext, mContext.getString(R.string.please_answer_enmpty));
                    mIsSubmit = false;
                    return;
                }
                submitService(content, b, oid);
            }

            @Override
            public void dismissDialog() {
                mIsSubmit = false;
            }
        });
    }

    /**
     * @param content     回复内容
     * @param isreplyType 是否解答过
     * @param oid         回复id
     */
    private void submitService(String content, boolean isreplyType, String oid) {
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.setShowProgress(true);
        problemService.setProgressShowContent(mContext.getResources().getString(R.string.submit_ing));
        String replyType = "";
        if (isreplyType) {
            replyType = REPLYTYPE;
        } else {
            replyType = REPLYTYPEONE;
        }
        problemService.submitLgavPostReply(content, replyType, oid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                mIsSubmit = false;
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, R.string.prompt_network_receiving_data_error);
                    return;
                }
                LgavConsultDetailVO vo = (LgavConsultDetailVO) values.get(0);
                if (vo == null) {
                    return;
                }
                T.showShort(mContext, R.string.submit_success);
                setNewData(vo);
                mAnsweradapter.setNewData(vo.getReplyList(), vo);
                mAnsweradapter.notifyDataSetChanged();

            }

            @Override
            public void onError(String msg, String content) {
                mIsSubmit = false;
                T.showShort(getContext(), msg);
            }
        });
    }

    /**
     * 获取按钮状态
     *
     * @param vo
     * @return
     */
    private String handlerBtnShowStatus(LgavConsultDetailVO vo) {

        //判断是否评价过
        if (vo.getAnswerFlag().equals(ANSWERFLAGONE)) {
            return mContext.getString(R.string.answer);
        }
        if (vo.getAnswerFlag().equals(ANSWERFLAGTHREE)) {
            return "继续解答";
        }
        //根据是否回复过
        return vo.getStringWithConsultStatus();
    }

    /**
     * 获取案件类型
     *
     * @param vo
     * @return
     */
    private String getEvaluatestatus(LgavConsultDetailVO vo) {
        if (!StringUtil.isEmpty(vo.getTypeTwoName())) {
            return vo.getTypeTwoName();
        }
        if (!StringUtil.isEmpty(vo.getTypeTwoId())) {
            return DataManage.getInstance().getNameWithOid(vo.getTypeTwoId());
        }
        if (!StringUtil.isEmpty(vo.getTypeOneName())) {
            return vo.getTypeOneName();
        }
        if (!StringUtil.isEmpty(vo.getTypeOneId())) {
            return DataManage.getInstance().getNameWithOid(vo.getTypeOneId());
        }
        return "";
    }

    private String getObjectTypeName(LgavConsultDetailVO vo) {
        if (!StringUtil.isEmpty(vo.getObjectTypeName()))
            return vo.getObjectTypeName();
        if (!StringUtil.isEmpty(vo.getObjectType())) {
            return DataManage.getInstance().getNameWithOid(vo.getObjectType());
        }
        return "";
    }

    /**
     * 根据位置得到类型-系统调用
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        switch (position) {
            case ONEPROBLEM://问题界面
                SHOWVIEW = ONEPROBLEM;
                break;
            case TWOANSWER://律师回答
                SHOWVIEW = TWOANSWER;
                break;
            default:
                break;
        }
        return SHOWVIEW;
    }


    @Override
    public int getItemCount() {
        return 2;
    }

    public static class AnswerViewHolder extends RecyclerView.ViewHolder {
        public RecyclerView mRlvMyproAnswer;

        public AnswerViewHolder(View itemView) {
            super(itemView);
            this.mRlvMyproAnswer = (RecyclerView) itemView.findViewById(R.id.rlv_mypro_answer);
        }
    }

    public static class ProblemViewHolder extends RecyclerView.ViewHolder {
        public ImageView mIvItemMyproPhoto;
        public TextView mTvMyproName;
        public TextView mTvItemMyproTab;
        public LinearLayout mLineTagLayout;
        public TextView mTvItemMyproTitle;
        public TextView mTvItemMyproTag;
        public TextView mTvMyproContent;
        public TextView mTvMyproTime;
        public TextView mTvMyproStutas;
        public Button mBtnMyproStatus;
        public Button mBtnItemMyprodetailStatusKnock;
        public RelativeLayout mRlMyproKnock;
        public Button mBtnItemMyprodetialCancel;
        public RelativeLayout mRlItemMyproAnswer;

        public ProblemViewHolder(View itemView) {
            super(itemView);
            this.mIvItemMyproPhoto = (ImageView) itemView.findViewById(R.id.iv_item_mypro_photo);
            this.mTvMyproName = (TextView) itemView.findViewById(R.id.tv_mypro_name);
            this.mTvItemMyproTab = (TextView) itemView.findViewById(R.id.tv_item_mypro_tab);
            this.mLineTagLayout = (LinearLayout) itemView.findViewById(R.id.line_tag_layout);
            this.mTvItemMyproTitle = (TextView) itemView.findViewById(R.id.tv_item_mypro_title);
            this.mTvItemMyproTag = (TextView) itemView.findViewById(R.id.tv_item_mypro_tag);
            this.mTvMyproContent = (TextView) itemView.findViewById(R.id.tv_mypro_content);
            this.mTvMyproTime = (TextView) itemView.findViewById(R.id.tv_mypro_time);
            this.mTvMyproStutas = (TextView) itemView.findViewById(R.id.tv_mypro_stutas);
            this.mBtnMyproStatus = (Button) itemView.findViewById(R.id.btn_item_mypro_status);
            this.mBtnItemMyprodetailStatusKnock = (Button) itemView.findViewById(R.id.btn_item_myprodetail_status_knock);
            this.mRlMyproKnock = (RelativeLayout) itemView.findViewById(R.id.rl_mypro_knock);
            this.mBtnItemMyprodetialCancel = (Button) itemView.findViewById(R.id.btn_item_myprodetial_cancel);
            this.mRlItemMyproAnswer = (RelativeLayout) itemView.findViewById(R.id.rl_item_mypro_answer);

        }
    }


}
