package com.lawyee.apppublic.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.util.TimeSampUtil;
import com.lawyee.apppublic.vo.LgavConsultReplyAskVO;
import com.lawyee.apppublic.vo.LgavConsultReplyVO;
import com.lawyee.apppublic.vo.LgavConsultVO;

import java.util.List;

import static com.lawyee.apppublic.adapter.MyLaywerAnswerAdapter.ANONYMOUSFLAG;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.adapter
 * @Description: $todo$
 * @author: YFL
 * @date: 2017/10/27 13:49
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class PeopleAnswerReplyAdpater extends RecyclerView.Adapter implements View.OnClickListener {

    private Context mContext;
    private List<LgavConsultReplyAskVO> mDatas;

    private LgavConsultVO mDetailVo;
    private final LayoutInflater mInflater;
    private LgavConsultReplyVO mReplyVO;

    /**
     * 公众追问
     */
    private static final String ASKTYPEONE = "0";
    /**
     * 律师解答
     */
    private static final String ASKTYPETWO = "1";
    /**
     * 解答状态超时
     */
    private static final String GAINSTATUS = "2";

    /**
     * 已评价
     */
    private static final String EVALUATESTATUS = "1";

    /**
     * 咨询状态已结束
     */
    private static final String CONSULTSTATUS = "1";
    /**
     * 类型，0追问、1追答
     */
    public static final String ASKTYPE = "1";

    public interface ReplyAskClikcListener {
        /**\
         * 继续解答按钮回调
         * @param view
         */
        public void ReplyAskClickListener(View view);
    }

    public ReplyAskClikcListener replyAskClikcListener = null;

    public ReplyAskClikcListener getReplyAskClikcListener() {
        return replyAskClikcListener;
    }

    public void setReplyAskClikcListener(ReplyAskClikcListener replyAskClikcListener) {
        this.replyAskClikcListener = replyAskClikcListener;
    }

    public PeopleAnswerReplyAdpater(Context mContext, List<LgavConsultReplyAskVO> mDatas, LgavConsultVO mDetail, LgavConsultReplyVO replyVO) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.mDetailVo = mDetail;
        this.mReplyVO = replyVO;
        mInflater = LayoutInflater.from(mContext);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_mypro_repleask, null);
        return new ReplyAskViewHodler(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewholder, int position) {
        ReplyAskViewHodler hodler = (ReplyAskViewHodler) viewholder;
        LgavConsultReplyAskVO vo = (LgavConsultReplyAskVO) mDatas.get(position);
        //判断是否是公众
        if (vo.getAskType().equals(ASKTYPEONE)) {//公众追问
            //是否匿名
            if (mDetailVo.getAnonymousFlag().equals(ANONYMOUSFLAG)) {//选中匿名
                hodler.mTvItemMyproReplyname.setText(R.string.anonymous);
            } else {
                hodler.mTvItemMyproReplyname.setText(vo.getUserName());
            }

            ShowOrHide.showPhotoPicture(mContext, mDetailVo.getPersonPhoto(), hodler.mIvItemMyproReplyPhoto
                    , mDetailVo.getAnonymousFlag());
            hodler.mBtnItemMyproReply.setVisibility(View.GONE);

        } else if (vo.getAskType().equals(ASKTYPETWO)) {//律师
            hodler.mBtnItemMyproReply.setVisibility(View.GONE);
            hodler.mTvItemMyproReplyname.setText(vo.getUserName());
            ShowOrHide.showPhotoPicture(mContext, mReplyVO.getUserPhoto(), hodler.mIvItemMyproReplyPhoto
                    , mDetailVo.getAnonymousFlag());
            //判断用户解答是否超时 或者已评价或者，结束
      /*      if (mReplyVO.getGainStatus().equals(GAINSTATUS)||
                    mDetailVo.getEvaluateStatus().equals(EVALUATESTATUS) ||
                    mDetailVo.getConsultStatus().equals(CONSULTSTATUS)||
                    vo.getAskType().equals(ASKTYPE)) {
                hodler.mBtnItemMyproReply.setVisibility(View.GONE);
            } else {
                hodler.mBtnItemMyproReply.setVisibility(View.VISIBLE);
            }*/
        }
        String timeStamp = TimeSampUtil.getStringTimeStamp(vo.getAskTime());
        hodler.mTvItemMyproReplytime.setText(timeStamp);
        hodler.mTvItemMyproReplycontent.setText(vo.getAskContent());
        hodler.mBtnItemMyproReply.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (replyAskClikcListener!=null){
            replyAskClikcListener.ReplyAskClickListener(v);

        }
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }


    public static class ReplyAskViewHodler extends RecyclerView.ViewHolder {
        public LinearLayout mLinearReplayUser;
        public View mViewReplyLineXuxian;
        public ImageView mIvItemMyproReplyPhoto;
        public TextView mTvItemMyproReplyname;
        public TextView mTvItemMyproReplytime;
        public Button mBtnItemMyproReply;
        public TextView mTvItemMyproReplycontent;

        public ReplyAskViewHodler(View itemView) {
            super(itemView);
            this.mLinearReplayUser = (LinearLayout) itemView.findViewById(R.id.linear_replay_user);
            this.mViewReplyLineXuxian = (View) itemView.findViewById(R.id.view__reply_line_xuxian);
            this.mIvItemMyproReplyPhoto = (ImageView) itemView.findViewById(R.id.iv_item_mypro_replyPhoto);
            this.mTvItemMyproReplyname = (TextView) itemView.findViewById(R.id.tv_item_mypro_replyname);
            this.mTvItemMyproReplytime = (TextView) itemView.findViewById(R.id.tv_item_mypro_replytime);
            this.mBtnItemMyproReply = (Button) itemView.findViewById(R.id.btn_item_mypro_reply);
            this.mTvItemMyproReplycontent = (TextView) itemView.findViewById(R.id.tv_item_mypro_replycontent);
        }
    }
}
