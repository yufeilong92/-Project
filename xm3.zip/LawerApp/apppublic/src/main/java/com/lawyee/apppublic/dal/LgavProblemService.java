package com.lawyee.apppublic.dal;

import android.content.Context;

import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.vo.UserVO;

import net.lawyee.mobilelib.json.JsonCreater;
import net.lawyee.mobilelib.utils.SecurityUtil;
import net.lawyee.mobilelib.utils.StringUtil;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.dal
 * @Description: 我的问题接口
 * @author: YFL
 * @date: 2017/10/12 11:12
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavProblemService extends BaseJsonService {
    /**
     * @param c
     */
    public LgavProblemService(Context c) {
        super(c);
    }

    /**
     *
     * @param pageNo 页码
     * @param datascore 0：新问题  1：待解答,2已解答，3已结贴（新）
     * @param objectType 1团队咨询，0法律顾问 -1 转值班律师
     * @param listener
     */
    public void queryLgavGetConsultList(int pageNo,String datascore,String objectType, IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if (!ApplicationSet.getInstance().IsLogin()) {
            listener.onError("请先进行用户登录", "");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId", SecurityUtil.Encrypt(userVO.getSessionId(), SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        creater.setParam("pageNo", pageNo < 1 ? 1 : pageNo);
        creater.setParam("pageSize", Constants.CINT_PAGE_SIZE);
        if (!StringUtil.isEmpty(datascore))
            creater.setParam("datascore", datascore);
        creater.setParam("objectType",objectType);
        creater.setParam("businessType","9b3f7ca997424892bdbdd9b9ec1034c0");
        mCommandName = "mmLgavGetConsultList";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_LIST);
        getData(json, null);
    }


    /**
     * 查询我的问题详情
     *
     * @param questionoId
     * @param listener
     */
    public void queryLgavGetConsultDetail(String questionoId, IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if (!ApplicationSet.getInstance().IsLogin()) {
            listener.onError("请先进行用户登录", "");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId", SecurityUtil.Encrypt(userVO.getSessionId(), SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        if (!StringUtil.isEmpty(questionoId)) {
            creater.setParam("consultId", questionoId);
        }

        mCommandName = "mmLgavGetConsultDetail";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);
    }

    /**
     * 回复咨询内容
     *
     * @param replyContent 回复内容
     * @param oid          问题id
     * @param listener
     */
    public void submitLgavPostReply(String replyContent, String repltType, String oid, IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if (!ApplicationSet.getInstance().IsLogin()) {
            listener.onError("请先进行用户登录", "");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId", SecurityUtil.Encrypt(userVO.getSessionId(), SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));


        if (!StringUtil.isEmpty(replyContent)) {
            creater.setParam("replyContent", replyContent);
        }
//        if (!StringUtil.isEmpty(repltType))
//            creater.setParam("replyType", repltType);
        if (!StringUtil.isEmpty(oid)) {
            creater.setParam("oid", oid);
        }
        mCommandName = "mmLgavPostReply";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);
    }

    /**
     * 回复咨询内容
     *
     * @param consultId  咨询id
     * @param actionType 类型，0 抢答 1 取消解答
     * @param listener
     */
    public void submitLgavAcitonAnswer(String consultId, String actionType, IResultInfoListener listener) {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        if (!ApplicationSet.getInstance().IsLogin()) {
            listener.onError("请先进行用户登录", "");
            return;
        }
        JsonCreater creater = JsonCreater.startJson(getDevID());
        creater.setParam("sessionId", SecurityUtil.Encrypt(userVO.getSessionId(), SecurityUtil.getLegalKey(creater.getId()), Constants.CSTR_IVS));

        if (!StringUtil.isEmpty(consultId))
            creater.setParam("consultId", consultId);
        if (!StringUtil.isEmpty(actionType)) {
            creater.setParam("actionType", actionType);
        }
        mCommandName = "mmLgavKnockAnswer";
        String json = creater.createJson(mCommandName);
        setResultInfoListener(listener);
        setValueType(CINT_VALUETYPE_ENTITY);
        getData(json, null);
    }
}
