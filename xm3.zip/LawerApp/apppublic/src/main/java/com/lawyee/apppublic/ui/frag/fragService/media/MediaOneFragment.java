package com.lawyee.apppublic.ui.frag.fragService.media;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.DataManage;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JamedUserService;
import com.lawyee.apppublic.ui.frag.fragService.BaseFragment;
import com.lawyee.apppublic.ui.lawAdministration.ShowInfomActivity;
import com.lawyee.apppublic.vo.JamedApplyDetailVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;


/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  MediaOneFragment.java 
 * @Package com.lawyee.apppublic.ui.frag.fragService.media   
 * @Description:    申请人信息页
 * @author: YFL
 * @date:   2017/8/30 15:34
 * @version V 1.0 xxxxxxxx
 * @verdescript  版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/8/30 www.lawyee.com Inc. All rights reserved. 
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MediaOneFragment extends BaseFragment implements View.OnClickListener {
    /**
     * 机构id
     */
    private static final String ARG_ORGID = "orgid";
    /**
     * 人民调解详情数据
     */
    private static final String ARG_JAMEDAPPLYDETAILVO = "jamedapplydetailvo";
    /**
     * 显示调解状态
     */
    private static final String ARG_MEDIASTATUS = "mediastatus";
    private static final String mSecrecy = "保密";
    private String mOrgOid;
    private TextView mTvMediaOneApplyType;
    private TextView mTvMediaOneLookOrg;
    private TextView mTvMediaOneLookAgree;
    private TextView mTvMediaOneLookName;
    private TextView mTvMediaOneLookSex;
    private TextView mTvMediaOneLookCardType;
    private TextView mTvMediaOneLookAge;
    private TextView mTvMediaOneLookNation;
    private TextView mTvMediaOneLookTelephone;
    private TextView mTvMediaOneLookAddress;
    private TextView mTvMediaOneLookRelation;
    private TextView mTvMediaOneLookBeiName;
    private TextView mTvMediaOneLookBeiSex;
    private TextView mTvMediaOneLookBeiAge;
    private TextView mTvMediaOneLookBeiNation;
    private TextView mTvMediaOneLookBeiTelephone;
    private TextView mTvMediaOneLookBeiAddress;
    private TextView mTvMediaOneLookCase;
    private TextView mTvMediaOneLookItem;
    private Context mContext;
    private JamedApplyDetailVO mJamedDetailVo;
    private Button mBtnMediaOneSubmit;
    private String mStutas;
    private TextView mTvMediaOneAssign;

    /**
     *
     * @param orgId 机构id
     * @param jamedApplyDetailVO  申请人详情
     * @param mediastatus 调解状态
     * @return
     */
    public static MediaOneFragment newInstance(String orgId, JamedApplyDetailVO jamedApplyDetailVO, String mediastatus) {
        MediaOneFragment fragment = new MediaOneFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ORGID, orgId);
        args.putSerializable(ARG_JAMEDAPPLYDETAILVO, jamedApplyDetailVO);
        args.putSerializable(ARG_MEDIASTATUS, mediastatus);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mOrgOid = getArguments().getString(ARG_ORGID);
            mJamedDetailVo = (JamedApplyDetailVO) getArguments().getSerializable(ARG_JAMEDAPPLYDETAILVO);
            mStutas = getArguments().getString(ARG_MEDIASTATUS);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_media_one, container, false);
        initView(view);
        return view;
    }

    private void initView(View view) {
        mContext = getActivity();
        mTvMediaOneApplyType = (TextView) view.findViewById(R.id.tv_MediaOne_ApplyType);
        mTvMediaOneLookOrg = (TextView) view.findViewById(R.id.tv_MediaOne_LookOrg);
        mTvMediaOneLookAgree = (TextView) view.findViewById(R.id.tv_MediaOne_LookAgree);
        mTvMediaOneLookName = (TextView) view.findViewById(R.id.tv_MediaOne_LookName);
        mTvMediaOneLookSex = (TextView) view.findViewById(R.id.tv_MediaOne_LookSex);
        mTvMediaOneLookCardType = (TextView) view.findViewById(R.id.tv_MediaOne_LookCardType);
        mTvMediaOneLookAge = (TextView) view.findViewById(R.id.tv_MediaOne_LookAge);
        mTvMediaOneLookNation = (TextView) view.findViewById(R.id.tv_MediaOne_LookNation);
        mTvMediaOneLookTelephone = (TextView) view.findViewById(R.id.tv_MediaOne_LookTelephone);
        mTvMediaOneLookAddress = (TextView) view.findViewById(R.id.tv_MediaOne_LookAddress);
        mTvMediaOneLookRelation = (TextView) view.findViewById(R.id.tv_MediaOne_LookRelation);
        mTvMediaOneLookBeiName = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiName);
        mTvMediaOneLookBeiSex = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiSex);
        mTvMediaOneLookBeiAge = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiAge);
        mTvMediaOneLookBeiNation = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiNation);
        mTvMediaOneLookBeiTelephone = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiTelephone);
        mTvMediaOneLookBeiAddress = (TextView) view.findViewById(R.id.tv_MediaOne_LookBeiAddress);
        mTvMediaOneLookCase = (TextView) view.findViewById(R.id.tv_MediaOne_LookCase);
        mTvMediaOneLookItem = (TextView) view.findViewById(R.id.tv_MediaOne_LookItem);
        mBtnMediaOneSubmit = (Button) view.findViewById(R.id.btn_mediaOne_submit);
        mTvMediaOneAssign = (TextView)view.findViewById(R.id.tv_MediaOne_assign);
        mBtnMediaOneSubmit.setOnClickListener(this);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (mJamedDetailVo != null) {
            selectResultShow(mJamedDetailVo);
        } else {
            requestServiceData();
        }
    }

    /**
     * 选择是否显示结果页
     * @param mJamedDetailVo
     */
    private void selectResultShow(JamedApplyDetailVO mJamedDetailVo) {
        String mediaFlag = mJamedDetailVo.getApplyMediaConfirm();
        boolean flag=false;
        if (mediaFlag.equals("1")){
            flag=true;
        }else {
            flag=false;
        }
        handlerSelectShowData(mJamedDetailVo,flag);
    }

    private void requestServiceData() {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setShowProgress(true);
        jamedUserService.setProgressShowContent(getString(R.string.get_ing));
        jamedUserService.getApplyDetail(mOrgOid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }

                JamedApplyDetailVO vo = (JamedApplyDetailVO) values.get(0);
                if (vo != null) {
                    selectResultShow(vo);
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });
    }

    /***
     *
     * @param vo 申请人数据
     * @param isShow 是否显示申请人保密信息
     */
    private void handlerSelectShowData(JamedApplyDetailVO vo, boolean isShow) {
        if (isShow) {
            mTvMediaOneLookCardType.setText(vo.getApplyIdCard());
            mTvMediaOneLookTelephone.setText(vo.getApplyTelephone());
            mTvMediaOneLookAddress.setText(vo.getApplyAddress());
            mTvMediaOneLookBeiTelephone.setText(vo.getBeApplyTelephone());
            mTvMediaOneLookBeiAddress.setText(vo.getBeApplyAddress());
        } else {
            mTvMediaOneLookCardType.setText(mSecrecy);
            mTvMediaOneLookTelephone.setText(mSecrecy);
            mTvMediaOneLookAddress.setText(mSecrecy);
            mTvMediaOneLookBeiTelephone.setText(mSecrecy);
            mTvMediaOneLookBeiAddress.setText(mSecrecy);
        }
        //当事人是否同意
        if (vo.isMediaFlag()) {
            mBtnMediaOneSubmit.setVisibility(View.GONE);
        } else {
            if (!mStutas.equals(ShowInfomActivity.MSTATUSONEBEGIN) && !mStutas.equals(ShowInfomActivity.MSTATUSTHREEORGNOAGREE))
                if (vo.getMediaApplyType()!=null&&vo.getMediaApplyType().equals("2")) {
                    mBtnMediaOneSubmit.setVisibility(View.GONE);
                } else {
                    mBtnMediaOneSubmit.setVisibility(View.VISIBLE);
                }
        }
        mTvMediaOneApplyType.setText(vo.getStringWithIsTjType());
        mTvMediaOneLookOrg.setText(vo.getTjOrgName());
        mTvMediaOneAssign.setText(vo.getAssignOrgName());
        mTvMediaOneLookAgree.setText(vo.getStringWithMediaFlag());
        mTvMediaOneLookName.setText(vo.getApplyName());
        mTvMediaOneLookSex.setText(DataManage.getInstance().getNameWithOid(vo.getApplyGender()));
        mTvMediaOneLookAge.setText(vo.getApplyAge());
        mTvMediaOneLookNation.setText(DataManage.getInstance().getNameWithOid(vo.getApplyNation()));
        mTvMediaOneLookRelation.setText(vo.getRelation());
        mTvMediaOneLookBeiName.setText(vo.getBeApplyName());
        mTvMediaOneLookBeiSex.setText(DataManage.getInstance().getNameWithOid(vo.getBeApplyGender()));
        mTvMediaOneLookBeiAge.setText(vo.getBeApplyAge());
        mTvMediaOneLookBeiNation.setText(DataManage.getInstance().getNameWithOid(vo.getBeApplyNation()));
        mTvMediaOneLookCase.setText(vo.getIntroduction());
        mTvMediaOneLookItem.setText(vo.getMatter());

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_mediaOne_submit:
                MaterialDialog.Builder showDialog = getShowDialog();
                showDialog.onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                        submitServiceData();
                        materialDialog.dismiss();
                    }
                });
                showDialog.onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                        materialDialog.dismiss();
                    }
                });
                break;
            default:
                break;
        }

    }

    private void submitServiceData() {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setShowProgress(true);
        jamedUserService.setProgressShowContent(getString(R.string.submit_success));
        jamedUserService.postMediaApply(mOrgOid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                T.showShort(mContext, getString(R.string.submit_ok));
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });

    }
}
