package com.lawyee.apppublic.ui.frag.fragService.media;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.lawyee.apppublic.R;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JamedUserService;
import com.lawyee.apppublic.ui.frag.fragService.BaseFragment;
import com.lawyee.apppublic.ui.lawAdministration.ShowInfomActivity;
import com.lawyee.apppublic.util.ShowOrHide;
import com.lawyee.apppublic.vo.JamedApplyDetailVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  MediaThreeFragment.java
 * @Package com.lawyee.apppublic.ui.frag.fragService.media
 * @Description:    媒体录制信息页
 * @author: YFL
 * @date:   2017/8/30 15:33
 * @version V 1.0 xxxxxxxx
 * @verdescript  版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/8/30 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MediaThreeFragment extends BaseFragment implements View.OnClickListener {
    /**
     * 机构id
     */
    private static final String ARG_ORGID = "orgid";
    /**
     * 调解状态
     */
    private static final String ARG_MEDIASTUTAS = "mediastutas";
    /**
     * 申请人详情数据
     */
    private static final String ARG_JAMEDDETAILVO = "jameddetialvo";

    private String mOrgID;
    private String mMediaStutas;
    private TextView mTvMediaThreeBeginTime;
    private EditText mEtMediaThreeAddress;
    private Button mBtnMediaThreeSubmit;
    private LinearLayout mLinearMediathreeApply;
    private TextView mTvMediathreeResulttime;
    private TextView mTvMediathreeResultaddress;
    private LinearLayout mLiearMediathreeResult;
    private Context mContext;
    private JamedApplyDetailVO mJamedDetailVo;

    public MediaThreeFragment() {
    }

    /**
     *
     * @param orgId 机构id
     * @param mediaStutas 调解状态
     * @param jamedDetailVo 申请人详情
     * @return
     */
    public static MediaThreeFragment newInstance(String orgId, String mediaStutas, JamedApplyDetailVO jamedDetailVo) {
        MediaThreeFragment fragment = new MediaThreeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ORGID, orgId);
        args.putString(ARG_MEDIASTUTAS, mediaStutas);
        args.putSerializable(ARG_JAMEDDETAILVO, jamedDetailVo);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mOrgID = getArguments().getString(ARG_ORGID);
            mMediaStutas = getArguments().getString(ARG_MEDIASTUTAS);
            mJamedDetailVo = (JamedApplyDetailVO) getArguments().getSerializable(ARG_JAMEDDETAILVO);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_media_three, container, false);
        initView(view);
        return view;
    }


    private void initView(View view) {
        mTvMediaThreeBeginTime = (TextView) view.findViewById(R.id.tv_MediaThree_BeginDate);
        mTvMediaThreeBeginTime.setOnClickListener(this);
        mEtMediaThreeAddress = (EditText) view.findViewById(R.id.et_MediaThree_Address);
        mBtnMediaThreeSubmit = (Button) view.findViewById(R.id.btn_MediaThree_Submit);
        mLinearMediathreeApply = (LinearLayout) view.findViewById(R.id.linear_mediathree_apply);
        mTvMediathreeResulttime = (TextView) view.findViewById(R.id.tv_mediathree_resulttime);
        mTvMediathreeResultaddress = (TextView) view.findViewById(R.id.tv_mediathree_resultaddress);
        mLiearMediathreeResult = (LinearLayout) view.findViewById(R.id.liear_mediathree_result);
        mContext = getActivity();
        mBtnMediaThreeSubmit.setOnClickListener(this);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (mJamedDetailVo != null) {
            selectResultShow(mJamedDetailVo);
        } else {
            requestServiceData();
        }
    }


    private void requestServiceData() {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setProgressShowContent(getString(R.string.get_ing));
        jamedUserService.setShowProgress(true);
        jamedUserService.getApplyDetail(mOrgID, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                JamedApplyDetailVO vo = (JamedApplyDetailVO) values.get(0);
                if (vo != null) {
                    selectResultShow(vo);
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });
    }

    /**
     * 处理选择结果
     * @param vo 申请人数据
     */
    private void selectResultShow(JamedApplyDetailVO vo) {
        String recordTime = vo.getRecordTime();
        String recordAddress = vo.getRecordAddress();
        if (TextUtils.isEmpty(recordTime) || TextUtils.isEmpty(recordAddress)) {
            isShowResultData(false, null);
        } else {
            isShowResultData(true, vo);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_MediaThree_Submit:
                submit();
                break;
            case R.id.tv_MediaThree_BeginDate://显示时间
                ShowOrHide.getDialogYMDHms(mContext, mTvMediaThreeBeginTime);
                break;
        }
    }

    private void submit() {
        final String begintime = getTextStr(mTvMediaThreeBeginTime);
        if (TextUtils.isEmpty(begintime)) {
            T.showShort(mContext, getString(R.string.pleaserecordTime));
            return;
        }
        final String address = getTextStr(mEtMediaThreeAddress);
        if (TextUtils.isEmpty(address)) {
            T.showShort(mContext, getString(R.string.pleaserecordAddress));
            return;
        }

        MaterialDialog.Builder builder = getShowDialog();
        builder.onPositive(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                submitServcie(begintime, address);
                materialDialog.dismiss();
            }
        });
        builder.onNegative(new MaterialDialog.SingleButtonCallback() {
            @Override
            public void onClick(@NonNull MaterialDialog materialDialog, @NonNull DialogAction dialogAction) {
                materialDialog.dismiss();
            }
        });
    }

    /**
     * 提交服务器
     * @param begintime 录制开始时间
     * @param address 录制地点
     */
    private void submitServcie(String begintime, String address) {
        JamedUserService jamedUserService = new JamedUserService(mContext);
        jamedUserService.setShowProgress(true);
        jamedUserService.setProgressShowContent(getString(R.string.submit_ing));
        jamedUserService.postMediaRecord(mOrgID, begintime, address, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, content);
                    return;
                }
                T.showShort(mContext, getString(R.string.submit_success));
                JamedApplyDetailVO vo = (JamedApplyDetailVO) values.get(0);
                if (vo != null) {
                    ShowInfomActivity activity = (ShowInfomActivity) getActivity();
                    activity.selectNextFourBtnSet(true);
                    isShowResultData(true, vo);
                }
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });

    }

    /**
     * 显示结果
     *
     * @param b  是否显示结果页
     * @param vo 申请人详情数据
     */
    private void isShowResultData(boolean b, JamedApplyDetailVO vo) {
        if (!b) {
            mLiearMediathreeResult.setVisibility(View.GONE);
            mLinearMediathreeApply.setVisibility(View.VISIBLE);
            return;
        }
        mLiearMediathreeResult.setVisibility(View.VISIBLE);
        mLinearMediathreeApply.setVisibility(View.GONE);
        if (vo != null) {
            mTvMediathreeResulttime.setText(vo.getRecordTime());
            mTvMediathreeResultaddress.setText(vo.getRecordAddress());
        }
    }
}
