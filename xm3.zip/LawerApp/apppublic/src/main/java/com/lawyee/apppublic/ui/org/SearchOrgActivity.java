package com.lawyee.apppublic.ui.org;

import android.os.Bundle;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.ui.BaseActivity;

public class SearchOrgActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_org);
    }

    @Override
    protected void initContentView(Bundle savedInstanceState) {

    }

}
