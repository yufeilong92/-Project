package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.MyEntrustDetailAdpater;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.JalawLawyerEntrustDetailVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

import static com.lawyee.apppublic.ui.personalcenter.lawyer.LawyerEntrustReplyActivity.ENTRUSTREPLY;

/**
 * All rights Reserved, Designed By www.lawyee.com
 * @Title:  标题
 * @Package com.lawyee.apppublic.ui.personalcenter.lawyer
 * @Description:    律师端-我的委托详情
 * @author:lzh
 * @date:   2017/8/9
 * @version
 * @verdescript   2017/8/9  lzh 初建
 * @Copyright: 2017/8/9 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LawyerEntrustDetailActivity extends BaseActivity {
    public final static String LAWENTRUSTDETAIL="EntrustDetail";//跳转进入LawyerEntrustDetailActivity的标识

    private JalawLawyerEntrustDetailVO mJalawLawyerEntrustDetailVO;// 律师委托详情VO
    private MyEntrustDetailAdpater mAdpater;
    private String  mOid;
    private RecyclerView rv_entrust_detail;
    private Context mContext;
    private TextView mTvReply;
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lawyer_entrust_detail);
        mContext=this;
        mOid= (String) getIntent().getSerializableExtra(LAWENTRUSTDETAIL);
        if(mOid==null||mOid.equals("")){
            finish();
        }
        rv_entrust_detail= (RecyclerView) findViewById(R.id.rv_entrust_detail);
        mTvReply= (TextView) findViewById(R.id.tv_reply);

    }

    public void onToolbarClick(View view){
        if(mJalawLawyerEntrustDetailVO!=null) {
            Intent intent = new Intent(mContext, LawyerEntrustReplyActivity.class);
            intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.entrust_reply1));
            intent.putExtra(ENTRUSTREPLY, mJalawLawyerEntrustDetailVO.getOid());
            mContext.startActivity(intent);
        }
    }

    @Override
    protected void onResume() {
        loadData();
        super.onResume();
    }

    private void loadData() {
        if(getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(this);
        service.setProgressShowContent(mContext.getString(R.string.get_ing));
        service.setShowProgress(true);
        service.getEntrustDetail(mOid,  new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);
                if(values==null||values.isEmpty()||!(values.get(0) instanceof JalawLawyerEntrustDetailVO))
                {
                    T.showLong(mContext,getString(R.string.get_error_noeffectdata));
                    return;
                }
                mJalawLawyerEntrustDetailVO  = (JalawLawyerEntrustDetailVO)values.get(0);
               if(mJalawLawyerEntrustDetailVO.getEntrutStatus()==1){
                     mTvReply.setVisibility(View.INVISIBLE);
                }
                GridLayoutManager gridLayoutManager=new GridLayoutManager(mContext,1);
                rv_entrust_detail.setLayoutManager(gridLayoutManager);
                if(mJalawLawyerEntrustDetailVO.isEvaluateStatus()){
                    mAdpater=new MyEntrustDetailAdpater(mContext,mJalawLawyerEntrustDetailVO,3);
                }else {
                    mAdpater=new MyEntrustDetailAdpater(mContext,mJalawLawyerEntrustDetailVO,2);
                }

                rv_entrust_detail.setAdapter(mAdpater);
            }

            @Override
            public void onError(String msg, String content) {
                T.showLong(mContext,msg);
                setInProgess(false);
            }
        });
    }

}
