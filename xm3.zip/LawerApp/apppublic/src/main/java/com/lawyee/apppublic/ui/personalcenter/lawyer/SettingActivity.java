package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.JalawUserService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.util.BaseCommonToStringUtil;
import com.lawyee.apppublic.util.TextViewUtil;
import com.lawyee.apppublic.util.UrlUtil;
import com.lawyee.apppublic.vo.UserVO;
import com.nostra13.universalimageloader.core.ImageLoader;

import net.lawyee.mobilelib.utils.L;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

import am.widget.wraplayout.WrapLayout;
import me.nereo.multi_image_selector.MultiImageSelectorActivity;

import static com.lawyee.apppublic.ui.lawyerService.SessionActivity.IMAGE_PICKER;
import static com.lawyee.apppublic.vo.UserVO.CSTR_USERROLE_BASICLAWWORKER;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @Title: 标题
 * @Package com.lawyee.apppublic.ui.personalcenter.lawyer
 * @Description: 律师端-个人信息
 * @author:lzh
 * @date: 2017/8/9
 * @verdescript 2017/8/9  lzh 初建
 * @Copyright: 2017/8/9 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class SettingActivity extends BaseActivity {


    private TextView mTvSave;
    private ImageView mIvHead;
    private RelativeLayout mRlHead;
    private TextView mTvName;
    private TextView mTvSex;
    private TextView mTvPhone;
    private TextView mTvLawfirm;
    private Context mContext;
    private TextView mTvEnter;
    private WrapLayout mWly_lyt_warp;

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_setting);
        mContext = this;
        initView();
        initData();

    }

    @Override
    protected void onResume() {
        validLawyerToTeam();
        super.onResume();


    }

    private void initData() {
        UserVO userVO = ApplicationSet.getInstance().getUserVO();
        TextViewUtil.isEmpty(mTvName, userVO.getRealName());
        TextViewUtil.isEmpty(mTvPhone, userVO.getMobile());
        TextViewUtil.isEmpty(mTvSex, BaseCommonToStringUtil.toString(userVO.getGender()));
        TextViewUtil.isEmpty(mTvLawfirm, userVO.getOrgName());
        String imageUrl = userVO.getPhoto();

        if (!TextUtils.isEmpty(imageUrl)) {
            ImageLoader.getInstance().displayImage(UrlUtil.getImageFileUrl(mContext, imageUrl), mIvHead, ApplicationSet.CDIO_LAW);
        } else {
            mIvHead.setImageResource(R.drawable.ic_default_avatar);
        }
        if (userVO.getBusiness() != null && userVO.getBusiness().size() > 0) {
            for(int i=0;i<userVO.getBusiness().size();i++){
                TextView textView = (TextView) getLayoutInflater().inflate(R.layout.layout_law_serivce_tv, null);
                textView.setText(BaseCommonToStringUtil.toString(userVO.getBusiness().get(i).getBusiness()));
                textView.measure(0, 0);
                mWly_lyt_warp.addView(textView);
            }
        }
    }

    private void initView() {
        mTvSave = (TextView) findViewById(R.id.tv_save);
        mIvHead = (ImageView) findViewById(R.id.iv_head);
        mRlHead = (RelativeLayout) findViewById(R.id.rl_head);
        mTvName = (TextView) findViewById(R.id.tv_name);
        mTvSex = (TextView) findViewById(R.id.tv_sex);
        mTvPhone = (TextView) findViewById(R.id.tv_phone);
        mTvLawfirm = (TextView) findViewById(R.id.tv_lawfirm);
        mWly_lyt_warp= (WrapLayout) findViewById(R.id.wly_lyt_warp);
        mTvEnter= (TextView) findViewById(R.id.tv_enter);
        mTvSave.setVisibility(View.INVISIBLE);

        mIvHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(mContext, MultiImageSelectorActivity.class);
//                intent.putExtra(MultiImageSelectorActivity.EXTRA_SHOW_CAMERA, true);
//                intent.putExtra(MultiImageSelectorActivity.EXTRA_SELECT_COUNT, 1);
//                intent.putExtra(MultiImageSelectorActivity.EXTRA_SELECT_MODE, MultiImageSelectorActivity.MODE_SINGLE);
//                startActivityForResult(intent, IMAGE_PICKER);
            }
        });
        mTvEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(mContext,LawProtocolActivity.class);
                intent.putExtra(CSTR_EXTRA_TITLE_STR,getString(R.string.enter_team));
                    startActivity(intent);
            }
        });


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case IMAGE_PICKER://图片回调
                if (data == null || data.getStringArrayListExtra(MultiImageSelectorActivity.EXTRA_RESULT) == null) {
                    return;
                }
                ArrayList<String> path = data.getStringArrayListExtra(MultiImageSelectorActivity.EXTRA_RESULT);
                if (path != null || path.size() > 0) {
                    //是否发送原图
                    for (String name : path
                            ) {
                        //   sendImagesMsg(name,false);
                        ImageLoader loader = ImageLoader.getInstance();
                        loader.displayImage(Uri.parse("file://" + name).toString(), mIvHead);
                    }
                }
                break;
        }
    }
    private void validLawyerToTeam() {
        if(getInProgess())
            return;
        setInProgess(true);
        JalawUserService service = new JalawUserService(mContext);
        service.validLawyerToTeam( new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                setInProgess(false);

                if(values==null||values.isEmpty()||!(values.get(0) instanceof UserVO))
                {
                    T.showLong(mContext,getString(R.string.login_error_noeffectdata));

                    return;
                }
                UserVO userVO = (UserVO)values.get(0);
                userVO.setPassword( ApplicationSet.getInstance().getUserVO().getPassword());
                userVO.setRememblePwd( ApplicationSet.getInstance().getUserVO().isRememblePwd());
                ApplicationSet.getInstance().setUserVO(userVO, true);
                refreshView();

            }

            @Override
            public void onError(String msg, String content) {
                L.v(TAG, "UserLogin onError:" + content);
                T.showLong(mContext, msg);
                setInProgess(false);
            }
        });
    }

  private  void refreshView(){
      initData();
      if(ApplicationSet.getInstance().getUserVO().getRole()==null){
          mTvEnter.setVisibility(View.GONE);
         return;
      }
      if(ApplicationSet.getInstance().getUserVO().getRole().equals(CSTR_USERROLE_BASICLAWWORKER)){
          mTvEnter.setVisibility(View.GONE);
      }else if(ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag()!=null){
          if(ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("0")){
              mTvEnter.setText(R.string.checking);
              mTvEnter.setClickable(false);
              mTvEnter.setBackgroundResource(R.drawable.shape_patrol_corners_gray);
              mTvEnter.setTextColor(ContextCompat.getColor(mContext,R.color.color_hei));
          }else if(ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("-1")){
              mTvEnter.setText(R.string.click_apply);
              mTvEnter.setClickable(true);
              mTvEnter.setBackgroundResource(R.drawable.shape_patrol_corners_blue);
              mTvEnter.setTextColor(ContextCompat.getColor(mContext,R.color.white));
          }else{
              mTvEnter.setVisibility(View.GONE);
          }
      }
  }
}
