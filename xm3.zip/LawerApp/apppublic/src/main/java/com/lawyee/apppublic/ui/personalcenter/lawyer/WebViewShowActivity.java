package com.lawyee.apppublic.ui.personalcenter.lawyer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.config.ApplicationSet;
import com.lawyee.apppublic.config.Constants;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.util.ImagePathUtil;
import com.lawyee.apppublic.util.SessionIdUtil;
import com.lawyee.apppublic.util.net.LightningDownloadListener;
import com.nostra13.universalimageloader.utils.L;

import net.lawyee.mobilelib.utils.PhoneInfoUtil;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @Title: 标题
 * @Package com.lawyee.apppublic.ui.personalcenter.lawyer
 * @Description: 用于展示微信链接的页面
 * @author:uustrong
 * @date: 2017/10/14
 * @verdescript 2017/10/14  uustrong 初建
 * @Copyright: 2017/10/14 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class WebViewShowActivity extends BaseActivity {

    /**
     * 传入参数-传入类型
     */
    public static final String CSTR_TYPE = "type";
    /**
     * 输入Url
     */
    public static final String CSTR_URL = "url";
    public static final String LAWHOMEPAGE="a7c51b0b4357410e81843744aeb7397c";
    public static final String EDITPAGE1="88199edc5b374b93bce49ab79da00d57";
    public static final String EDITPAGE2="69a91277aace41c39a2eb857fc3cb913";
    public static final String EDITPAGE3="6db1299e8d9c457795a45dd2e77cff6b";
    private WebView mWvContent;

    private Context mContext;
    /**
     * 4.获取获取律师详情接口URL
     */
    private int mType;
    private String mUrl;
    private TextView mTvEdit;
    private ProgressBar mpb_content_loading;
//    private Map<String,String> mExtraHeaders;
  private String mFinsishUrl="";
    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_web_view_show);
        mContext = this;
        mType = getIntent().getIntExtra(CSTR_TYPE, 0);
        mUrl=getIntent().getStringExtra(CSTR_URL);
        initView();
    }

    private void initView() {
        mWvContent = (WebView) findViewById(R.id.wv_content);
        mTvEdit= (TextView) findViewById(R.id.tv_edit);
        mpb_content_loading = (ProgressBar) findViewById(R.id.newsdetail_content_loading_pb);
        if(mType==4&&ApplicationSet.getInstance().getUserVO().getLawyerTeamFlag().equals("1")){
            mTvEdit.setVisibility(View.VISIBLE);
        }else{
            mTvEdit.setVisibility(View.INVISIBLE);
        }

//        mExtraHeaders= new HashMap<String, String>();
//        mExtraHeaders.put("devid", PhoneInfoUtil.GetIMEI(mContext));
//        mExtraHeaders.put("User-Agent", PhoneInfoUtil.GetIMEI(mContext));
        WebSettings settings = mWvContent.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAppCacheMaxSize(1024*1024*8);
        String appCachePath = getApplicationContext().getCacheDir().getAbsolutePath();
        settings.setAppCachePath(appCachePath);
        settings.setAllowFileAccess(true);
        settings.setAppCacheEnabled(true);
        settings.setUserAgentString(Constants.CSTR_DEVTYPE+"_"+getDevID());//用于传递设备ID给服务器用于区分设备
        mWvContent.setWebChromeClient(mWebChromeClient);
        mWvContent.setDownloadListener(new LightningDownloadListener(this));
        mWvContent.setWebViewClient(new MyWebViewClient3());
        //点击后退按钮,让WebView后退一页(也可以覆写Activity的onKeyDown方法)
        mWvContent.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK && mWvContent.canGoBack()) {  //表示按返回键
                        if(!mWvContent.canGoBack()||mFinsishUrl.contains(LAWHOMEPAGE)||mFinsishUrl.contains(EDITPAGE1)||mFinsishUrl.contains(EDITPAGE2)){
                            finish();
                        }else{
                            mWvContent.goBack();   //后退
                        }
                        return true;    //已处理
                    }
                }
                return false;
            }
        });
        mWvContent.loadUrl(mUrl);
        mpb_content_loading.setVisibility(View.VISIBLE);
        mWvContent.setVisibility(View.GONE);
        Log.e("czq", mUrl);
    }

    public void onToolbarClick(View view){
        Intent intent = new Intent(mContext, WebViewShowActivity.class);
        intent.putExtra(CSTR_EXTRA_TITLE_STR, mContext.getString(R.string.personal_homepage));
        String url =getString(R.string.url_base) + getString(R.string.url_revised_law_detail) + SessionIdUtil.getUserSessionId(mContext) +
                getString(R.string.url_appstamp) + SessionIdUtil.getAppstamp(mContext);
        intent.putExtra(CSTR_URL, url);
        startActivity(intent);
    }

    /**
     * 自定义WebView类，重载shouldOverrideUrlLoading，改变打开方式
     */
    private class MyWebViewClient3 extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            mFinsishUrl=url;
            mpb_content_loading.setVisibility(View.GONE);
            mWvContent.setVisibility(View.VISIBLE);
        }
    }

    public void onHomeClick(View v) {
        if(!mWvContent.canGoBack()||
                mFinsishUrl.contains(LAWHOMEPAGE)||
                mFinsishUrl.contains(EDITPAGE1)||
                mFinsishUrl.contains(EDITPAGE2)||
                mFinsishUrl.contains(EDITPAGE3)){
            this.finish();
        }else{

            mWvContent.goBack();   //后退
        }

    }



    public static final int INPUT_FILE_REQUEST_CODE = 1;
    private ValueCallback<Uri> mUploadMessage;
    private final static int FILECHOOSER_RESULTCODE = 2;
    private ValueCallback<Uri[]> mFilePathCallback;

    private String mCameraPhotoPath;

    //在sdcard卡创建缩略图
    //createImageFileInSdcard
    @SuppressLint("SdCardPath")
    private File createImageFile() {
        //mCameraPhotoPath="/mnt/sdcard/tmp.png";
        File file=new File(Environment.getExternalStorageDirectory()+"/","tmp.png");
        mCameraPhotoPath=file.getAbsolutePath();
        if(!file.exists())
        {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return file;
    }

    private WebChromeClient mWebChromeClient = new WebChromeClient() {
        // android 5.0 这里需要使用android5.0 sdk
        public boolean onShowFileChooser(
                WebView webView, final ValueCallback<Uri[]> filePathCallback,
                WebChromeClient.FileChooserParams fileChooserParams) {

            Log.d(TAG, "onShowFileChooser");
            if (mFilePathCallback != null) {
                mFilePathCallback.onReceiveValue(null);
            }

            String[] perms = {Manifest.permission.CAMERA};
            performCodeWithPermission(getString(R.string.rationale_camera), RC_STORAGE_PERM, perms, new PermissionCallback() {
                @Override
                public void hasPermission(List<String> allPerms) {
                    mFilePathCallback = filePathCallback;

                    /**
                     Open Declaration   String android.provider.MediaStore.ACTION_IMAGE_CAPTURE = "android.media.action.IMAGE_CAPTURE"
                     Standard Intent action that can be sent to have the camera application capture an image and return it.
                     The caller may pass an extra EXTRA_OUTPUT to control where this image will be written. If the EXTRA_OUTPUT is not present, then a small sized image is returned as a Bitmap object in the extra field. This is useful for applications that only need a small image. If the EXTRA_OUTPUT is present, then the full-sized image will be written to the Uri value of EXTRA_OUTPUT. As of android.os.Build.VERSION_CODES.LOLLIPOP, this uri can also be supplied through android.content.Intent.setClipData(ClipData). If using this approach, you still must supply the uri through the EXTRA_OUTPUT field for compatibility with old applications. If you don't set a ClipData, it will be copied there for you when calling Context.startActivity(Intent).
                     See Also:EXTRA_OUTPUT
                     标准意图，被发送到相机应用程序捕获一个图像，并返回它。通过一个额外的extra_output控制这个图像将被写入。如果extra_output是不存在的，
                     那么一个小尺寸的图像作为位图对象返回。如果extra_output是存在的，那么全尺寸的图像将被写入extra_output URI值。
                     */
                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        // Create the File where the photo should go
                        File photoFile = null;
                        try {
                            //设置MediaStore.EXTRA_OUTPUT路径,相机拍照写入的全路径
                            photoFile = createImageFile();
                            takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath);
                        } catch (Exception ex) {
                            // Error occurred while creating the File
                            L.e("WebViewSetting", "Unable to create Image File", ex);
                        }

                        // Continue only if the File was successfully created
                        if (photoFile != null) {
                            mCameraPhotoPath = "file:" + photoFile.getAbsolutePath();
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                                    Uri.fromFile(photoFile));
                            L.d(mCameraPhotoPath);
                        } else {
                            takePictureIntent = null;
                        }
                    }

                    Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                    contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                    contentSelectionIntent.setType("image/*");
                    Intent[] intentArray;
                    if (takePictureIntent != null) {
                        intentArray = new Intent[]{takePictureIntent};
                    } else {
                        intentArray = new Intent[0];
                    }

                    Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                    chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                    chooserIntent.putExtra(Intent.EXTRA_TITLE, "图片选择");
                    chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

                    startActivityForResult(chooserIntent, INPUT_FILE_REQUEST_CODE);
                }

                @Override
                public void noPermission(List<String> deniedPerms, List<String> grantedPerms, Boolean hasPermanentlyDenied) {
                    if (hasPermanentlyDenied) {
                        alertAppSetPermission(getString(R.string.rationale_ask_again), RC_SETTINGS_SCREEN);
                    }
                }
            });

            return true;
        }



        //The undocumented magic method override
        //Eclipse will swear at you if you try to put @Override here
        // For Android 3.0+
        public void openFileChooser(ValueCallback<Uri> uploadMsg) {
            Log.d(TAG, "openFileChooser1");

            mUploadMessage = uploadMsg;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            WebViewShowActivity.this.startActivityForResult(Intent.createChooser(i, "Image Chooser"), FILECHOOSER_RESULTCODE);

        }

        // For Android 3.0+
        public void openFileChooser(ValueCallback uploadMsg, String acceptType) {
            Log.d(TAG, "openFileChooser2");
            mUploadMessage = uploadMsg;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            WebViewShowActivity.this.startActivityForResult(
                    Intent.createChooser(i, "图片选择"),
                    FILECHOOSER_RESULTCODE);
        }

        //For Android 4.1
        public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
            Log.d(TAG, "openFileChooser3");

            mUploadMessage = uploadMsg;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            WebViewShowActivity.this.startActivityForResult(Intent.createChooser(i, "图片选择"), WebViewShowActivity.FILECHOOSER_RESULTCODE);

        }
    };

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult");

        if (requestCode == FILECHOOSER_RESULTCODE) {
            if (null == mUploadMessage) return;
            Uri result = data == null || resultCode != RESULT_OK ? null
                    : data.getData();
            if (result != null) {
                String imagePath = ImagePathUtil.getPath(this, result);
                if (!TextUtils.isEmpty(imagePath)) {
                    result = Uri.parse("file:///" + imagePath);
                }
            }
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        } else if (requestCode == INPUT_FILE_REQUEST_CODE && mFilePathCallback != null) {
            // 5.0的回调
            Uri[] results = null;

            // Check that the response is a good one
            if (resultCode == Activity.RESULT_OK) {
                if (data == null||data.getDataString()==null) {
                    // If there is not data, then we may have taken a photo
                    if (mCameraPhotoPath != null) {
                        L.d("camera_photo_path", mCameraPhotoPath);
                        results = new Uri[]{Uri.parse(mCameraPhotoPath)};
                    }
                } else {
                    String dataString = data.getDataString();
                    L.d("camera_dataString", dataString);
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
            }

            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
    }
    protected  String getDevID() {
        return PhoneInfoUtil.GetIMEI(mContext);
    }
}
