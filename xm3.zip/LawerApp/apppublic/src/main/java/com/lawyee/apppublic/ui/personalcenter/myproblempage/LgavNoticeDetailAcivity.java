package com.lawyee.apppublic.ui.personalcenter.myproblempage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavNoticeService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.ui.ViewImageActivity;
import com.lawyee.apppublic.util.NoticeHtmlParser;
import com.lawyee.apppublic.util.WebViewUtil;
import com.lawyee.apppublic.util.net.DownloadWebImgTask;
import com.lawyee.apppublic.vo.LgavNoticeDetailVO;

import net.lawyee.mobilelib.utils.HtmlParser;
import net.lawyee.mobilelib.utils.ImageUtil;
import net.lawyee.mobilelib.utils.StringUtil;
import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;
import java.util.List;

public class LgavNoticeDetailAcivity extends BaseActivity {

    private LinearLayout mLinearLayout;
    private WebView mWvDetailContent;
    private ProgressBar mPgbDetailContentLoading;
    private Context mContext;
    private int mScreenHeight;
    /**
     * 通知公告oid
     */
    public static final String NOTICEOID = "NOTICEOID";
    private String mNoticeOid;
    private TextView mTvEmptyContent;
    private LgavNoticeDetailVO mDetailvo;
    private NoticeHtmlParser mParser;

    public static void onNewIntent(Context context, String oid) {
        Intent intent = new Intent(context, LgavNoticeDetailAcivity.class);
        intent.putExtra(NOTICEOID, oid);
        context.startActivity(intent);
    }

    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_lgav_notice_detail_acivity);
        Intent intent = getIntent();
        mNoticeOid = intent.getStringExtra(NOTICEOID);
        initView();
        requestNoticeData();

    }

    private void requestNoticeData() {
        LgavNoticeService noticeService = new LgavNoticeService(mContext);
        noticeService.queryLgavNoticeDetail(1, mNoticeOid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, R.string.prompt_network_receiving_data_error);
                    return;
                }
                mDetailvo = (LgavNoticeDetailVO) values.get(0);
                if (mDetailvo == null) {
                    mTvEmptyContent.setVisibility(View.VISIBLE);
                    mWvDetailContent.setVisibility(View.GONE);
                    mPgbDetailContentLoading.setVisibility(View.GONE);
                }
                initDataView();
                loadData();
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });

    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initDataView() {
        WebSettings webSettings = mWvDetailContent.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        mWvDetailContent.addJavascriptInterface(mContext, HtmlParser.Js2JavaInterfaceName);
        mWvDetailContent.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                mPgbDetailContentLoading.setVisibility(View.GONE);
                mWvDetailContent.setVisibility(View.VISIBLE);
                mTvEmptyContent.setVisibility(View.GONE);
                if (mParser != null) {
                    List<String> urls = mParser.getImgUrls();
                    if (urls == null || urls.isEmpty())
                        return;
                    DownloadWebImgTask downloadWebImgTask = new DownloadWebImgTask(
                            LgavNoticeDetailAcivity.this, mWvDetailContent
                            , false);

                    String[] urlStringArray = new String[urls.size() + 1];
                    urls.toArray(urlStringArray);
                    downloadWebImgTask.execute(urlStringArray);
                }

            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (WebViewUtil.isreloadlink(url)) {
                    loadData();
                    return true;
                }
                WebViewUtil.ProcessSiteLink(LgavNoticeDetailAcivity.this, url);
                return true;
            }
        });
    }
    /**
     * 显示图片（JavascriptInterface）
     *
     * @param url
     */
    @JavascriptInterface
    public void showImage(String url) {
        // 显示图片(需要判断是否已经有本地图片，如果没有则要进行加载)
        if (StringUtil.isEmpty(url))
            return;
        if (mParser != null && !ImageUtil.hasLocalFile(LgavNoticeDetailAcivity.this,url)) {
            // 未加载图时，加载图
            DownloadWebImgTask downloadTask = new DownloadWebImgTask(
                    LgavNoticeDetailAcivity.this, mWvDetailContent, true);
            String urlStrArray[] = { url };
            downloadTask.execute(urlStrArray);
            return;
        }
        Intent intent = new Intent(LgavNoticeDetailAcivity.this,
                ViewImageActivity.class);
        intent.putExtra(ViewImageActivity.CSTR_EXTRA_IMAGE_STR, url);
        startActivity(intent);
    }

    private void loadData() {
        mPgbDetailContentLoading.setVisibility(View.VISIBLE);
        mTvEmptyContent.setVisibility(View.GONE);
        mWvDetailContent.setVisibility(View.GONE);
        mParser = new NoticeHtmlParser(mWvDetailContent, mContext, mDetailvo, mScreenHeight);
        mParser.startHandle();
    }

    private void initView() {
        mContext = LgavNoticeDetailAcivity.this;
        mLinearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        mWvDetailContent = (WebView) findViewById(R.id.wv_detail_content);
        mPgbDetailContentLoading = (ProgressBar) findViewById(R.id.pgb_detail_content_loading);
        mTvEmptyContent = (TextView) findViewById(R.id.tv_empty_content);
    }
}
