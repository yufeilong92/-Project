package com.lawyee.apppublic.ui.personalcenter.myproblempage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.adapter.MyProblemDetailAdapter;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavProblemService;
import com.lawyee.apppublic.ui.BaseActivity;
import com.lawyee.apppublic.vo.LgavConsultDetailVO;

import net.lawyee.mobilelib.utils.T;

import java.util.ArrayList;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: MyProblemDetailActivity.java
 * @Package com.lawyee.apppublic.ui.personalcenter.myhomepage
 * @Description: 我的问题详情
 * @author: YFL
 * @date: 2017/9/28 15:44
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017/9/28 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class MyProblemDetailActivity extends BaseActivity {

    private RecyclerView mRlvMyproDetailView;
    private Context mContext;
    private TextView mXrv_mypro_empty_detail;
    /**
     * 咨询oid
     */
    public static final String PROBLEMOID = "porblemoid";
    /**
     * 资讯角色类型
     */
    private static final String ROLECASE = "rolecase";
    /**
     * 模块标示
     */
    private static final String MARK = "mark";
    /**
     * id
     */
    private static final String MOBJECTI="objecti";
    private String mOid;
    private MyProblemDetailAdapter mProblemAdapter;
    private Object mDataObj;
    /**
     * 角色
     */
    private String mRoleCase;
    /**
     * 已经解答过了
     */
    public static final String ANSWERFLAG = "2";


    /**
     * @param context 上下文
     * @param oid     咨询oid
     */
    public static void newInstance(Context context, String oid) {
        Intent intent = new Intent(context, MyProblemDetailActivity.class);
        intent.putExtra(PROBLEMOID, oid);
        context.startActivity(intent);
    }


    @Override
    protected void initContentView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_my_problem_detail);
        Intent intent = getIntent();
        mOid = intent.getStringExtra(PROBLEMOID);
        mRoleCase = intent.getStringExtra(ROLECASE);
        initView();
        loadData();
    }

    private void loadData() {
        //请求网络
        requestService(true);
    }

    /***
     * 请求网络获取数据
     */
    public void requestService(boolean isfirst) {
        LgavProblemService problemService = new LgavProblemService(mContext);
        problemService.setShowProgress(isfirst);
        problemService.setProgressShowContent(getResources().getString(R.string.get_ing));
        problemService.queryLgavGetConsultDetail(mOid, new BaseJsonService.IResultInfoListener() {
            @Override
            public void onComplete(ArrayList<Object> values, String content) {
                if (values == null || values.isEmpty()) {
                    T.showShort(mContext, R.string.prompt_network_receiving_data_error);
                    return;
                }
                LgavConsultDetailVO detailVO = (LgavConsultDetailVO) values.get(0);
                if (detailVO == null) {
                    mRlvMyproDetailView.setVisibility(View.GONE);
                    mXrv_mypro_empty_detail.setVisibility(View.VISIBLE);
                } else {
                    mRlvMyproDetailView.setVisibility(View.VISIBLE);
                    mXrv_mypro_empty_detail.setVisibility(View.GONE);
                    mDataObj = detailVO;
                }
                setAdapterData();
                mProblemAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String msg, String content) {
                T.showShort(mContext, msg);
            }
        });


    }

    //绑定数据
    private void setAdapterData() {
        mProblemAdapter = new MyProblemDetailAdapter(mContext, mDataObj,this);
        GridLayoutManager layoutManager = new GridLayoutManager(mContext, 1);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        mRlvMyproDetailView.setLayoutManager(layoutManager);
        mRlvMyproDetailView.setAdapter(mProblemAdapter);
    }

    private void initView() {
        mContext = this;
        mRlvMyproDetailView = (RecyclerView) findViewById(R.id.rlv_myprodetail_view);
        mXrv_mypro_empty_detail = (TextView) findViewById(R.id.xrv_mypro_empty_detail);
    }

}
