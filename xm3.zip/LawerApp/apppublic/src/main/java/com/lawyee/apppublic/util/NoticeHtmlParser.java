package com.lawyee.apppublic.util;

import android.content.Context;
import android.webkit.WebView;

import com.lawyee.apppublic.R;
import com.lawyee.apppublic.dal.BaseJsonService;
import com.lawyee.apppublic.dal.LgavNoticeService;
import com.lawyee.apppublic.vo.LgavNoticeDetailVO;

import net.lawyee.mobilelib.utils.FileUtil;
import net.lawyee.mobilelib.utils.HtmlParser;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

/**
 * 资讯详情处理
 *
 * @author wuzhu
 * @note 初始化后调用startHandle获取数据
 */
public class NoticeHtmlParser extends HtmlParser {
    private LgavNoticeDetailVO mDataVO;

    private NoticeHtmlParser(WebView wevView, Context context, String htmltext,
                             int screenwidth) {
        super(wevView, context, htmltext, false, screenwidth);

    }

    public NoticeHtmlParser(WebView webView, Context context, LgavNoticeDetailVO datavo,
                            int screenwidth) {
        this(webView, context, "", screenwidth);
        mDataVO = datavo;
        // 不要读取缓存
//        String cachehtml = FileUtil.readContent(mDataVO.getDataFileName(context));
        setHandledHtmltext(null);
    }

    public void startHandle() {
        // 如果已经有已经处理过的内容
        if (isHandledContent()) {
            execute((Void) null);
            return;
        }
        // 如果已经是详情，则直接处理
        if (mDataVO!=null&&mDataVO instanceof LgavNoticeDetailVO) {
            setNoHandledHtmltext(((LgavNoticeDetailVO) mDataVO).getContent());
            execute((Void) null);
            return;
        }
        // 未处理，则要调用处理
        LgavNoticeService service = new LgavNoticeService(getContext());
        service.queryLgavNoticeDetail(1, mDataVO.getOid(), new BaseJsonService.IResultInfoListener() {

            @Override
            public void onError(String msg, String content) {
                setHandledHtmltext(setErrorInfo(msg));
                execute((Void) null);
            }

            @Override
            public void onComplete(ArrayList<Object> values,
                                   String content) {
                if (values == null || values.isEmpty()) {
                    setHandledHtmltext(setErrorInfo("无效的数据内容"));
                    execute((Void) null);
                    return;
                }
                Object o = values.get(0);
                if (!(o instanceof LgavNoticeDetailVO)) {
                    setHandledHtmltext(setErrorInfo("无效的数据内容"));
                    execute((Void) null);
                    return;
                }
                mDataVO = (LgavNoticeDetailVO) o;
                setNoHandledHtmltext(((LgavNoticeDetailVO) mDataVO)
                        .getContent());
                execute((Void) null);
            }
        });
    }

    public LgavNoticeDetailVO getDataVO() {
        return mDataVO;
    }

    public void setDataVO(LgavNoticeDetailVO dataVO) {
        this.mDataVO = dataVO;
    }

    /**
     * 显示错误信息
     *
     * @param msg
     */
    private String setErrorInfo(String msg) {
        return WebViewUtil.getHtmlHead() + mDataVO.getHtmlTitle()
                + mDataVO.getHtmlSubTitle()
                + WebViewUtil.getHtmlErrorHit(msg, true)
                + WebViewUtil.getHtmlEnd();
    }

    /**
     * 显示新闻信息
     */
    private String setNewsInfo(String content) {
        return WebViewUtil.getHtmlHead() + mDataVO.getHtmlTitle()
                + mDataVO.getHtmlSubTitle() + content
                + WebViewUtil.getHtmlEnd();
    }

    @Override
    protected Element handleDocument(Document doc) {
        if (doc == null) {
            return null;
        }
        Elements es = doc.getElementsByTag("a");
        /*
		 * for (Element e : es) { if (e.getElementsByTag("img") != null)//
		 * 包含图片的链接时 { e.removeAttr("href"); } }
		 */
        for (Element e : es) {
            Elements imges = e.getElementsByTag("img");
            if (imges != null && imges.size() > 0)// 包含图片的链接时
            {
                e.removeAttr("href");
            }
        }
        return doc;
    }

    @Override
    protected String getDocument(Element e) {
        if (e == null) {
            return setErrorInfo(getContext().getResources().getString(
                    R.string.newsdetail_news_content_geterror));
        }
        String content = e.html().replace("<html>\n" +
                " <head></head>\n" +
                " <body>", "").replace(" </body>\n" +
                "</html>", "");
        String html = setNewsInfo(content);
        // 缓存
        FileUtil.saveContent(mDataVO.getDataFileName(getContext()), html);
        return html;
    }

}
