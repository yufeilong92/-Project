package com.lawyee.apppublic.vo;

import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.vo
 * @Description: ${todo}(用一句话描述该文件做什么)
 * @author: uustrong
 * @date: 2018/1/11 10:56
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class JaUpdateVO extends BaseVO {
    /**
     * "服务器最新版本号,返回成功时必填字段。如果请求的版本号与服务端最新版本号一致时，则以下版本信息相关字段可以不返回".
     */
    private String   sversion;
    /**
     * "更新类型，0: 可忽略版本升级(默认),1：建议升级，2强制升级".
     */
    private String  updtype;
    /**
     * ""文件更新地址,android为apk地址，ios为plist文件地址",
     */
    private String  fileurl;
    /**
     * "新安装包文件大小描述，如3.6M",
     */
    private String filesize;
    /**
     更新信息描述，可多行，换行符使用
     */
    private String updinfo;

    public String getSversion() {
        return sversion;
    }

    public void setSversion(String sversion) {
        this.sversion = sversion;
    }

    public String getUpdtype() {
        return updtype;
    }

    public void setUpdtype(String updtype) {
        this.updtype = updtype;
    }

    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl;
    }

    public String getFilesize() {
        return filesize;
    }

    public void setFilesize(String filesize) {
        this.filesize = filesize;
    }

    public String getUpdinfo() {
        return updinfo;
    }

    public void setUpdinfo(String updinfo) {
        this.updinfo = updinfo;
    }
}
