package com.lawyee.apppublic.vo;

import android.content.Context;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 我的活动详情
 * @author: YFL
 * @date: 2017/10/12 14:38
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavActivityDetailVO extends LgavActivityVO {
    private static final long serialVersionUID = 7911646726576352427L;
    /**
     *负责人
     */
    private String charge;
    /**
     *活动形式",
     */
    private String way ;
    /**
     *参与人",
     */
    private String participant ;
    /**
     *主办单位",
     */
    private String sponsor ;

    /**
     *参与单位",
     */
    private String cosponsor;
    /**
     * 省
     */
    private String province;
    /**
     * 省名称
     */
    private String provinceName ;
    /**
     * 市
     */
    private String city;
    /**
     *市名称
     */
    private String cityName ;
    /**
     * 区县
     */
    private String county ;
    /**
     *区县名称"
     */
    private String countyName  ;
    /**
     *活动地点"
     */
    private String address ;
    /**
     *"活动详情",
     */
    private String introduction ;
    /**
     *备注"
     */
    private String remarks ;
    /**
     * 活动开始时间",
     */
    private String activityStartTime;
    /**
     * 活动结束时间"
     */
    private String activityEndTime ;

    public String getActivityStartTime() {
        return activityStartTime;
    }

    public void setActivityStartTime(String activityStartTime) {
        this.activityStartTime = activityStartTime;
    }

    public String getActivityEndTime() {
        return activityEndTime;
    }

    public void setActivityEndTime(String activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getWay() {
        return way;
    }

    public String getCosponsor() {
        return cosponsor;
    }

    public void setCosponsor(String cosponsor) {
        this.cosponsor = cosponsor;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getParticipant() {
        return participant;
    }

    public void setParticipant(String participant) {
        this.participant = participant;
    }

    public String getSponsor() {
        return sponsor;
    }

    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public static String dataFile(Context context) {
        return dataListFileName(context, serialVersionUID);
    }
}
