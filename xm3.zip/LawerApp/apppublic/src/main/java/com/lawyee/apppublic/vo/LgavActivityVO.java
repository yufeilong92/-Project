package com.lawyee.apppublic.vo;

import android.content.Context;

import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V 1.0 xxxxxxxx
 * @Title: LawerApp
 * @Package com.lawyee.apppublic.vo
 * @Description: 我的活动
 * @author: YFL
 * @date: 2017/10/12 14:33
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: 2017 www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */
public class LgavActivityVO extends BaseVO {
    private static final long serialVersionUID = 309940389839805298L;

    /**
     *活动标题",
     */
    private String title;
    /**
     *发布时间，yyyy-MM-dd"
     */
    private String publishDatetime;
//    /**
//     *发布时间，yyyy-MM-dd"
//     */
//    private String isRead;

    public static String dataFile(Context context) {
        return dataFileName(context, serialVersionUID);
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublishDatetime() {
        return publishDatetime;
    }

    public void setPublishDatetime(String publishDatetime) {
        this.publishDatetime = publishDatetime;
    }
/*
    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }*/
}
