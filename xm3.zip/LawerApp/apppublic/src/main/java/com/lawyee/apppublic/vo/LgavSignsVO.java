package com.lawyee.apppublic.vo;

import net.lawyee.mobilelib.vo.BaseVO;

import java.util.List;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.vo
 * @Description: 律师签到数据
 * @author: uustrong
 * @date: 2017/10/12 14:01
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class LgavSignsVO extends BaseVO{
    private static final long serialVersionUID = -5633510582519040987L;
    /**
     * 签到总数
     */
    	private String totalSign;

    /**
     * 具体签到列表
     */
    private List<LgavSignDateVO> signDates;

    public String getTotalSign() {
        return totalSign;
    }

    public void setTotalSign(String totalSign) {
        this.totalSign = totalSign;
    }

    public List<LgavSignDateVO> getSignDates() {
        return signDates;
    }

    public void setSignDates(List<LgavSignDateVO> signDates) {
        this.signDates = signDates;
    }


}
