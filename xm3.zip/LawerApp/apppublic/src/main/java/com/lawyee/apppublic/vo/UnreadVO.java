package com.lawyee.apppublic.vo;

import net.lawyee.mobilelib.vo.BaseVO;

/**
 * All rights Reserved, Designed By www.lawyee.com
 *
 * @version V1.0.xxxxxxxx
 * @Package com.lawyee.apppublic.vo
 * @Description: 律师未读信息
 * @author: uustrong
 * @date: 2017/10/12 11:12
 * @verdescript 版本号 修改时间  修改人 修改的概要说明
 * @Copyright: ${year} www.lawyee.com Inc. All rights reserved.
 * 注意：本内容仅限于北京法意科技有限公司内部传阅，禁止外泄以及用于其他的商业目
 */

public class UnreadVO extends BaseVO{
    private static final long serialVersionUID = -2707867661636096267L;
    /**
     * 我的消息未读数
     */
     private String messageCount;
    /**
     * 我的委托未读数
     */
    private String entrustCount;



    /**
     * 黔微普法未读数
     */
    private String teamLawCount;
    /**
     * 咨询未读数
     */
    private String consultCount;
    /**
     * 我的活动未读数
     */
    private String activeCount;
    /**
     * 通知公告未读数
     */
    private String noticeCount;




    /**
     * 村居顾问未读数
     */
    private String teamVillageCount;




    /**
     * 值班问题未读数
     */
    private String teamDutyCount;




    /**
     *
     * 总数
     */
    private String totalCount;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getMessageCount() {
        return messageCount;
    }

    public void setMessageCount(String messageCount) {
        this.messageCount = messageCount;
    }

    public String getEntrustCount() {
        return entrustCount;
    }

    public void setEntrustCount(String entrustCount) {
        this.entrustCount = entrustCount;
    }


    public String getConsultCount() {
        return consultCount;
    }

    public void setConsultCount(String consultCount) {
        this.consultCount = consultCount;
    }

    public String getActiveCount() {
        return activeCount;
    }

    public void setActiveCount(String activeCount) {
        this.activeCount = activeCount;
    }

    public String getNoticeCount() {
        return noticeCount;
    }

    public void setNoticeCount(String noticeCount) {
        this.noticeCount = noticeCount;
    }

    public String getTotalCount() {
        return totalCount;
    }


    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }
    public String getTeamLawCount() {
        return teamLawCount;
    }

    public void setTeamLawCount(String teamLawCount) {
        this.teamLawCount = teamLawCount;
    }
    public String getTeamVillageCount() {
        return teamVillageCount;
    }

    public void setTeamVillageCount(String teamVillageCount) {
        this.teamVillageCount = teamVillageCount;
    }
    public String getTeamDutyCount() {
        return teamDutyCount;
    }

    public void setTeamDutyCount(String teamDutyCount) {
        this.teamDutyCount = teamDutyCount;
    }
}
